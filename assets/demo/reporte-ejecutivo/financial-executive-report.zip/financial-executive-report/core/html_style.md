# Estilo HTML Interactivo para Reportes Financieros

Referencia de implementación para generar reportes financieros como presentaciones
HTML interactivas de un solo archivo. Sigue los mismos principios de Storytelling with
Data definidos en `core/pptx_design.md`.

## Arquitectura

Single-file HTML con CSS + JS inline. Sin dependencias externas excepto Google Fonts.

```html
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte Financiero - {Empresa} - {Periodo}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>/* Todos los estilos aquí */</style>
</head>
<body>
    <!-- Slides aquí -->
    <script>/* Toda la lógica aquí */</script>
</body>
</html>
```

---

## CSS Variables (Paleta — misma que PPTX)

```css
:root {
    /* Corporativos */
    --primary: #0B5394;
    --primary-dark: #073B6B;
    --secondary: #1B7F9B;
    --accent: #0D6EFD;

    /* Semánticos */
    --positive: #0B5394;
    --negative: #CC0000;
    --warning: #E67E22;
    --success: #27AE60;

    /* Fondos */
    --bg-primary: #FFFFFF;
    --bg-slide: #F8FAFC;
    --bg-summary: #EBF2FA;
    --bg-table-header: #0B5394;
    --bg-table-alt: #F8F9FA;
    --bg-footer: #F2F4F6;
    --bg-danger: #F8D7DA;
    --bg-warning: #FFF3CD;
    --bg-success: #D1E7DD;

    /* Texto */
    --text-primary: #1A202C;
    --text-secondary: #4A5568;
    --text-light: #FFFFFF;
    --text-muted: #718096;

    /* Tipografía responsive */
    --title-size: clamp(1.5rem, 4vw, 3rem);
    --h2-size: clamp(1.2rem, 3vw, 2rem);
    --body-size: clamp(0.85rem, 1.5vw, 1rem);
    --small-size: clamp(0.75rem, 1.2vw, 0.875rem);

    /* Espaciado */
    --slide-padding: clamp(1.5rem, 4vw, 3rem);
    --card-gap: clamp(0.5rem, 1.5vw, 1rem);
}
```

---

## Estructura de Slides

### Navegación
```html
<nav class="slide-nav">
    <button onclick="goToSlide(n)" class="nav-dot active" title="Portada"></button>
    <!-- ... -->
</nav>
```
Navegación por dots + flechas izq/der + teclas.

### Componentes por Slide

#### Slide Header
```html
<div class="slide-header">
    <h2>{Título de la Slide}</h2>
</div>
```

#### Summary Box (Capa 1 del Comment Engine)
```html
<div class="summary-box">
    <p><em>{Hallazgo principal con cifra}</em></p>
</div>
```
Fondo: `var(--bg-summary)`. Borde izquierdo: 4px solid `var(--primary)`.

#### Content Zone
Layouts disponibles:
- `.layout-table-bullets` → tabla izq + bullets der (flexbox 60/40)
- `.layout-full-chart` → gráfico full width
- `.layout-dual` → gráfico + tabla side by side (50/50)
- `.layout-kpi-grid` → grid de KPI cards (responsive)
- `.layout-three-blocks` → conclusiones (hallazgos, riesgos, prioridades)

#### Footer (Capa 3 del Comment Engine)
```html
<div class="slide-footer" data-severity="normal|warning|critical">
    <p><em>{Forward-looking statement}</em></p>
</div>
```
Color según severity: normal=gris, warning=ámbar, critical=rojo.

---

## KPI Cards (Responsive)

```html
<div class="kpi-grid">
    <div class="kpi-card" data-status="good|warning|danger|neutral">
        <span class="kpi-label">{Label}</span>
        <span class="kpi-value">{Valor}</span>
        <span class="kpi-delta positive|negative">{Δ vs anterior}</span>
    </div>
</div>
```

```css
.kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: var(--card-gap);
}
.kpi-card[data-status="good"] { background: var(--bg-success); }
.kpi-card[data-status="warning"] { background: var(--bg-warning); }
.kpi-card[data-status="danger"] { background: var(--bg-danger); }
.kpi-card[data-status="neutral"] { background: var(--bg-footer); }
```

**Semáforo:** Asignar status según benchmarks de `sectors/{sector}.md`.

---

## Tablas Financieras

```css
.fin-table th { background: var(--bg-table-header); color: var(--text-light); }
.fin-table tr:nth-child(even) { background: var(--bg-table-alt); }
.fin-table .subtotal { font-weight: 600; background: #E8E8E8; }
.fin-table .total { font-weight: 700; background: var(--primary); color: white; }
```

⚠️ **REGLA CRÍTICA**: Filas `.total` siempre con `color: white`. Nunca texto oscuro.

### Heatmap en Ratios
Celdas de evaluación con fondo semántico:
```css
.eval-good { background: var(--bg-success); }
.eval-warning { background: var(--bg-warning); }
.eval-danger { background: var(--bg-danger); }
```

---

## Charts (Chart.js o inline SVG)

Preferir Chart.js para gráficos interactivos. Incluir como script inline.

### Waterfall
Implementar con barras floating (stacked bar con segmento transparente + color).
Colores: azul=positivo, rojo=negativo, teal=subtotal.

### Doughnut
Max 5 segmentos. cutout: '50%'. Leyenda bottom.

### Barras Horizontales (Pareto)
Ordenar de mayor a menor. Top 3 en color primary, resto en gris.

---

## Slides Sectoriales (Routing Modular)

El HTML debe incluir slides adicionales según el sector:

### restaurants
- Slide de Costos y Eficiencia: barras horizontales food cost por categoría + KPI cards sectoriales

### distribution
- Slide de Cartera y Eficiencia: DSO, rotación, concentración, CCE
- Slide Cambiario (condicional): si hay exposición USD

### Routing
```javascript
const SECTOR_SLIDES = {
    restaurants: ['slide-costos-eficiencia'],
    distribution: ['slide-cartera-eficiencia', 'slide-cambiario'],
    // ...
};

function renderSectorSlides(sector, data) {
    const slides = SECTOR_SLIDES[sector] || [];
    slides.forEach(slideId => {
        const el = document.getElementById(slideId);
        if (el) el.style.display = 'block';
    });
}
```

---

## Multi-Stakeholder (Resumen Ejecutivo)

4 columnas responsive:
```html
<div class="stakeholder-grid">
    <div class="stakeholder-card" data-role="ceo">
        <h4>CEO — ¿Es viable?</h4>
        <ul><!-- bullets --></ul>
    </div>
    <div class="stakeholder-card" data-role="cfo">...</div>
    <div class="stakeholder-card" data-role="comercial">...</div>
    <div class="stakeholder-card" data-role="directorio">...</div>
</div>
```

```css
.stakeholder-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
}
```

---

## Conclusiones (3 bloques)

```html
<div class="conclusions-block hallazgos"><!-- bg gris --></div>
<div class="conclusions-block riesgos"><!-- bg rojo claro --></div>
<div class="conclusions-block prioridades">
    <div class="priority-col urgente">0-3 meses</div>
    <div class="priority-col mediano">3-6 meses</div>
    <div class="priority-col estructural">6-12 meses</div>
</div>
```

---

## Responsive Design

```css
@media (max-width: 768px) {
    .layout-table-bullets { flex-direction: column; }
    .stakeholder-grid { grid-template-columns: 1fr; }
    .kpi-grid { grid-template-columns: repeat(2, 1fr); }
    .priority-col { width: 100%; }
}
```

---

## Print Support

```css
@media print {
    .slide-nav { display: none; }
    .slide { page-break-after: always; min-height: auto; }
    * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
}
```
