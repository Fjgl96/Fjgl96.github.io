# Comment Engine V4 — Mode-Aware Templates

Estructura de comentarios ejecutivos para slides financieras.
Los comentarios se adaptan al MODE del reporte.

---

## 1. MODOS DE COMENTARIO

### Mode: "diagnostic" → 3 CAPAS POR SLIDE
```
┌─────────────────────────────────────────────────────┐
│  SUMMARY BOX (Big Idea — hallazgo con implicación)  │
├─────────────────────────────────────────────────────┤
│  TABLE          │  BULLETS (3-5)                     │
│                 │  Cada uno: dato → causa → acción   │
├─────────────────┴───────────────────────────────────┤
│  FOOTER (forward-looking, acción siguiente)          │
└─────────────────────────────────────────────────────┘
```

### Mode: "status" → 1 CAPA POR SLIDE
```
┌─────────────────────────────────────────────────────┐
│  SUMMARY BOX (factual — hechos + deltas)            │
├─────────────────────────────────────────────────────┤
│  TABLE COMPARATIVA     │  BULLETS (2-3)             │
│  Actual|Anterior|Var   │  Solo hechos, sin acciones │
├────────────────────────┴────────────────────────────┤
│  FOOTER (informativo — sin acciones)                 │
└─────────────────────────────────────────────────────┘
```

---

## 2. TEMPLATES DE SUMMARY BOX

### 2.1 Mode: diagnostic

```
POSITIVE:  "[Métrica] alcanzó [valor], superando el benchmark de [ref] en [X pp/pts]."
NEGATIVE:  "[Métrica] se ubica en [valor], [X pp] por debajo del umbral de [ref], lo que indica [impacto]."
MIXED:     "Mientras [A] muestra mejora a [valor], [B] se deterioró a [valor], generando [tensión]."
DISTORTION: "[Métrica] muestra [valor] pero está distorsionada por [causa], el valor ajustado sería [aprox]."
ALERT:     "⚠️ [Condición regulatoria/legal] se ha activado: [detalle]. Requiere acción en [plazo]."
```

### 2.2 Mode: status

```
DELTA_POSITIVE:  "[Métrica] mejoró de [anterior] a [actual] ([+X pp/pts]), impulsada por [driver principal]."
DELTA_NEGATIVE:  "[Métrica] retrocedió de [anterior] a [actual] ([-X pp/pts]). Principal factor: [driver]."
DELTA_STABLE:    "[Métrica] se mantuvo estable en [valor] (variación de [±X pp]), en línea con [referencia]."
DELTA_MIXED:     "[A] mejoró [+X pp] mientras [B] retrocedió [-Y pp]. El efecto neto en [resultado] fue [Z]."
```

**Regla mode status:** NUNCA incluir "se recomienda", "debe evaluar", "acción requerida".
Solo hechos y variaciones. El lector decide qué hacer.

---

## 3. TEMPLATES DE BULLETS

### 3.1 Mode: diagnostic (dato → causa → acción)

```
Positivo:
  "El margen bruto de 55.4% supera el benchmark sectorial de 50%. El pricing
  actual es adecuado. Mantener estrategia de precios y monitorear insumos."

Negativo:
  "El food cost de 44.6% excede el benchmark de 38% por 6.6 pp. Las categorías
  de mayor incidencia son pescados (65%) y carnes (52%). Priorizar renegociación
  con proveedores y revisión de porciones."

Distorsionado:
  "El resultado neto incluye dif. cambio de S/ 207,885 (no recurrente). Sin este
  efecto, la pérdida real es S/ 452,256 (margen: -24.2%). No usar como base
  para proyecciones."

Alerta regulatoria:
  "Las pérdidas acumuladas (S/ 540,918) superan 2/3 del capital (S/ 1,000).
  Art. 407 LGS configura causal de disolución. El directorio debe convocar junta."
```

### 3.2 Mode: status (solo dato + delta)

```
Delta positivo:
  "Ventas netas crecieron 12.3% interanual (de S/ 1,662K a S/ 1,867K), con
  pico en diciembre (S/ 243K vs S/ 198K del año anterior)."

Delta negativo:
  "Margen bruto retrocedió 2.1 pp (de 57.6% a 55.5%). Principal driver:
  incremento en costo de pescados/mariscos (+15% interanual)."

Estable:
  "Ratio corriente se mantuvo en 1.21x (vs 1.18x anterior), sin cambios
  materiales en la composición de activos ni pasivos corrientes."
```

**Regla mode status:** Máximo 3 bullets por slide. Sin "recomendaciones" ni "acciones".
Cada bullet es una observación factual con el delta numérico.

---

## 4. TEMPLATES DE FOOTER

### 4.1 Mode: diagnostic (action-oriented)

```
NORMAL (gris):
  "Para el siguiente periodo, monitorear la evolución de [variable] y su impacto en [métrica]."

WARNING (ámbar):
  "Si [condición] persiste más de [plazo], el riesgo de [consecuencia] se incrementa significativamente."

CRITICAL (rojo):
  "Acción inmediata requerida: [qué hacer] antes de [fecha/condición] para evitar [consecuencia]."

POSITIVE (azul):
  "La tendencia actual permite [oportunidad]. Considerar [acción] para capitalizar esta posición."
```

### 4.2 Mode: status (informational — NO accionable)

```
INFORMATIONAL (gris):
  "Indicadores actualizados al [fecha]. Siguiente corte: [fecha siguiente]."

TREND (gris):
  "La tendencia de [métrica] en los últimos [N] meses muestra [patrón]."

CONTEXT (gris):
  "El periodo incluye [eventos relevantes] que impactaron [métricas afectadas]."
```

**Regla mode status:** Footers NUNCA contienen verbos imperativos ("reducir",
"evaluar", "implementar"). Solo contexto y hechos.

---

## 5. FRAMEWORK MULTI-STAKEHOLDER (solo mode diagnostic)

En mode "status", NO se incluye el grid multi-stakeholder.
Se reemplaza por un dashboard de KPIs con deltas.

### diagnostic: 4 columnas stakeholder
CEO — "¿Es viable?"
CFO — "¿Cuánto riesgo?"
Dir. Comercial — "¿Costos?"
Directorio — "¿Cumplimos?"

### status: KPI dashboard con tendencias
Fila 1: 5 KPI cards con valor actual + flecha ↑↓ + delta vs anterior
Fila 2: 5 KPI cards más
Mini-trend sparklines si hay data mensual
Sin cajas de stakeholder

---

## 6. SLIDE DE CONCLUSIONES vs EVOLUCIÓN

### diagnostic → Conclusiones (3 bloques)
- **HALLAZGOS** (gris): 4-5 bullets dato + implicación
- **RIESGOS** (rojo): 3-4 formato "SI [condición] → ENTONCES [impacto]"
- **PRIORIDADES** (verde, 3 columnas): Urgente (0-3m) | Mediano (3-6m) | Estructural (6-12m)

### status → Evolución de Indicadores
- **Tabla resumen**: Indicador | Actual | Anterior | Var | Tendencia (↑↓→)
- **Semáforo de tendencia**: Verde=mejora, Gris=estable, Rojo=deterioro
- **SIN bloques de riesgo ni prioridades**
- **SIN verbos imperativos**

---

## 7. REGLAS DE CONSISTENCIA (aplican a AMBOS modos)

### Datos
1. Montos en bullets = montos exactos de tablas
2. Porcentajes con 1 decimal
3. Variaciones: pp para porcentajes, % para montos

### Tono
1. Mode diagnostic: directo y constructivo ("la operación no es rentable")
2. Mode status: neutral y factual ("el margen operativo fue -23.9%")
3. NUNCA alarmista innecesariamente en ningún modo

### Redundancia
1. Summary box → QUÉ (hallazgo o hecho principal)
2. Bullets → POR QUÉ (evidencia) — solo en diagnostic tienen "acción"
3. Footer → diagnostic: QUÉ HACER | status: CONTEXTO SIGUIENTE
4. NO repetir la misma información en las 3 capas

---

## 8. TEMPLATES SLIDE FLUJO DE EFECTIVO (V4.2)

La slide de Flujo de Efectivo usa Layout Tipo D-CF: tabla método indirecto (izq) + gráfico barras (der).

### 8.1 Summary Box

```
diagnostic:
  POSITIVE: "La operación generó S/ [flujo_op] de caja en [periodo], [+/-X%] vs [anterior]. [Driver principal del cambio en WK]."
  NEGATIVE: "La operación consumió S/ [flujo_op] de caja en [periodo]. [Causa: pérdida neta + cambios adversos en WK]. El efectivo se redujo [X%]."
  MIXED: "A pesar de [pérdida/resultado], la generación operativa fue [positiva/negativa] por [driver]. El financiamiento [compensó/no compensó] el déficit."

status:
  "Flujo operativo [periodo]: S/ [monto] (vs S/ [anterior], [+/-X%]). Variación neta de efectivo: S/ [monto]. Saldo final: S/ [saldo]."
```

### 8.2 Bullets (al lado derecho del gráfico, Tipo D-CF)

```
diagnostic (3-4 bullets, dato→causa→acción):
  "Operación (+/- S/ X): [Deprec. S/ Y] + [cambios WK S/ Z] compensaron/no compensaron la pérdida neta. [Acción sobre WK]."
  "Inversión (-S/ X): [Detalle CAPEX]. [Comparar vs periodo anterior]. [Evaluar si es mantenimiento o expansión]."
  "Financiamiento (+/- S/ X): [Origen: préstamos/pagos]. [Impacto en estructura de deuda]."
  "Efecto cambiario (-S/ X): [Contexto de exposición en ME]. [Solo si material >2% del efectivo]."

status (2-3 bullets, solo hechos):
  "Flujo operativo S/ X (vs S/ Y anterior, [+/-Z%]). Principal driver: [cambios WK / deprec]."
  "Efectivo: S/ [inicial] → S/ [final] ([+/-X%])."
```

### 8.3 Footer

```
diagnostic: "La generación operativa de caja [es/no es] suficiente para cubrir [inversiones + servicio de deuda]. [Acción sobre política de caja]."
status: "Saldo de efectivo actualizado al [fecha]. Cobertura de gastos operativos: ~[N] meses."
```
