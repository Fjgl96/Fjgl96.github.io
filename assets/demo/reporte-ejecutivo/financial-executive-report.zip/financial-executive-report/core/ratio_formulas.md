# Formulas de Ratios Financieros

## Liquidez
Ratio Corriente = AC / PC (0.00x)
Prueba Acida = (AC - Inventarios - Suministros) / PC
Capital Trabajo = AC - PC (S/ monto)
Dias Cobertura = Efectivo / (Gastos_Diarios_Prom)
  Donde: Gastos_Diarios_Prom = (CV + Gastos_Restaurante + Gastos_Admin) / 365
  Nota: Para periodos parciales, usar dias_reales en vez de 365
  Edge: Si gastos=0 → NA | Si <15 dias → alerta liquidez critica

## Solvencia
D/E = Pasivo / Patrimonio
  Edge: pat<0 PATRIMONIO NEGATIVO | pat<1% activo notar distorsion
Endeudamiento = Pasivo / Activo
Concentracion CP = PC / Pasivo Total x 100
Cobertura Intereses = EBIT / Gastos Financieros
  Edge: GF=0 NA | EBIT<0 negativo con nota

## Rentabilidad
Margen Bruto = (Ventas-CV)/Ventas x100
Margen Operativo = EBIT/Ventas x100
Margen Neto = Resultado/Ventas x100
EBITDA = EBIT + Deprec_periodo
  Deprec_periodo: buscar en EGP (dentro de gastos) o estimar de BG si hay 2 periodos
  Si solo 1 periodo y deprec dentro de gastos: EBITDA = EBIT + Deprec_acum_BG (aprox)
  SIEMPRE mostrar descomposicion explicita: "EBIT (X) + D&A (Y) = EBITDA (Z)"
  Edge: Si EBITDA<0 → operacion no genera caja operativa (destacar)
ROE = Resultado/Patrimonio x100 (si pat<5% activo usar DuPont)
ROA = Resultado/Activo x100

## Eficiencia
Rotacion Inv = CV/Inventarios | Edad = 360/Rotacion
Rotacion CxC = Ventas/CxC | Per Cobro = 360/Rot
Rotacion CxP = CV/CxP | Per Pago = 360/Rot
CCE = Edad Inv + Per Cobro - Per Pago

## Punto Equilibrio
PE = Gastos Fijos / (1 - CV/Ventas)
