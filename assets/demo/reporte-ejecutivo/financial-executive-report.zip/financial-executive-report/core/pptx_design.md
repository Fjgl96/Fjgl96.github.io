# Diseño Visual PPTX — Guía Completa

Basado en principios de Storytelling with Data (Nussbaumer Knaflic) + mejores prácticas
financieras. Esta guía gobierna TODA la generación visual del reporte.

---

## 1. FILOSOFÍA CORE (Storytelling with Data)

### 1.1 Contexto Antes de Data
Cada slide debe responder UNA pregunta clara. Antes de elegir el gráfico, definir:
- **Quién** lo va a leer (CEO, CFO, Directorio, Banco)
- **Qué** necesita saber o decidir
- **Big Idea** de la slide: 1 oración que condense el hallazgo

### 1.2 Exploratorio vs Explicativo
Los reportes financieros son EXPLICATIVOS. No mostrar toda la data cruda.
Presentar las "perlas" (2-3 hallazgos clave), no las 100 ostras.
- NO: tabla con 50 cuentas contables
- SÍ: tabla condensada en 8-12 líneas + bullets con los hallazgos

### 1.3 Storytelling Arc (Beginning → Middle → End)
El reporte sigue un arco narrativo:
- **Beginning** (Slides 1-2): Contexto, KPIs resumen, semáforo → "¿Dónde estamos?"
- **Middle** (Slides 3-8): Evidencia, análisis, drivers → "¿Por qué estamos aquí?"
- **End** (Slides 9-10): Conclusiones, riesgos, prioridades → "¿Qué hacemos ahora?"

---

## 2. PALETA DE COLORES

### 2.1 Colores Base
```
primary:      0B5394    (azul corporativo — headers, totales, positivo)
secondary:    1B7F9B    (teal — subtotales, referencia)
negative:     CC0000    (rojo — pérdidas, alertas críticas)
warning:      FFC107    (ámbar — precaución)
neutral:      6C757D    (gris — texto secundario)
```

### 2.2 Fondos
```
lightGray:    F2F4F6    (fondo general, KPI cards neutral)
altRowBg:     F8F9FA    (filas alternas tablas)
subtotalBg:   E8E8E8    (subtotales)
summaryBox:   EBF2FA    (caja resumen ejecutivo)
dangerBg:     F8D7DA    (fondo riesgos)
warningBg:    FFF3CD    (fondo advertencias)
successBg:    D1E7DD    (fondo positivo)
```

### 2.3 Texto
```
lightText:    FFFFFF    (sobre fondos oscuros — headers, totales)
darkText:     2D3748    (texto principal)
```

### 2.4 Regla de Color (SWD)
- Diseñar en GRIS primero, luego usar UN color estratégico para destacar
- Azul = positivo/estable. Rojo = negativo/alarma. Gris = contexto/referencia
- Teal = subtotales y categorías intermedias
- NUNCA usar color por decoración. Cada color tiene significado semántico
- Máximo 3 colores por gráfico (excluyendo gris)

### 2.5 Font
```
font: Calibri (todo el reporte)
```

---

## 3. LAYOUT (LAYOUT_WIDE 13.33 x 7.5 pulgadas)

### 3.1 Zonas de Slide

```
┌─────────────────────────────────────────────────┐
│  HEADER BAR (azul primary)                       │ y:0 h:0.6
│  Título slide (blanco, 14pt bold, x:0.4)         │
├─────────────────────────────────────────────────┤
│  SUMMARY BOX (fondo EBF2FA)                      │ y:0.75 h:0.55
│  Hallazgo principal en itálica (10pt)            │ x:0.4 w:12.53
├─────────────────────────────────────────────────┤
│                                                   │
│  CONTENT ZONE                                     │ y:1.5
│  Tablas, gráficos, bullets                       │
│  (varía por tipo de slide)                       │
│                                                   │
├─────────────────────────────────────────────────┤
│  FOOTER (itálica, forward-looking)               │ y:6.5 h:0.55
│  Color según gravedad: gris/ámbar/rojo           │ x:0.4 w:12.53
├─────────────────────────────────────────────────┤
│  PAGE NUMBER                                      │ x:12.4 y:6.9
└─────────────────────────────────────────────────┘
```

### 3.2 Coordenadas por Tipo de Slide

#### Tipo A: Tabla + Bullets (EGP, ESF Activos, ESF P&P)
```
Tabla:    x:0.4  y:1.5  w:7.8  h:auto (fontSize 8-9pt)
Bullets:  x:8.5  y:1.5  w:4.4  h:4.5  (fontSize 8-9pt)
```

#### Tipo B: KPI Cards Grid (Resumen Ejecutivo)
```
Fila 1:   y:1.0  h:1.2  → 5 cards (x: 0.4, 2.95, 5.5, 8.05, 10.6) w:2.25
Fila 2:   y:2.4  h:1.2  → 5 cards mismos x
Multi-stakeholder boxes: y:3.8  4 columnas w:3.0 gap:0.2
```

#### Tipo C: Gráficos Full Width (Estructura, Waterfall)
```
Gráfico:  x:0.6  y:1.5  w:12.0  h:4.5
Leyenda:  bottom (showLegend:true, legendPos:'b')
```

#### Tipo D: Dual (Gráfico + Tabla pequeña)
```
Gráfico:  x:0.4  y:1.5  w:6.5  h:4.5
Tabla:    x:7.2  y:1.5  w:5.7  h:4.5
```

#### Tipo D-CF: Flujo de Efectivo Dual (V4.2)
Tabla resumen método indirecto (izq) + gráfico de barras por actividad (der):
```
Tabla:    x:0.4  y:1.5  w:6.5  h:4.2  (6-8 filas, método indirecto)
Gráfico:  x:7.2  y:1.5  w:5.7  h:4.2  (barras: Oper | Inv | Fin | TC | Neto)
```
Estructura tabla método indirecto:
```
| Concepto                    | P1 (S/)   | P2 (S/)   | Var S/    |
| Resultado Neto              | (xxx)     | (xxx)     | (xxx)     |
| (+) Depreciación y Amort.   | xxx       | xxx       | xxx       |
| (+) Otros ajustes no caja   | xxx       | xxx       | xxx       |  ← gris si = 0
| (±) Cambios en WK           | xxx       | xxx       | xxx       |
| = Flujo Operativo           | xxx       | xxx       | xxx       |  ← SUBTOTAL
| Flujo de Inversión          | (xxx)     | (xxx)     | xxx       |
| Flujo de Financiamiento     | xxx       | (xxx)     | (xxx)     |
| Efecto Tipo de Cambio       | (xxx)     | (xxx)     | xxx       |  ← solo si ≠ 0
| = Variación Neta Efectivo   | xxx       | (xxx)     | (xxx)     |  ← TOTAL
```
Para 1 periodo: tabla de 2 columnas (Concepto + Importe) + gráfico barras.
Fuente: Estado de Flujo de Efectivo del EEFF. NO estimar — usar datos reales.

#### Tipo E: Conclusiones (3 bloques)
```
Hallazgos:   x:0.4  y:1.2  w:12.53  h:1.5  fondo:F2F4F6
Riesgos:     x:0.4  y:2.9  w:12.53  h:1.3  fondo:F8D7DA
Prioridades: x:0.4  y:4.4  w:12.53  h:2.0  fondo:D1E7DD
  Columna 1 (Urgente 0-3m):     x:0.5  w:4.0
  Columna 2 (Mediano 3-6m):     x:4.7  w:4.0
  Columna 3 (Estructural 6-12m): x:8.9  w:4.0
```
**Headers de Prioridades con Dots de Color (V4.2):**
```
Cada header de columna usa un círculo de color + texto:
  Columna 1: addShape(OVAL, {x:0.5,  y:4.5, w:0.18, h:0.18, fill:{color:"CC0000"}})
             addText("Urgente (0-3 meses)", {x:0.75, y:4.47, bold, color:"CC0000"})
  Columna 2: addShape(OVAL, {x:4.7,  y:4.5, w:0.18, h:0.18, fill:{color:"FFC107"}})
             addText("Mediano Plazo (3-6m)", {x:4.95, y:4.47, bold, color:"B8860B"})
  Columna 3: addShape(OVAL, {x:8.9,  y:4.5, w:0.18, h:0.18, fill:{color:"28A745"}})
             addText("Estructural (6-12m)", {x:9.15, y:4.47, bold, color:"28A745"})
```
Refuerza el sistema de semáforo usado en ratios → consistencia cromática en todo el reporte.

---

## 4. TABLAS FINANCIERAS

### 4.1 Estilos de Fila
```
HEADER:     fill:0B5394  color:FFFFFF  bold:true  fontSize:9  align:center
DATOS:      alternas FFFFFF / F8F9FA  fontSize:8-9  align:right (montos)
SUBTOTAL:   bold:true  fill:E8E8E8  color:2D3748
TOTAL:      bold:true  fill:0B5394  color:FFFFFF
```

### 4.2 REGLA CRÍTICA DE VISIBILIDAD
⚠️ **Filas TOTAL: texto SIEMPRE BLANCO (FFFFFF) sobre fondo azul (0B5394).**
NUNCA texto azul sobre fondo azul. NUNCA texto rojo sobre fondo azul.
Si un total es negativo, usar FFFFFF igualmente (el fondo azul ya provee contraste).

### 4.3 Formato Numérico
- Montos: separador de miles, sin decimales (S/ 262,951)
- Porcentajes: 1 decimal (55.4%)
- Ratios: 2 decimales (1.31x)
- Columnas de montos: alineadas a la derecha
- Primera columna (cuenta): alineada a la izquierda
- Incluir SIEMPRE símbolo moneda y % — no depender del título

### 4.4 Reglas de Condensación (SWD: Declutter)
- Máximo 12-15 filas por tabla (agrupar cuentas menores en "Otros")
- Eliminar filas con valor 0 o insignificante (<0.5% del total)
- Si hay análisis vertical, ponerlo como columna "%" al lado del monto
- No repetir el total del activo si ya aparece en otra slide

### 4.5 Heatmap en Tablas (SWD)
Para tablas de ratios con benchmark, usar color de fondo semántico:
- Verde claro (D1E7DD) → ratio en zona "sólido/bueno"
- Ámbar claro (FFF3CD) → ratio en zona "adecuado/monitorear"
- Rojo claro (F8D7DA) → ratio en zona "riesgo/crítico"
Esto reemplaza columnas de "Evaluación" con texto — el color ES la evaluación.

### 4.6 Círculos Semáforo en Tabla de Ratios (V4.2)
ADEMÁS del heatmap de fondo, agregar columna "Estado" con círculos de color sólido:
```
Columna final de la tabla: "Estado" (ancho: 0.6")
Cada celda contiene un círculo (addShape OVAL) centrado:
  🟢 fill: 28A745  → Cumple benchmark
  🟡 fill: FFC107  → En observación
  🔴 fill: CC0000  → Fuera de benchmark
  Tamaño: 0.24" × 0.24" (radio 0.12")
```
Implementación pptxgenjs:
```javascript
// Después de slide.addTable(), agregar círculos por fila:
const circleX = tableX + tableW - 0.35; // centrado en última columna
ratioData.forEach((r, i) => {
  if (r.header) return; // skip headers de sección
  const circleY = tableY + headerH + (dataRowIndex * rowH) + (rowH - 0.24) / 2;
  const color = getSemaforo(r.value, r.thresholds); // "28A745" | "FFC107" | "CC0000"
  slide.addShape("ellipse", {
    x: circleX, y: circleY, w: 0.24, h: 0.24,
    fill: { color: color }
  });
});
```
Leyenda al pie de tabla: "🟢 Cumple benchmark  |  🟡 En observación  |  🔴 Fuera de benchmark"
Implementar con 3 shapes OVAL pequeños (0.15") + texto inline.

---

## 5. REGLAS DE VISUALIZACIÓN (SWD + Finanzas)

### 5.1 Las 10 Reglas Fundamentales

1. **Cada gráfico responde UNA pregunta**
   Si no puedes escribir la pregunta en 1 oración, el gráfico es demasiado complejo.

2. **Máx 5 segmentos en pie/doughnut** (resto como "Otros")
   SIEMPRE leyenda visible (showLegend:true, legendPos:'b').
   Considerar barras 100% stacked como alternativa superior a pies.

3. **Waterfall para bridges de rentabilidad**
   Ventas → CV → Margen Bruto → Gastos → EBIT.
   Colores: azul=positivo, rojo=negativo, teal=subtotal/neto.

4. **Barras horizontales para rankings y Pareto**
   Top 10 gastos, composición de costos por categoría.
   Ordenar de mayor a menor (no alfabético).

5. **Stacked bars para composición temporal, NO múltiples pies**
   Composición de activos/pasivos en el tiempo → stacked bars.
   NUNCA hacer 3 pies lado a lado para comparar periodos.

6. **Color semántico consistente**
   azul=positivo, rojo=negativo, teal=subtotal, gris=referencia.
   NUNCA cambiar el significado del color entre slides.

7. **Menos es más: 1 buen chart > 3 mediocres**
   Si la tabla ya cuenta la historia, NO agregar gráfico redundante.
   Priorizar claridad sobre completitud.

8. **Data-ink ratio alto** (SWD: Declutter)
   Sin gridlines innecesarios. Sin 3D NUNCA. Sin bordes de gráfico.
   Sin marcadores en líneas (excepto puntos clave). Sin chart border.
   Etiquetar datos directamente cuando sea posible, no depender de leyenda.

9. **Formato numérico consistente con el país** (ver countries/)
   Perú: S/ 262,951 con comas. 15.4% con punto decimal.

10. **Jerarquía visual clara** (SWD: Preattentive Attributes)
    Título > Hallazgo > Data > Contexto.
    Usar tamaño, peso y color para crear esta jerarquía.
    Lo más importante debe verse primero sin esfuerzo.

### 5.2 Reglas Adicionales de Declutter (SWD Cap.3)

- **Remover borde del gráfico** → el gráfico flota en la slide
- **Remover gridlines** → si son necesarias, usar gris muy claro (E8E8E8)
- **Remover data markers** → solo marcar puntos críticos (max, min, actual)
- **Limpiar labels de ejes** → no poner TODOS los valores, solo los informativos
- **Etiquetar directamente** → poner el nombre junto a la línea/barra, no en leyenda
- **Color consistente** → gris para "todo lo demás", UN color para el foco

### 5.3 Dirigir la Atención (SWD Cap.4)
Usar atributos preatentivos para señalar dónde mirar:
- **Tamaño**: KPI principal más grande (18pt bold), secundarios más chicos
- **Color**: UN dato resaltado en azul/rojo, el resto en gris
- **Posición**: Lo más importante arriba-izquierda (lectura en Z)
- **Negrita**: Solo para hallazgos clave, no para todo

---

## 6. KPI CARDS

### 6.1 Layout Grid
2 filas × hasta 5 columnas. Cada card:
```
Ancho: 2.25"  Alto: 1.2"
Fondo según semáforo:
  good:    D1E7DD (verde claro)
  warning: FFF3CD (ámbar claro)
  danger:  F8D7DA (rojo claro)
  neutral: F2F4F6 (gris claro)
```

### 6.2 Estructura Interna

**Modo single-period:**
```
┌───────────────┐
│ LABEL  (8pt)  │  color: 6C757D (gris), align: center
│ VALOR  (18pt) │  bold, color: 2D3748, align: center
│ DELTA  (7pt)  │  color: verde si positivo, rojo si negativo
└───────────────┘
```

**Modo multiperiodo (V4.2):**
```
┌─────────────────────┐
│ LABEL        (8pt)  │  color: 6C757D (gris), align: center
│ VALOR        (18pt) │  bold, color: 2D3748, align: center
│ ↑↓ DELTA     (9pt)  │  bold, verde/rojo, con flecha ↑ o ↓
│ vs [anterior] (7pt) │  italic, color: 6C757D (gris)
└─────────────────────┘
Alto card: 1.3" (0.1" más que single para acomodar línea extra)
```
Reglas multiperiodo:
- DELTA prominente: fontSize 9pt bold (no 7pt). Incluir flecha: "↑ +12.3%" o "↓ -5.2 pp"
- Color delta: 28A745 (verde) si mejora, CC0000 (rojo) si deteriora. Para ratios invertidos (D/E, endeudamiento), bajar es verde.
- Valor anterior: "vs S/ 4,272,524" en gris itálica 7pt. Solo referencia, no protagonista.
- NO agregar 3ra fila de cards. Mantener 2 filas × 5 cards + multi-stakeholder debajo.

### 6.3 Semáforo por Sector
Usar benchmarks de `sectors/{sector}.md` para asignar colores.
Ejemplo restaurante: food_cost <32% → good, 32-38% → warning, >38% → danger.

---

## 7. GRÁFICOS ESPECÍFICOS

### 7.1 Waterfall (Bridge de Rentabilidad)
```
Categorías:  Ventas | -CV | =Margen Bruto | -G.Admin | -G.Ventas | =EBIT | ±Otros | =Resultado
Colores:     azul    rojo   teal            rojo       rojo        teal    gris     azul/rojo
```
- Barras positivas arrancan del eje
- Barras negativas caen desde el subtotal anterior
- Subtotales (MB, EBIT, Resultado) son barras completas en teal
- Labels de valor sobre cada barra (fontSize 8)
- SIN gridlines, SIN borde

### 7.2 Doughnut (Estructura Financiera)
```
innerSize: 50%
Max 5 segmentos + "Otros" si es necesario
Leyenda: bottom, horizontal
```
Usar para: Composición de activos, Fuentes de financiamiento, Mix de gastos.
Si hay 2+ periodos, preferir stacked bars sobre múltiples doughnuts.

### 7.3 Barras Horizontales (Pareto)
```
Ordenar de mayor a menor
Color principal: 0B5394
Top 3 resaltados, resto en gris claro (D5D5D5)
Labels de valor al final de cada barra
```
Usar para: Top gastos, Composición de costo de ventas, Ranking de ratios.

### 7.4 Tabla con Semáforo (Ratios)
```
Formato (V4.2):
| Ratio | P1 | P2 | Benchmark | Variación | Estado |
```
- Columnas P1/P2 con heatmap de fondo semántico (verde/ámbar/rojo claro)
- Columna "Estado" con círculos sólidos (ver sección 4.6)
- Columna "Variación" con color de texto (verde si mejora, rojo si deteriora)
- En vez de columna "Evaluación" con texto, el color ES la evaluación (dual: fondo + círculo)

---

## 8. PORTADA Y CIERRE

### 8.1 Slide de Portada
```
Fondo: 0B5394 (azul primary) full slide
Título empresa: blanco, 28pt bold, centrado vertical
Subtítulo: "Reporte Financiero Ejecutivo"
Periodo: "Enero 2026" / "Ejercicio 2025"
Fecha de generación: esquina inferior derecha, 9pt
```

### 8.2 Slide de Cierre
```
Fondo: 0B5394 o gradiente
Texto central: "Información preparada para uso interno"
Disclaimer: "Las proyecciones son estimaciones..."
Contacto / créditos si aplica
```

---

## 9. QA CHECKLIST VISUAL

Verificar ANTES de entregar:

### Datos
- [ ] Montos en slides = montos parseados del Excel (no redondear arbitrariamente)
- [ ] Porcentajes calculados correctamente (1 decimal)
- [ ] Totales cuadran: Activo = Pasivo + Patrimonio
- [ ] Signos correctos: CV positivo en tabla pero restando en waterfall

### Tablas
- [ ] Filas TOTAL: texto BLANCO sobre fondo AZUL (NUNCA texto oscuro)
- [ ] Filas alternas con colores correctos
- [ ] Subtotales en gris con negrita
- [ ] Columnas numéricas alineadas a la derecha
- [ ] Símbolo de moneda presente

### Gráficos
- [ ] Doughnuts con máx 5 segmentos y leyenda visible bottom
- [ ] Waterfall con colores semánticos correctos
- [ ] Sin 3D, sin gridlines excesivos, sin bordes de chart
- [ ] Labels directos cuando es posible
- [ ] Barras ordenadas de mayor a menor (no alfabético)

### Storytelling
- [ ] Cada slide tiene Big Idea clara en summary box
- [ ] Summary box NO repite lo que dicen los bullets
- [ ] Footer es forward-looking (no repite datos)
- [ ] Arco narrativo: Contexto → Evidencia → Acción
- [ ] KPIs sectoriales presentes con benchmarks del sector
- [ ] Benchmarks corresponden al sector específico (no genéricos)

### Técnico (pptxgenjs)
- [ ] Hex SIN # (pptxgenjs no usa #): "0B5394" no "#0B5394"
- [ ] Shadow: usar factory function, no reusar objetos shadow
- [ ] Unicode bullets: usar {bullet: true}, no caracteres manuales
- [ ] Layout: LAYOUT_WIDE (13.33 x 7.5)

### V4.2 Features
- [ ] KPI cards multiperiodo: delta en 9pt bold con flecha ↑↓ + valor anterior en gris 7pt
- [ ] Tabla ratios: círculos semáforo (OVAL 0.24") alineados con filas de datos
- [ ] Tabla ratios: leyenda de círculos al pie (🟢🟡🔴)
- [ ] ROE presente en sección Rentabilidad de ratios
- [ ] Flujo de Efectivo: tabla método indirecto (izq) + gráfico barras (der)
- [ ] Conclusiones: dots de color (OVAL 0.18") antes de cada header de prioridad
- [ ] Var S/: presente en tablas comparativas cuando hay espacio (Tipo F o ≤5 cols)

---

## 10. ERRORES FRECUENTES A EVITAR

1. **Texto invisible**: fila total con texto azul/negro sobre fondo azul → BLANCO siempre
2. **Doughnut sin leyenda**: showLegend:true obligatorio
3. **Más de 5 segmentos**: agrupar en "Otros"
4. **Shadow reuse**: cada shape necesita su propia instancia de shadow
5. **Hex con #**: pptxgenjs usa "0B5394", no "#0B5394"
6. **Unicode bullets manual**: usar bullet:true del API
7. **Gráfico 3D**: NUNCA, bajo ninguna circunstancia
8. **Múltiples pies para comparar**: usar stacked bars
9. **Decoración sin función**: cada elemento visual debe informar
10. **Eje Y secundario**: generalmente mala idea, confunde al lector
