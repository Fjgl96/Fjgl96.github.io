/**
 * slide_estructura.js — Estructura Financiera
 * 1 period: 2 doughnuts (Activos, Financiamiento) + monthly trend line + PE box
 * 2+ periods: stacked bars comparison
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const mode = plan.mode;

  h.addHeader(pres, slide, "Estructura Financiera y Tendencia de Ventas Mensuales");

  const patNegNote = ratios.patrimonio < 0
    ? `El activo se financia en un ${h.pct1(ratios.endeudamiento)} con deuda (patrimonio negativo).`
    : `Activo financiado ${h.pct1(ratios.endeudamiento)} con deuda y ${h.pct1(100 - ratios.endeudamiento)} con patrimonio.`;
  const monthlyNote = data.monthly && Object.keys(data.monthly.ventas_netas || {}).length >= 6
    ? ` La tendencia de ventas muestra estacionalidad con picos identificables.`
    : "";

  h.addSummaryBoxSimple(pres, slide,
    slideConfig.summary_text || patNegNote + monthlyNote
  );

  const ac = data.esf.activo_corriente;
  const anc = data.esf.activo_no_corriente;
  const pc = data.esf.pasivo_corriente;
  const pnc = data.esf.pasivo_no_corriente;
  const pat = data.esf.patrimonio;
  const totalA = data.esf.totales.activo;

  // ── DOUGHNUT 1: ACTIVOS ──
  slide.addText("Composición de Activos", {
    x: 0.4, y: 1.45, w: 4, h: 0.3,
    fontSize: 9, fontFace: h.FONT, color: C.primary, bold: true, align: "center"
  });

  const actSegments = [
    { label: "Efectivo", val: ac.efectivo || 0 },
    { label: "CxC", val: (ac.cxc_comerciales || 0) + (ac.cxc_diversas || 0) + (ac.cxc_personal || 0) },
    { label: "Inventarios", val: (ac.mercaderias || 0) + (ac.suministros_menajes || 0) },
    { label: "Otros AC", val: (ac.gastos_anticipados || 0) },
    { label: "ANC (IME)", val: anc.total_anc },
  ].filter(s => Math.abs(s.val) > totalA * 0.01);

  const actColors = [C.primary, C.secondary, "4CAF50", C.warning, C.neutral];
  drawDoughnut(pres, slide, actSegments, actColors, 0.8, 1.85, 3.2, 3.2, totalA, h);

  // ── DOUGHNUT 2: FINANCIAMIENTO ──
  slide.addText("Fuentes de Financiamiento", {
    x: 4.6, y: 1.45, w: 4, h: 0.3,
    fontSize: 9, fontFace: h.FONT, color: C.primary, bold: true, align: "center"
  });

  const finSegments = [
    { label: "CxP Comerciales", val: pc.cxp_comerciales || 0 },
    { label: "Otros PC", val: pc.total_pc - (pc.cxp_comerciales || 0) },
    { label: "Deuda Accionistas", val: pnc.cxp_accionistas_nc || 0 },
    { label: "Otros PNC", val: pnc.total_pnc - (pnc.cxp_accionistas_nc || 0) },
    { label: "Patrimonio", val: Math.max(pat.total_patrimonio, 0) },
  ].filter(s => s.val > totalA * 0.01);

  // If patrimonio is negative, don't show it as segment
  const finColors = ["E74C3C", "F39C12", C.negative, C.warning, "27AE60"];
  const finTotal = finSegments.reduce((s, seg) => s + seg.val, 0);
  drawDoughnut(pres, slide, finSegments, finColors, 5.0, 1.85, 3.2, 3.2, finTotal, h);

  // ── PATRIMONIO NEGATIVO NOTE ──
  if (pat.total_patrimonio < 0) {
    const noteY = 1.85 + 0.3 + 0.5 + 0.2 + finSegments.length * 0.3 + 0.15;
    slide.addText(`* Patrimonio negativo (${h.fmtS(pat.total_patrimonio)}) — no representable en gráfico de composición`, {
      x: 5.0, y: Math.min(noteY, 4.8), w: 3.5, h: 0.35,
      fontSize: 6.5, fontFace: h.FONT, color: C.negative, italic: true, valign: "top"
    });
  }

  // ── MONTHLY TREND (if available) ──
  const monthly = data.monthly || {};
  const ventasMensual = monthly.ventas_netas || {};
  const months = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"];

  if (Object.keys(ventasMensual).length >= 6) {
    slide.addText("Ventas Mensuales", {
      x: 9.0, y: 1.45, w: 4, h: 0.3,
      fontSize: 9, fontFace: h.FONT, color: C.primary, bold: true, align: "center"
    });

    const vals = months.map(m => ventasMensual[m] || 0);
    const maxV = Math.max(...vals);
    const chartX = 9.2, chartY = 1.85, chartW = 3.8, chartH = 2.5;

    // Y-axis scale
    slide.addText(h.fmtS(maxV), { x: chartX - 0.3, y: chartY, w: 1.2, h: 0.2, fontSize: 6, fontFace: h.FONT, color: C.neutral, align: "right" });
    slide.addText("S/ 0", { x: chartX - 0.3, y: chartY + chartH - 0.2, w: 1.2, h: 0.2, fontSize: 6, fontFace: h.FONT, color: C.neutral, align: "right" });

    // Bars
    const barW = chartW / 12 - 0.02;
    vals.forEach((v, i) => {
      const barH = maxV > 0 ? (v / maxV) * chartH : 0;
      const isPeak = v === maxV;
      slide.addShape(pres.shapes.RECTANGLE, {
        x: chartX + i * (barW + 0.02),
        y: chartY + chartH - barH,
        w: barW, h: Math.max(barH, 0.02),
        fill: { color: isPeak ? C.primary : C.secondary }
      });
      // Month label
      slide.addText(months[i].substring(0, 1), {
        x: chartX + i * (barW + 0.02), y: chartY + chartH + 0.02, w: barW, h: 0.2,
        fontSize: 5.5, fontFace: h.FONT, color: C.neutral, align: "center"
      });
    });

    // PE line (if available)
    if (ratios.punto_equilibrio) {
      const peMensual = ratios.punto_equilibrio / 12;
      const peY = chartY + chartH - (peMensual / maxV) * chartH;
      if (peY > chartY && peY < chartY + chartH) {
        slide.addShape(pres.shapes.LINE, {
          x: chartX, y: peY, w: chartW, h: 0,
          line: { color: C.negative, width: 1.5, dashType: "dash" }
        });
        slide.addText(`PE: ${h.fmtS(Math.round(peMensual))}`, {
          x: chartX + chartW - 2, y: peY - 0.2, w: 2, h: 0.2,
          fontSize: 6, fontFace: h.FONT, color: C.negative, align: "right"
        });
      }
    }
  }

  // ── PE ANALYSIS BOX ──
  if (ratios.punto_equilibrio && mode === "diagnostic") {
    const peBox = {
      pe: ratios.punto_equilibrio,
      ventas: data.egp.ventas_netas,
      cobertura: ratios.cobertura_pe_pct || 0,
      deficit: (ratios.punto_equilibrio - data.egp.ventas_netas) / 12,
    };

    slide.addShape(pres.shapes.RECTANGLE, {
      x: 9.0, y: 4.8, w: 4.13, h: 1.5,
      fill: { color: peBox.cobertura >= 100 ? C.successBg : C.dangerBg },
      shadow: h.makeShadow()
    });
    slide.addText("Punto de Equilibrio", {
      x: 9.15, y: 4.85, w: 3.8, h: 0.25,
      fontSize: 9, fontFace: h.FONT, color: C.primary, bold: true
    });
    slide.addText([
      { text: `PE Anual: ${h.fmtS(Math.round(peBox.pe))}\n`, options: { fontSize: 8, fontFace: h.FONT, color: C.darkText } },
      { text: `PE Mensual: ${h.fmtS(Math.round(peBox.pe / 12))}\n`, options: { fontSize: 8, fontFace: h.FONT, color: C.darkText } },
      { text: `Cobertura: ${h.pct1(peBox.cobertura)}\n`, options: { fontSize: 8, fontFace: h.FONT, color: peBox.cobertura >= 100 ? "1B5E20" : C.negative, bold: true } },
      { text: peBox.deficit > 0 ? `Déficit mensual: ${h.fmtS(Math.round(peBox.deficit))}` : "PE alcanzado ✅", options: { fontSize: 8, fontFace: h.FONT, color: peBox.deficit > 0 ? C.negative : "1B5E20" } },
    ], { x: 9.15, y: 5.1, w: 3.8, h: 1.1, valign: "top" });
  }

  h.addFooter(pres, slide,
    slideConfig.footer_text || (mode === "status"
      ? `Estructura financiera al ${data.periodo || "cierre"}.`
      : ratios.punto_equilibrio
        ? `La estacionalidad sugiere oportunidad de potenciar meses fuertes con eventos y promociones, mientras se contienen costos fijos en meses bajos.`
        : `Monitorear evolución de la composición de financiamiento. ${ratios.patrimonio < 0 ? "Priorizar capitalización." : ""}`),
    mode === "status" ? "informational" : (ratios.patrimonio < 0 ? "warning" : "normal")
  );
  h.addPageNum(slide, slideConfig.page_num);
};


/**
 * Draw a simple doughnut using shapes (pptxgenjs doesn't support native doughnuts well)
 * Uses stacked bars as visual proxy
 */
function drawDoughnut(pres, slide, segments, colors, x, y, w, h_chart, total, helpers) {
  const C = helpers.COLORS;
  // Legend + stacked horizontal bar as proxy for doughnut
  const barY = y + 0.3;
  const barH = 0.5;

  let currentX = x;
  segments.forEach((seg, i) => {
    const segW = (seg.val / total) * w;
    if (segW > 0.01) {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: currentX, y: barY, w: segW, h: barH,
        fill: { color: colors[i % colors.length] }
      });
      currentX += segW;
    }
  });

  // Legend items
  segments.forEach((seg, i) => {
    const legendY = barY + barH + 0.2 + i * 0.3;
    const pct = (seg.val / total * 100).toFixed(1);

    slide.addShape(pres.shapes.RECTANGLE, {
      x: x, y: legendY, w: 0.2, h: 0.2,
      fill: { color: colors[i % colors.length] }
    });
    slide.addText(`${seg.label}: ${helpers.fmtS(Math.round(seg.val))} (${pct}%)`, {
      x: x + 0.3, y: legendY - 0.02, w: w - 0.4, h: 0.25,
      fontSize: 7, fontFace: helpers.FONT, color: C.darkText
    });
  });
}
