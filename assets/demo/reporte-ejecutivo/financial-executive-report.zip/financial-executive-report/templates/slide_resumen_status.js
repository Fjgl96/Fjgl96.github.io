/**
 * slide_resumen_status.js — Resumen Ejecutivo (Status Mode)
 * 10 KPI cards with ↑↓ deltas vs prior period. NO stakeholder grid.
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const prev = ratios.anterior || {};

  h.addHeader(pres, slide, "Status Ejecutivo — Indicadores Clave");

  h.addSummaryBoxSimple(pres, slide,
    slideConfig.summary_text || `Resumen de indicadores al ${data.periodo || "cierre del periodo"}. Flechas indican variación vs periodo anterior.`
  );

  const deltaFor = (curr, prev, fmt) => {
    if (prev === undefined || prev === null) return null;
    if (fmt === "pct") return h.fmtDeltaPP(curr, prev);
    return h.fmtDelta(curr, prev);
  };

  const statusFor = (curr, prev, better) => {
    if (prev === undefined || prev === null) return "neutral";
    const d = curr - prev;
    const threshold = 0.3;
    if (better === "up") return d > threshold ? "up" : d < -threshold ? "down" : "stable";
    if (better === "down") return d < -threshold ? "up" : d > threshold ? "down" : "stable";
    return "stable";
  };

  // Row 1: 5 KPIs
  const kpis1 = [
    { label: "Ventas Netas", value: h.fmtS(data.egp.ventas_netas), delta: deltaFor(data.egp.ventas_netas, prev.ventas_netas_abs, "abs"), status: statusFor(data.egp.ventas_netas, prev.ventas_netas_abs, "up") },
    { label: "Margen Bruto", value: h.pct1(ratios.margen_bruto), delta: deltaFor(ratios.margen_bruto, prev.margen_bruto, "pct"), status: statusFor(ratios.margen_bruto, prev.margen_bruto, "up") },
    { label: "Margen Operativo", value: h.pct1(ratios.margen_operativo), delta: deltaFor(ratios.margen_operativo, prev.margen_operativo, "pct"), status: statusFor(ratios.margen_operativo, prev.margen_operativo, "up") },
    { label: "EBITDA", value: h.fmtS(ratios.ebitda), delta: deltaFor(ratios.ebitda, prev.ebitda, "abs"), status: statusFor(ratios.ebitda, prev.ebitda, "up") },
    { label: "Margen Neto", value: h.pct1(ratios.margen_neto), delta: deltaFor(ratios.margen_neto, prev.margen_neto, "pct"), status: statusFor(ratios.margen_neto, prev.margen_neto, "up") },
  ];

  kpis1.forEach((kpi, i) => {
    h.addKPICard(pres, slide, { ...kpi, x: 0.4 + i * 2.55, y: 1.45, w: 2.35, h: 1.2 });
  });

  // Row 2: 5 KPIs
  const kpis2 = [
    { label: "Ratio Corriente", value: h.fmtRatio(ratios.ratio_corriente), delta: deltaFor(ratios.ratio_corriente, prev.ratio_corriente, "abs"), status: statusFor(ratios.ratio_corriente, prev.ratio_corriente, "up") },
    { label: "Endeudamiento", value: h.pct1(ratios.endeudamiento), delta: deltaFor(ratios.endeudamiento, prev.endeudamiento, "pct"), status: statusFor(ratios.endeudamiento, prev.endeudamiento, "down") },
    { label: "ROA", value: h.pct1(ratios.roa), delta: deltaFor(ratios.roa, prev.roa, "pct"), status: statusFor(ratios.roa, prev.roa, "up") },
    { label: "Días Efectivo", value: `${(ratios.dias_cobertura || 0).toFixed(0)}d`, delta: deltaFor(ratios.dias_cobertura, prev.dias_cobertura, "abs"), status: statusFor(ratios.dias_cobertura, prev.dias_cobertura, "up") },
    { label: "CCE", value: `${(ratios.cce || 0).toFixed(0)}d`, delta: deltaFor(ratios.cce, prev.cce, "abs"), status: statusFor(ratios.cce, prev.cce, "down") },
  ];

  kpis2.forEach((kpi, i) => {
    h.addKPICard(pres, slide, { ...kpi, x: 0.4 + i * 2.55, y: 2.85, w: 2.35, h: 1.2 });
  });

  // Sector-specific KPIs Row 3 (if available)
  if (ratios.food_cost_pct !== undefined) {
    const kpis3 = [
      { label: "Food Cost %", value: h.pct1(ratios.food_cost_pct), delta: deltaFor(ratios.food_cost_pct, prev.food_cost_pct, "pct"), status: statusFor(ratios.food_cost_pct, prev.food_cost_pct, "down") },
      { label: "Labor Cost %", value: h.pct1(ratios.labor_cost_pct), delta: deltaFor(ratios.labor_cost_pct, prev.labor_cost_pct, "pct"), status: statusFor(ratios.labor_cost_pct, prev.labor_cost_pct, "down") },
      { label: "Prime Cost %", value: h.pct1(ratios.prime_cost_pct), delta: deltaFor(ratios.prime_cost_pct, prev.prime_cost_pct, "pct"), status: statusFor(ratios.prime_cost_pct, prev.prime_cost_pct, "down") },
      { label: "Cortesías %", value: h.pct1(ratios.cortesias_pct || 0), delta: deltaFor(ratios.cortesias_pct, prev.cortesias_pct, "pct"), status: statusFor(ratios.cortesias_pct, prev.cortesias_pct, "down") },
      { label: "Cobertura PE", value: h.pct1(ratios.cobertura_pe_pct || 0), delta: deltaFor(ratios.cobertura_pe_pct, prev.cobertura_pe_pct, "pct"), status: statusFor(ratios.cobertura_pe_pct, prev.cobertura_pe_pct, "up") },
    ];
    kpis3.forEach((kpi, i) => {
      h.addKPICard(pres, slide, { ...kpi, x: 0.4 + i * 2.55, y: 4.25, w: 2.35, h: 1.2 });
    });
  }

  // Footer - informational only
  h.addFooter(pres, slide,
    slideConfig.footer_text || `Indicadores al ${data.periodo || "cierre"}. Los deltas se calculan vs periodo inmediato anterior.`,
    "informational"
  );
  h.addPageNum(slide, slideConfig.page_num);
};
