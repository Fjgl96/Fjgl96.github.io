/**
 * slide_esf_activos.js — Estado de Situación Financiera: Activos
 * diagnostic: tabla absoluta + % vertical + 5 bullets interpretativos
 * status: tabla comparativa + 2-3 bullets factuales
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const mode = plan.mode;
  const ac = data.esf.activo_corriente;
  const anc = data.esf.activo_no_corriente;
  const totalA = data.esf.totales.activo;

  h.addHeader(pres, slide, "Estado de Situación Financiera — Activos");

  // Summary
  const acPct = (ac.total_ac / totalA * 100).toFixed(1);
  const ancPct = (anc.total_anc / totalA * 100).toFixed(1);
  const summaryText = slideConfig.summary_text || (mode === "status"
    ? `Activo total de ${h.fmtS(totalA)}. AC ${acPct}% vs ANC ${ancPct}%.`
    : `Activo total de ${h.fmtS(totalA)} concentrado ${ancPct}% en no corriente (IME). AC de ${h.fmtS(ac.total_ac)} (${acPct}%) con efectivo limitado.`);
  h.addSummaryBoxSimple(pres, slide, summaryText);

  // Build table rows
  const rows = [];
  if (mode === "status" && plan.periods >= 2) {
    rows.push(h.tableRow(["Concepto", "Actual S/", "Anterior S/", "Var S/", "Var %"], { isHeader: true }));
  } else {
    rows.push(h.tableRow(["Concepto", "S/", "% Activo"], { isHeader: true }));
  }

  // AC items
  rows.push(h.tableRow(["ACTIVO CORRIENTE", "", ""], { isSubtotal: true }));
  const acItems = [
    ["Efectivo y Equivalentes", ac.efectivo || 0],
    ["CxC Comerciales", ac.cxc_comerciales || 0],
    ["CxC Personal/Accionistas", (ac.cxc_personal || 0)],
    ["CxC Diversas", ac.cxc_diversas || 0],
    ["Gastos Anticipados", ac.gastos_anticipados || 0],
    ["Mercaderías", ac.mercaderias || 0],
    ["Suministros/Menajes", ac.suministros_menajes || 0],
  ];

  let idx = 0;
  acItems.forEach(([label, val]) => {
    if (val && Math.abs(val) > 0.5) {
      rows.push(h.tableRow(
        ["  " + label, h.fmtS(val), h.pct1(val / totalA * 100)],
        { altIdx: idx++ }
      ));
    }
  });
  rows.push(h.tableRow(["Total Activo Corriente", h.fmtS(ac.total_ac), h.pct1(ac.total_ac / totalA * 100)], { isSubtotal: true }));

  // ANC items
  rows.push(h.tableRow(["ACTIVO NO CORRIENTE", "", ""], { isSubtotal: true }));
  const ancItems = [
    ["IME Bruto", anc.ime_bruto || 0],
    ["Depreciación Acumulada", anc.depreciacion || 0],
    ["Intangibles", anc.intangibles || 0],
    ["Otras CxC No Corriente", anc.otras_cxc_nc || 0],
  ];
  ancItems.forEach(([label, val]) => {
    if (val && Math.abs(val) > 0.5) {
      rows.push(h.tableRow(
        ["  " + label, h.fmtS(val), h.pct1(val / totalA * 100)],
        { altIdx: idx++ }
      ));
    }
  });
  rows.push(h.tableRow(["Total Activo No Corriente", h.fmtS(anc.total_anc), h.pct1(anc.total_anc / totalA * 100)], { isSubtotal: true }));

  // TOTAL
  rows.push(h.tableRow(["TOTAL ACTIVO", h.fmtS(totalA), "100.0%"], { isTotal: true }));

  slide.addTable(rows, { x: 0.4, y: 1.5, w: 7.8, colW: [4.2, 2.0, 1.6], fontSize: 8.5, autoPage: false });

  // Bullets
  const bullets = slideConfig.bullets || generateActBullets(data, ratios, mode, h);
  h.addBullets(slide, bullets, 8.5, 1.5, 4.4, 4.8);

  // ── LIQUIDITY INSIGHT BOX (fills empty space) ──
  if (mode === "diagnostic") {
    const efectivo = ac.efectivo || 0;
    const preop = ac.gastos_anticipados || 0;
    const liquidezReal = ac.total_ac - preop;
    const diasCob = ratios.dias_cobertura || 0;

    const lines = [
      { text: `Liquidez efectiva: AC (${h.fmtS(ac.total_ac)}) − Preoperativos (${h.fmtS(preop)}) = ${h.fmtS(Math.round(liquidezReal))}  |  Días efectivo: ${diasCob.toFixed(0)} (benchmark: 30+)`, fontSize: 8, bold: true },
    ];
    if (ratios.capital_trabajo !== undefined) {
      const ct = ratios.capital_trabajo;
      lines.push({ text: `Capital de trabajo: ${h.fmtS(Math.round(ct))} (${ct > 0 ? "positivo — cubre obligaciones CP" : "negativo — riesgo de liquidez"})  |  Ratio corriente: ${(ratios.ratio_corriente || 0).toFixed(2)}x`, fontSize: 8 });
    }

    h.addInsightBox(pres, slide, {
      title: "Indicadores de Liquidez",
      lines: lines,
      x: 0.4, y: 5.2, w: 12.53, h: 0.85,
      bgColor: diasCob >= 30 ? h.COLORS.successBg : diasCob >= 15 ? h.COLORS.warningBg : h.COLORS.dangerBg
    });
  }

  // Footer
  const footerSeverity = mode === "status" ? "informational" : (ratios.dias_cobertura < 15 ? "warning" : "normal");
  h.addFooter(pres, slide,
    slideConfig.footer_text || (mode === "status"
      ? `Composición de activos al ${data.periodo || "cierre del periodo"}.`
      : `Evaluar liquidez real descontando gastos anticipados no líquidos. Días de efectivo: ${(ratios.dias_cobertura || 0).toFixed(0)}.`),
    footerSeverity
  );
  h.addPageNum(slide, slideConfig.page_num);
};

function generateActBullets(data, ratios, mode, h) {
  const ac = data.esf.activo_corriente;
  const totalA = data.esf.totales.activo;
  if (mode === "status") {
    return [
      `AC representa ${(ac.total_ac / totalA * 100).toFixed(1)}% del activo total.`,
      `Efectivo: ${h.fmtS(ac.efectivo || 0)} (${(ratios.dias_cobertura || 0).toFixed(0)} días de cobertura).`,
    ];
  }
  return [
    `Activo concentrado ${((data.esf.activo_no_corriente.total_anc / totalA) * 100).toFixed(1)}% en no corriente (inversión en IME).`,
    `Efectivo de ${(ac.efectivo || 0).toLocaleString("en-US", { maximumFractionDigits: 0 })} cubre ${(ratios.dias_cobertura || 0).toFixed(0)} días de operación (benchmark: 30+ días).`,
    `CxC comerciales de ${(ac.cxc_comerciales || 0).toLocaleString("en-US", { maximumFractionDigits: 0 })} indica cobranza rápida (${(ratios.per_cobro || 0).toFixed(0)} días).`,
    ac.gastos_anticipados > ac.total_ac * 0.10
      ? `Gastos anticipados S/ ${(ac.gastos_anticipados || 0).toLocaleString("en-US", { maximumFractionDigits: 0 })} (${(ac.gastos_anticipados / ac.total_ac * 100).toFixed(1)}% del AC) no son líquidos — distorsionan liquidez.`
      : `Inventarios (mercaderías + suministros) de S/ ${((ac.mercaderias || 0) + (ac.suministros_menajes || 0)).toLocaleString("en-US", { maximumFractionDigits: 0 })} con rotación adecuada.`,
    `Capital de trabajo: S/ ${(ratios.capital_trabajo || 0).toLocaleString("en-US", { maximumFractionDigits: 0 })} (${ratios.capital_trabajo > 0 ? "positivo" : "negativo"}).`,
  ];
}
