/**
 * slide_ratios.js — Ratios Financieros
 * diagnostic: heatmap table vs benchmarks sectoriales (verde/ámbar/rojo)
 * status: table with ↑↓ arrows vs periodo anterior
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const mode = plan.mode;

  h.addHeader(pres, slide, mode === "status" ? "Ratios Financieros — Evolución" : "Ratios Financieros — Benchmarks Sectoriales");

  h.addSummaryBoxSimple(pres, slide,
    slideConfig.summary_text || (mode === "status"
      ? `Indicadores financieros comparados con el periodo anterior.`
      : `Indicadores evaluados contra benchmarks del sector ${plan.sector}. Verde = favorable, Ámbar = precaución, Rojo = alerta.`)
  );

  const rows = [];

  if (mode === "diagnostic") {
    rows.push(h.tableRow(["Indicador", "Valor", "Benchmark", "Evaluación"], { isHeader: true }));

    const sections = [
      { title: "LIQUIDEZ", items: [
        { name: "Ratio Corriente", val: h.fmtRatio(ratios.ratio_corriente), bench: "> 1.20x", status: ratios.ratio_corriente >= 1.2 ? "good" : ratios.ratio_corriente >= 0.8 ? "warning" : "danger" },
        { name: "Prueba Ácida", val: h.fmtRatio(ratios.prueba_acida), bench: "> 0.60x", status: ratios.prueba_acida >= 0.6 ? "good" : ratios.prueba_acida >= 0.4 ? "warning" : "danger" },
        { name: "Capital de Trabajo", val: h.fmtS(ratios.capital_trabajo), bench: "> 0", status: ratios.capital_trabajo > 0 ? "good" : "danger" },
        { name: "Días Cobertura Efectivo", val: `${(ratios.dias_cobertura || 0).toFixed(0)} días`, bench: "> 30 días", status: ratios.dias_cobertura >= 30 ? "good" : ratios.dias_cobertura >= 15 ? "warning" : "danger" },
      ]},
      { title: "SOLVENCIA", items: [
        { name: "Endeudamiento", val: h.pct1(ratios.endeudamiento), bench: "< 70%", status: ratios.endeudamiento <= 70 ? "good" : ratios.endeudamiento <= 100 ? "warning" : "danger" },
        { name: "D/E Ratio", val: ratios.de_ratio !== null ? h.fmtRatio(ratios.de_ratio) : "N/A", bench: "< 2.0x", status: ratios.de_ratio === null ? "neutral" : ratios.de_ratio <= 2 ? "good" : "danger" },
        { name: "Concentración CP", val: h.pct1(ratios.concentracion_cp), bench: "< 60%", status: ratios.concentracion_cp <= 60 ? "good" : "warning" },
      ]},
      { title: "RENTABILIDAD", items: [
        { name: "Margen Bruto", val: h.pct1(ratios.margen_bruto), bench: "> 55%", status: ratios.margen_bruto >= 55 ? "good" : ratios.margen_bruto >= 45 ? "warning" : "danger" },
        { name: "Margen Operativo", val: h.pct1(ratios.margen_operativo), bench: "> 5%", status: ratios.margen_operativo >= 5 ? "good" : ratios.margen_operativo >= 0 ? "warning" : "danger" },
        { name: "Margen Neto", val: h.pct1(ratios.margen_neto), bench: "> 3%", status: ratios.margen_neto >= 3 ? "good" : ratios.margen_neto >= 0 ? "warning" : "danger" },
        { name: "ROA", val: h.pct1(ratios.roa), bench: "> 5%", status: ratios.roa >= 5 ? "good" : ratios.roa >= 0 ? "warning" : "danger" },
      ]},
      { title: "EFICIENCIA", items: [
        { name: "Rotación Inventarios", val: `${(ratios.rot_inventarios || 0).toFixed(1)}x`, bench: "> 12x", status: (ratios.rot_inventarios || 0) >= 12 ? "good" : "warning" },
        { name: "Período de Cobro", val: `${(ratios.per_cobro || 0).toFixed(0)} días`, bench: "< 7 días", status: (ratios.per_cobro || 0) <= 7 ? "good" : "warning" },
        { name: "Período de Pago", val: `${(ratios.per_pago || 0).toFixed(0)} días`, bench: "30-60 días", status: (ratios.per_pago || 0) <= 60 ? "good" : "warning" },
        { name: "CCE", val: `${(ratios.cce || 0).toFixed(0)} días`, bench: "< 30 días", status: (ratios.cce || 0) <= 30 ? "good" : "warning" },
      ]},
    ];

    let altIdx = 0;
    sections.forEach(section => {
      // Section header
      rows.push([
        { text: section.title, options: { fill: { color: C.subtotalBg }, color: C.primary, bold: true, fontSize: 8.5, fontFace: h.FONT, align: "left", colspan: 4, border: h.BORDER_STYLE } },
      ]);
      section.items.forEach(item => {
        rows.push(h.ratioRow([item.name, item.val, item.bench, ""], item.status, altIdx++));
      });
    });

  } else {
    // Status mode: delta table
    rows.push(h.tableRow(["Indicador", "Actual", "Anterior", "Variación"], { isHeader: true }));
    // Simplified - Claude fills these
    const items = [
      ["Ratio Corriente", h.fmtRatio(ratios.ratio_corriente)],
      ["Margen Bruto", h.pct1(ratios.margen_bruto)],
      ["Margen Operativo", h.pct1(ratios.margen_operativo)],
      ["Margen Neto", h.pct1(ratios.margen_neto)],
      ["Endeudamiento", h.pct1(ratios.endeudamiento)],
      ["ROA", h.pct1(ratios.roa)],
    ];
    items.forEach((item, i) => {
      rows.push(h.tableRow([item[0], item[1], "-", "-"], { altIdx: i }));
    });
  }

  slide.addTable(rows, {
    x: 0.4, y: 1.5, w: 12.53,
    colW: mode === "diagnostic" ? [4.0, 2.5, 2.5, 3.53] : [4.0, 2.5, 3.0, 3.03],
    fontSize: 8.5, autoPage: false
  });

  // Distortion notes
  const distortionNotes = plan.distortions.filter(d => d.severity === "critical" || d.severity === "warning");
  if (distortionNotes.length > 0 && mode === "diagnostic") {
    const noteText = distortionNotes.map(d => `⚠️ ${d.note}`).join(" | ");
    slide.addText(noteText, {
      x: 0.4, y: 6.15, w: 12.53, h: 0.3,
      fontSize: 7, fontFace: h.FONT, color: C.negative, italic: true
    });
  }

  h.addFooter(pres, slide,
    slideConfig.footer_text || (mode === "status"
      ? `Ratios calculados al ${data.periodo || "cierre"}.`
      : `Benchmarks corresponden al sector ${plan.sector} en ${plan.country === "peru" ? "Perú" : plan.country}. Ratios distorsionados señalados con ⚠️.`),
    mode === "status" ? "informational" : "normal"
  );
  h.addPageNum(slide, slideConfig.page_num);
};
