/**
 * slide_conclusiones.js — Conclusiones y Recomendaciones
 *
 * MODE: diagnostic ONLY. Never generated in status mode.
 *
 * Structure: 3 blocks
 *   - HALLAZGOS (gray bg) — key findings with implications
 *   - RIESGOS (red bg) — IF condition → THEN impact
 *   - PRIORIDADES (green bg, 3 columns) — Urgent | Medium | Structural
 */

module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;

  h.addHeader(pres, slide, "Conclusiones y Recomendaciones");

  // Summary box
  const summaryText = slideConfig.summary_text ||
    `Diagnóstico general: severidad ${plan.severity}. Se identificaron ${plan.alerts.length} alertas y ${plan.distortions.length} distorsiones en los indicadores.`;
  h.addSummaryBoxSimple(pres, slide, summaryText);

  // ── HALLAZGOS ──
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0.4, y: 1.35, w: 12.53, h: 1.5,
    fill: { color: C.lightGray }, shadow: h.makeShadow()
  });
  slide.addText("HALLAZGOS PRINCIPALES", {
    x: 0.6, y: 1.38, w: 5, h: 0.25,
    fontSize: 9, fontFace: h.FONT, color: C.primary, bold: true
  });

  const hallazgos = slideConfig.hallazgos || [
    "Hallazgo 1 — dato + implicación.",
    "Hallazgo 2 — dato + implicación.",
    "Hallazgo 3 — dato + implicación.",
  ];
  const hallazgoItems = hallazgos.map((t, i) => ({
    text: t,
    options: {
      bullet: true, breakLine: i < hallazgos.length - 1,
      fontSize: 8, fontFace: h.FONT, color: C.darkText, paraSpaceAfter: 3
    }
  }));
  slide.addText(hallazgoItems, { x: 0.6, y: 1.6, w: 12.1, h: 1.2, valign: "top" });

  // ── RIESGOS ──
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0.4, y: 3.0, w: 12.53, h: 1.2,
    fill: { color: C.dangerBg }, shadow: h.makeShadow()
  });
  slide.addText("RIESGOS IDENTIFICADOS", {
    x: 0.6, y: 3.03, w: 5, h: 0.25,
    fontSize: 9, fontFace: h.FONT, color: C.negative, bold: true
  });

  const riesgos = slideConfig.riesgos || plan.alerts.map(a =>
    `SI ${a.description.split(".")[0].toLowerCase()} → ${a.action || "evaluar impacto"}.`
  );
  const riesgoItems = riesgos.map((t, i) => ({
    text: t,
    options: {
      bullet: true, breakLine: i < riesgos.length - 1,
      fontSize: 8, fontFace: h.FONT, color: C.darkText, paraSpaceAfter: 3
    }
  }));
  slide.addText(riesgoItems, { x: 0.6, y: 3.25, w: 12.1, h: 0.9, valign: "top" });

  // ── PRIORIDADES (3 columnas) ──
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0.4, y: 4.4, w: 12.53, h: 2.0,
    fill: { color: C.successBg }, shadow: h.makeShadow()
  });
  slide.addText("PRIORIDADES DE ACCIÓN", {
    x: 0.6, y: 4.43, w: 5, h: 0.25,
    fontSize: 9, fontFace: h.FONT, color: "1B5E20", bold: true
  });

  const columns = [
    { title: "URGENTE (0-3 meses)", color: C.negative, x: 0.6, items: slideConfig.urgente || ["Acción urgente 1", "Acción urgente 2"] },
    { title: "MEDIANO PLAZO (3-6 meses)", color: "B8860B", x: 4.8, items: slideConfig.mediano || ["Acción mediano 1", "Acción mediano 2"] },
    { title: "ESTRUCTURAL (6-12 meses)", color: "1B5E20", x: 9.0, items: slideConfig.estructural || ["Acción estructural 1", "Acción estructural 2"] },
  ];

  columns.forEach(col => {
    slide.addText(col.title, {
      x: col.x, y: 4.7, w: 3.8, h: 0.2,
      fontSize: 8, fontFace: h.FONT, color: col.color, bold: true
    });
    const items = col.items.map((t, i) => ({
      text: t,
      options: {
        bullet: true, breakLine: i < col.items.length - 1,
        fontSize: 7.5, fontFace: h.FONT, color: C.darkText, paraSpaceAfter: 2
      }
    }));
    slide.addText(items, { x: col.x, y: 4.9, w: 3.8, h: 1.4, valign: "top" });
  });

  h.addPageNum(slide, slideConfig.page_num);
};
