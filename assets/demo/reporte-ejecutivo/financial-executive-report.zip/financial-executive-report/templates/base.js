/**
 * templates/base.js — Shared helpers for all slide templates
 * Financial Executive Report V4
 *
 * NEVER modify this file per-report. These are invariant helpers.
 */

// ════════════════════════════════════════════════════════════
// COLOR PALETTE (hex WITHOUT #)
// ════════════════════════════════════════════════════════════
const COLORS = {
  primary:    "0B5394",
  secondary:  "1B7F9B",
  negative:   "CC0000",
  warning:    "FFC107",
  neutral:    "6C757D",
  white:      "FFFFFF",
  darkText:   "2D3748",
  lightGray:  "F2F4F6",
  altRow:     "F8F9FA",
  subtotalBg: "E8E8E8",
  summaryBox: "EBF2FA",
  dangerBg:   "F8D7DA",
  warningBg:  "FFF3CD",
  successBg:  "D1E7DD",
  portadaAccent: "A8C4E0",
  portadaMuted:  "7BA3CC",
};

const FONT = "Calibri";

// ════════════════════════════════════════════════════════════
// NUMBER FORMATTING
// ════════════════════════════════════════════════════════════
function fmt(n) {
  if (n === null || n === undefined) return "-";
  const abs = Math.abs(n);
  const s = abs >= 1000
    ? abs.toLocaleString("en-US", { maximumFractionDigits: 0 })
    : abs.toFixed(0);
  return n < 0 ? `-${s}` : s;
}

function fmtS(n, moneda = "S/") {
  return `${moneda} ${fmt(n)}`;
}

function pct1(n) {
  if (n === null || n === undefined) return "-";
  return `${n.toFixed(1)}%`;
}

function fmtRatio(n) {
  if (n === null || n === undefined) return "N/A";
  return `${n.toFixed(2)}x`;
}

function fmtDelta(current, previous) {
  if (previous === null || previous === undefined || previous === 0) return "-";
  const delta = ((current - previous) / Math.abs(previous)) * 100;
  const arrow = delta > 0.5 ? "↑" : delta < -0.5 ? "↓" : "→";
  return `${arrow} ${delta >= 0 ? "+" : ""}${delta.toFixed(1)}%`;
}

function fmtDeltaPP(current, previous) {
  if (previous === null || previous === undefined) return "-";
  const delta = current - previous;
  const arrow = delta > 0.3 ? "↑" : delta < -0.3 ? "↓" : "→";
  return `${arrow} ${delta >= 0 ? "+" : ""}${delta.toFixed(1)} pp`;
}

// ════════════════════════════════════════════════════════════
// SHADOW FACTORY (never reuse shadow objects in pptxgenjs)
// ════════════════════════════════════════════════════════════
function makeShadow() {
  return { type: "outer", color: "000000", blur: 4, offset: 2, angle: 135, opacity: 0.10 };
}

// ════════════════════════════════════════════════════════════
// SLIDE STRUCTURE HELPERS
// ════════════════════════════════════════════════════════════
function addHeader(pres, slide, title) {
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 0, w: 13.33, h: 0.6,
    fill: { color: COLORS.primary }
  });
  slide.addText(title, {
    x: 0.4, y: 0.05, w: 12, h: 0.5,
    fontSize: 14, fontFace: FONT, color: COLORS.white, bold: true
  });
}

function addSummaryBoxSimple(pres, slide, text) {
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0.4, y: 0.75, w: 12.53, h: 0.55,
    fill: { color: COLORS.summaryBox },
    shadow: makeShadow()
  });
  slide.addText(text, {
    x: 0.55, y: 0.78, w: 12.2, h: 0.5,
    fontSize: 9.5, fontFace: FONT, color: COLORS.darkText, italic: true
  });
}

/**
 * Insight Box — fills the gap between content and footer
 * Use for EBITDA breakdown, composition bars, key metric highlights
 * Positioned just above the footer zone
 */
function addInsightBox(pres, slide, { title, lines, x, y, w, h, bgColor }) {
  const bg = bgColor || COLORS.lightGray;
  slide.addShape(pres.shapes.RECTANGLE, {
    x: x || 0.4, y: y || 5.3, w: w || 12.53, h: h || 1.0,
    fill: { color: bg },
    shadow: makeShadow()
  });
  if (title) {
    slide.addText(title, {
      x: (x || 0.4) + 0.15, y: (y || 5.3) + 0.05, w: (w || 12.53) - 0.3, h: 0.25,
      fontSize: 9, fontFace: FONT, color: COLORS.primary, bold: true
    });
  }
  if (lines && lines.length > 0) {
    const textItems = lines.map((line, i) => ({
      text: typeof line === 'string' ? line : line.text,
      options: {
        fontSize: (line && line.fontSize) || 8,
        fontFace: FONT,
        color: (line && line.color) || COLORS.darkText,
        bold: (line && line.bold) || false,
        breakLine: i < lines.length - 1,
      }
    }));
    slide.addText(textItems, {
      x: (x || 0.4) + 0.15, y: (y || 5.3) + (title ? 0.3 : 0.08),
      w: (w || 12.53) - 0.3, h: (h || 1.0) - (title ? 0.4 : 0.15),
      valign: "top"
    });
  }
}

function addFooter(pres, slide, text, severity) {
  const colorMap = {
    normal: COLORS.neutral,
    informational: COLORS.neutral,
    warning: "B8860B",
    critical: COLORS.negative,
    positive: COLORS.primary,
    sano: COLORS.neutral,
    riesgo: "B8860B",
    critico: COLORS.negative,
  };
  const bgMap = {
    normal: COLORS.lightGray,
    informational: COLORS.lightGray,
    warning: COLORS.warningBg,
    critical: COLORS.dangerBg,
    positive: COLORS.successBg,
    sano: COLORS.lightGray,
    riesgo: COLORS.warningBg,
    critico: COLORS.dangerBg,
  };

  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0.4, y: 6.5, w: 12.53, h: 0.55,
    fill: { color: bgMap[severity] || COLORS.lightGray }
  });
  slide.addText(text, {
    x: 0.55, y: 6.52, w: 12.2, h: 0.5,
    fontSize: 8.5, fontFace: FONT,
    color: colorMap[severity] || COLORS.neutral,
    italic: true
  });
}

function addPageNum(slide, num) {
  slide.addText(String(num), {
    x: 12.4, y: 6.95, w: 0.6, h: 0.3,
    fontSize: 8, fontFace: FONT, color: COLORS.neutral, align: "right"
  });
}

// ════════════════════════════════════════════════════════════
// TABLE HELPERS
// ════════════════════════════════════════════════════════════
const BORDER_STYLE = [
  { pt: 0.3, color: "D0D0D0" },
  { pt: 0.3, color: "D0D0D0" },
  { pt: 0.3, color: "D0D0D0" },
  { pt: 0.3, color: "D0D0D0" }
];

function tableRow(cells, opts = {}) {
  const { isHeader, isSubtotal, isTotal, altIdx } = opts;
  let fill, color, bold;

  if (isHeader) {
    fill = COLORS.primary; color = COLORS.white; bold = true;
  } else if (isTotal) {
    fill = COLORS.primary; color = COLORS.white; bold = true;
  } else if (isSubtotal) {
    fill = COLORS.subtotalBg; color = COLORS.darkText; bold = true;
  } else {
    fill = altIdx % 2 === 0 ? COLORS.white : COLORS.altRow;
    color = COLORS.darkText;
    bold = false;
  }

  return cells.map((c, i) => ({
    text: String(c),
    options: {
      fill: { color: fill }, color, bold,
      fontSize: isHeader ? 9 : 8.5, fontFace: FONT,
      align: i === 0 ? "left" : "right",
      border: BORDER_STYLE
    }
  }));
}

function ratioRow(cells, status, altIdx) {
  const statusColors = {
    good: COLORS.successBg,
    warning: COLORS.warningBg,
    danger: COLORS.dangerBg,
    neutral: COLORS.lightGray
  };
  const bg = statusColors[status] || (altIdx % 2 === 0 ? COLORS.white : COLORS.altRow);

  return cells.map((c, i) => ({
    text: String(c),
    options: {
      fill: { color: i >= 1 ? bg : (altIdx % 2 === 0 ? COLORS.white : COLORS.altRow) },
      color: COLORS.darkText, bold: false,
      fontSize: 8.5, fontFace: FONT,
      align: i === 0 ? "left" : "right",
      border: BORDER_STYLE
    }
  }));
}

// ════════════════════════════════════════════════════════════
// BULLET HELPERS
// ════════════════════════════════════════════════════════════
function addBullets(slide, bullets, x, y, w, h) {
  const textItems = bullets.map((b, i) => ({
    text: b,
    options: {
      bullet: true,
      breakLine: i < bullets.length - 1,
      fontSize: 8.5, fontFace: FONT, color: COLORS.darkText,
      paraSpaceAfter: 6
    }
  }));
  slide.addText(textItems, { x, y, w, h, valign: "top" });
}

// ════════════════════════════════════════════════════════════
// KPI CARD HELPER
// ════════════════════════════════════════════════════════════
function addKPICard(pres, slide, { label, value, status, delta, x, y, w, h }) {
  const statusColors = {
    good: COLORS.successBg,
    warning: COLORS.warningBg,
    danger: COLORS.dangerBg,
    neutral: COLORS.lightGray,
    up: COLORS.successBg,
    down: COLORS.dangerBg,
    stable: COLORS.lightGray,
  };

  const cardW = w || 2.25;
  const cardH = h || 1.1;

  slide.addShape(pres.shapes.RECTANGLE, {
    x, y, w: cardW, h: cardH,
    fill: { color: statusColors[status] || COLORS.lightGray },
    shadow: makeShadow()
  });
  slide.addText(label, {
    x, y: y + 0.08, w: cardW, h: 0.3,
    fontSize: 8, fontFace: FONT, color: COLORS.neutral, align: "center"
  });
  slide.addText(value, {
    x, y: y + 0.35, w: cardW, h: 0.45,
    fontSize: 17, fontFace: FONT, color: COLORS.darkText, bold: true, align: "center"
  });

  // Delta line (mode status)
  if (delta) {
    const deltaColor = delta.startsWith("↑") ? "2E7D32" : delta.startsWith("↓") ? COLORS.negative : COLORS.neutral;
    slide.addText(delta, {
      x, y: y + cardH - 0.25, w: cardW, h: 0.2,
      fontSize: 7, fontFace: FONT, color: deltaColor, align: "center"
    });
  }
}

// ════════════════════════════════════════════════════════════
// STAKEHOLDER BOX HELPER
// ════════════════════════════════════════════════════════════
function addStakeholderBox(pres, slide, { title, text, bg, x, y, w, h }) {
  slide.addShape(pres.shapes.RECTANGLE, {
    x, y, w, h, fill: { color: bg }, shadow: makeShadow()
  });
  slide.addText(title, {
    x: x + 0.1, y: y + 0.05, w: w - 0.2, h: 0.3,
    fontSize: 8, fontFace: FONT, color: COLORS.primary, bold: true
  });
  slide.addText(text, {
    x: x + 0.1, y: y + 0.35, w: w - 0.2, h: h - 0.45,
    fontSize: 7, fontFace: FONT, color: COLORS.darkText, valign: "top"
  });
}

// ════════════════════════════════════════════════════════════
// EXPORTS
// ════════════════════════════════════════════════════════════
module.exports = {
  COLORS,
  FONT,
  fmt, fmtS, pct1, fmtRatio, fmtDelta, fmtDeltaPP,
  makeShadow,
  addHeader, addSummaryBoxSimple, addFooter, addPageNum,
  addInsightBox,
  tableRow, ratioRow, BORDER_STYLE,
  addBullets,
  addKPICard,
  addStakeholderBox,
};
