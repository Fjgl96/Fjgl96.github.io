/**
 * slide_resumen_diagnostic.js — Resumen Ejecutivo (Diagnostic Mode)
 * 10 KPI cards (2 rows × 5) + 4 stakeholder boxes
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;

  h.addHeader(pres, slide, "Resumen Ejecutivo — Diagnóstico");

  // Summary box
  const sev = plan.severity;
  const sevLabel = sev === "critico" ? "CRÍTICO" : sev === "riesgo" ? "EN RIESGO" : "SANO";
  const sevBg = sev === "critico" ? C.dangerBg : sev === "riesgo" ? C.warningBg : C.successBg;
  h.addSummaryBoxSimple(pres, slide,
    slideConfig.summary_text || `Estado general: ${sevLabel}. ${plan.alerts.length} alertas activas, ${plan.distortions.length} distorsiones detectadas.`
  );

  // ── KPI CARDS: Row 1 (5 cards) ──
  const kpis_r1 = [
    { label: "Ventas Netas", value: h.fmtS(data.egp.ventas_netas), status: "neutral" },
    { label: "Margen Bruto", value: h.pct1(ratios.margen_bruto), status: ratios.margen_bruto >= 55 ? "good" : ratios.margen_bruto >= 45 ? "warning" : "danger" },
    { label: "Margen Operativo", value: h.pct1(ratios.margen_operativo), status: ratios.margen_operativo > 0 ? "good" : ratios.margen_operativo > -10 ? "warning" : "danger" },
    { label: "EBITDA", value: h.fmtS(ratios.ebitda), status: ratios.ebitda > 0 ? "good" : "danger" },
    { label: "Margen Neto", value: h.pct1(ratios.margen_neto), status: ratios.margen_neto > 0 ? "good" : "danger" },
  ];
  kpis_r1.forEach((kpi, i) => {
    h.addKPICard(pres, slide, { ...kpi, x: 0.4 + i * 2.55, y: 1.45, w: 2.35, h: 1.0 });
  });

  // ── KPI CARDS: Row 2 (5 cards) ──
  const kpis_r2 = [
    { label: "Ratio Corriente", value: h.fmtRatio(ratios.ratio_corriente), status: ratios.ratio_corriente >= 1.2 ? "good" : ratios.ratio_corriente >= 0.8 ? "warning" : "danger" },
    { label: "Endeudamiento", value: h.pct1(ratios.endeudamiento), status: ratios.endeudamiento <= 70 ? "good" : ratios.endeudamiento <= 100 ? "warning" : "danger" },
    { label: "ROA", value: h.pct1(ratios.roa), status: ratios.roa > 5 ? "good" : ratios.roa > 0 ? "warning" : "danger" },
    { label: "Cobertura PE", value: h.pct1(ratios.cobertura_pe_pct || 0), status: (ratios.cobertura_pe_pct || 0) >= 100 ? "good" : (ratios.cobertura_pe_pct || 0) >= 80 ? "warning" : "danger" },
    { label: "Patrimonio", value: h.fmtS(ratios.patrimonio), status: ratios.patrimonio > 0 ? "good" : "danger" },
  ];
  kpis_r2.forEach((kpi, i) => {
    h.addKPICard(pres, slide, { ...kpi, x: 0.4 + i * 2.55, y: 2.6, w: 2.35, h: 1.0 });
  });

  // ── STAKEHOLDER BOXES (4 columns) ──
  const stakeholders = slideConfig.stakeholders || [
    { title: "CEO — ¿Es viable?", text: plan.severity === "critico" ? "La operación no es viable en su estructura actual. Pérdidas operativas sostenidas requieren reestructuración." : "La operación es viable pero requiere ajustes en estructura de costos.", bg: C.lightGray },
    { title: "CFO — ¿Cuánto riesgo?", text: `Patrimonio ${ratios.patrimonio < 0 ? "negativo" : "positivo"}. Endeudamiento ${h.pct1(ratios.endeudamiento)}. Liquidez ${ratios.ratio_corriente >= 1 ? "adecuada" : "insuficiente"}.`, bg: C.lightGray },
    { title: "Dir. Comercial — ¿Costos?", text: ratios.food_cost_pct ? `Food cost ${h.pct1(ratios.food_cost_pct)} vs benchmark 38%. Prime cost ${h.pct1(ratios.prime_cost_pct)}.` : `Costo de ventas representa ${h.pct1(ratios.margen_bruto ? 100 - ratios.margen_bruto : 0)} de ingresos.`, bg: C.lightGray },
    { title: "Directorio — ¿Cumplimos?", text: plan.alerts.length > 0 ? plan.alerts[0].description.substring(0, 120) + "..." : "Sin alertas regulatorias activas.", bg: plan.alerts.length > 0 ? C.dangerBg : C.successBg },
  ];

  stakeholders.forEach((s, i) => {
    h.addStakeholderBox(pres, slide, {
      ...s, x: 0.4 + i * 3.2, y: 3.85, w: 3.0, h: 2.45
    });
  });

  h.addPageNum(slide, slideConfig.page_num);
};
