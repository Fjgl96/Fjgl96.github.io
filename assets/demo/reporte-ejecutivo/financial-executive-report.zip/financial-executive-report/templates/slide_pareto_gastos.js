/**
 * slide_pareto_gastos.js — Pareto de Gastos (Conditional slide)
 * Only generated when has_cost_detail = true in diagnostic mode
 * Shows top expense categories ranked by size
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const v = data.egp.ventas_netas;

  h.addHeader(pres, slide, "Análisis Pareto — Principales Partidas de Gasto");

  h.addSummaryBoxSimple(pres, slide,
    slideConfig.summary_text || `Los gastos operativos totalizan ${h.fmtS(Math.round(data.egp.gastos_restaurante + data.egp.gastos_admin))} (${h.pct1((data.egp.gastos_restaurante + data.egp.gastos_admin) / v * 100)} de ventas). El 80% se concentra en pocas partidas identificables.`
  );

  // Collect all expense items
  const allGastos = [];
  const gRest = data.complementary.gastos_restaurante_detalle || {};
  const gAdmin = data.complementary.gastos_admin_detalle || {};

  Object.entries(gRest).forEach(([k, val]) => {
    allGastos.push({ label: `Rest: ${k.replace(/_/g, " ")}`, value: val, area: "restaurante" });
  });
  Object.entries(gAdmin).forEach(([k, val]) => {
    allGastos.push({ label: `Admin: ${k.replace(/_/g, " ")}`, value: val, area: "admin" });
  });

  // If no sub-detail, use main lines
  if (allGastos.length === 0) {
    allGastos.push({ label: "Gastos Restaurante", value: data.egp.gastos_restaurante, area: "restaurante" });
    allGastos.push({ label: "Gastos Administrativos", value: data.egp.gastos_admin, area: "admin" });
  }

  // Sort descending
  allGastos.sort((a, b) => b.value - a.value);

  // Table
  const rows = [];
  rows.push(h.tableRow(["#", "Partida", "S/", "% Ventas", "% Acum."], { isHeader: true }));

  let acum = 0;
  const totalGastos = allGastos.reduce((s, g) => s + g.value, 0);

  allGastos.slice(0, 12).forEach((g, i) => {
    acum += g.value;
    const pctVtas = g.value / v * 100;
    const pctAcum = acum / totalGastos * 100;
    const status = pctAcum <= 80 ? "danger" : "neutral";

    rows.push(h.ratioRow(
      [String(i + 1), g.label, h.fmtS(Math.round(g.value)), h.pct1(pctVtas), h.pct1(pctAcum)],
      i < 3 ? "danger" : (pctAcum <= 80 ? "warning" : "neutral"),
      i
    ));
  });

  rows.push(h.tableRow(
    ["", "TOTAL GASTOS", h.fmtS(Math.round(totalGastos)), h.pct1(totalGastos / v * 100), "100.0%"],
    { isTotal: true }
  ));

  slide.addTable(rows, {
    x: 0.4, y: 1.5, w: 8.0, colW: [0.5, 3.5, 1.5, 1.2, 1.3],
    fontSize: 8.5, autoPage: false
  });

  // Bullets (right side)
  const top3Total = allGastos.slice(0, 3).reduce((s, g) => s + g.value, 0);
  const bullets = slideConfig.bullets || [
    `Las 3 principales partidas concentran ${h.pct1(top3Total / totalGastos * 100)} del gasto total.`,
    `Gasto total en personal: repartido entre restaurante y administración. Evaluar eficiencia de headcount.`,
    `Servicios de terceros: partida con mayor margen de negociación inmediata.`,
    `El 80% del gasto proviene de las primeras ${allGastos.findIndex((_, i) => allGastos.slice(0, i + 1).reduce((s, g) => s + g.value, 0) / totalGastos >= 0.80) + 1} partidas.`,
  ];

  h.addBullets(slide, bullets, 8.7, 1.5, 4.3, 4.5);

  h.addFooter(pres, slide,
    slideConfig.footer_text || `Pareto de gastos: enfocar esfuerzo de reducción en las partidas de mayor incidencia (sombreadas en rojo/ámbar).`,
    "normal"
  );
  h.addPageNum(slide, slideConfig.page_num);
};
