/**
 * slide_esf_pasivo.js — ESF: Pasivo y Patrimonio
 * diagnostic: tabla + bullets interpretativos + alerta legal si aplica
 * status: tabla comparativa + bullets factuales
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const mode = plan.mode;
  const pc = data.esf.pasivo_corriente;
  const pnc = data.esf.pasivo_no_corriente;
  const pat = data.esf.patrimonio;
  const totalPP = data.esf.totales.pasivo_patrimonio;
  const totalPasivo = pc.total_pc + pnc.total_pnc;

  h.addHeader(pres, slide, "Estado de Situación Financiera — Pasivo y Patrimonio");

  const patNeg = pat.total_patrimonio < 0;
  const summaryText = slideConfig.summary_text || (mode === "status"
    ? `Financiamiento total ${h.fmtS(totalPP)}. Pasivo ${h.pct1(totalPasivo / totalPP * 100)} vs Patrimonio ${h.pct1(pat.total_patrimonio / totalPP * 100)}.`
    : patNeg
      ? `Patrimonio negativo de ${h.fmtS(pat.total_patrimonio)} indica que las pérdidas acumuladas han consumido el capital. La empresa opera con financiamiento 100% de terceros y accionistas.`
      : `Financiamiento total ${h.fmtS(totalPP)}. Endeudamiento de ${h.pct1(ratios.endeudamiento)}.`);
  h.addSummaryBoxSimple(pres, slide, summaryText);

  // Table
  const rows = [];
  rows.push(h.tableRow(["Concepto", "S/", "% P+P"], { isHeader: true }));

  // PC
  rows.push(h.tableRow(["PASIVO CORRIENTE", "", ""], { isSubtotal: true }));
  let idx = 0;
  const pcItems = [
    ["Sobregiros Bancarios", pc.sobregiros],
    ["Tributos por Pagar", pc.tributos_pagar],
    ["Remuneraciones por Pagar", pc.remuneraciones_pagar],
    ["CxP Comerciales", pc.cxp_comerciales],
    ["CxP Relacionadas", pc.cxp_relacionadas],
    ["CxP Diversas", pc.cxp_diversas],
    ["Provisiones", pc.provisiones],
  ];
  pcItems.forEach(([label, val]) => {
    if (val && Math.abs(val) > 0.5) {
      rows.push(h.tableRow(["  " + label, h.fmtS(val), h.pct1(val / totalPP * 100)], { altIdx: idx++ }));
    }
  });
  rows.push(h.tableRow(["Total Pasivo Corriente", h.fmtS(pc.total_pc), h.pct1(pc.total_pc / totalPP * 100)], { isSubtotal: true }));

  // PNC
  rows.push(h.tableRow(["PASIVO NO CORRIENTE", "", ""], { isSubtotal: true }));
  const pncItems = [
    ["CxP Accionistas LP", pnc.cxp_accionistas_nc],
    ["Obligaciones Financieras LP", pnc.oblig_fin_lp],
  ];
  pncItems.forEach(([label, val]) => {
    if (val && Math.abs(val) > 0.5) {
      rows.push(h.tableRow(["  " + label, h.fmtS(val), h.pct1(val / totalPP * 100)], { altIdx: idx++ }));
    }
  });
  rows.push(h.tableRow(["Total Pasivo No Corriente", h.fmtS(pnc.total_pnc), h.pct1(pnc.total_pnc / totalPP * 100)], { isSubtotal: true }));
  rows.push(h.tableRow(["TOTAL PASIVO", h.fmtS(totalPasivo), h.pct1(totalPasivo / totalPP * 100)], { isTotal: true }));

  // Patrimonio
  rows.push(h.tableRow(["PATRIMONIO", "", ""], { isSubtotal: true }));
  const patItems = [
    ["Capital Social", pat.capital],
    ["Reservas", pat.reservas],
    ["Resultados Acumulados", pat.resultados_acum || pat.perdidas_acum],
    ["Resultado del Ejercicio", pat.resultado_ejercicio],
  ];
  patItems.forEach(([label, val]) => {
    if (val !== undefined && val !== null && Math.abs(val) > 0.5) {
      rows.push(h.tableRow(["  " + label, h.fmtS(val), h.pct1(val / totalPP * 100)], { altIdx: idx++ }));
    }
  });
  rows.push(h.tableRow(["Total Patrimonio", h.fmtS(pat.total_patrimonio), h.pct1(pat.total_patrimonio / totalPP * 100)], { isTotal: true }));
  rows.push(h.tableRow(["TOTAL PASIVO Y PATRIMONIO", h.fmtS(totalPP), "100.0%"], { isTotal: true }));

  slide.addTable(rows, { x: 0.4, y: 1.5, w: 7.8, colW: [4.2, 2.0, 1.6], fontSize: 8.5, autoPage: false });

  // Bullets
  const bullets = slideConfig.bullets || [];
  if (bullets.length === 0) {
    if (mode === "status") {
      bullets.push(`Pasivo total ${h.fmtS(totalPasivo)} (${h.pct1(totalPasivo / totalPP * 100)}).`);
      bullets.push(`Patrimonio ${h.fmtS(pat.total_patrimonio)}.`);
    } else {
      bullets.push(`Endeudamiento de ${h.pct1(ratios.endeudamiento)} (benchmark: <70%).`);
      if (pnc.cxp_accionistas_nc && pnc.cxp_accionistas_nc > totalPasivo * 0.5) {
        bullets.push(`Deuda con accionistas S/ ${Math.round(pnc.cxp_accionistas_nc).toLocaleString("en-US")} (${(pnc.cxp_accionistas_nc / totalPasivo * 100).toFixed(0)}% del pasivo). Capitalizable sin desembolso.`);
      }
      bullets.push(`Concentración CP: ${h.pct1(ratios.concentracion_cp)} — ${ratios.concentracion_cp < 50 ? "deuda mayormente LP (favorable)" : "deuda concentrada en CP"}.`);
      if (patNeg) {
        bullets.push(`⚠️ Patrimonio negativo: pérdidas acumuladas han erosionado el capital completamente.`);
      }
      bullets.push(`CxP comerciales S/ ${Math.round(pc.cxp_comerciales || 0).toLocaleString("en-US")} — periodo de pago ${(ratios.per_pago || 0).toFixed(0)} días.`);
    }
  }
  h.addBullets(slide, bullets, 8.5, 1.5, 4.4, 4.8);

  // ── FINANCING STRUCTURE INSIGHT BOX ──
  if (mode === "diagnostic") {
    const deudaAccionistas = pnc.cxp_accionistas_nc || 0;
    const deudaTerceros = totalPasivo - deudaAccionistas;
    const pctAccionistas = totalPasivo > 0 ? (deudaAccionistas / totalPasivo * 100).toFixed(0) : 0;
    const pctTerceros = totalPasivo > 0 ? (deudaTerceros / totalPasivo * 100).toFixed(0) : 0;

    const lines = [];
    lines.push({ text: `Pasivo total: ${h.fmtS(totalPasivo)}  →  Accionistas: ${h.fmtS(Math.round(deudaAccionistas))} (${pctAccionistas}%)  |  Terceros: ${h.fmtS(Math.round(deudaTerceros))} (${pctTerceros}%)`, fontSize: 8, bold: true });

    if (patNeg) {
      const capitalNeeded = Math.abs(pat.total_patrimonio) + 100000; // buffer
      lines.push({ text: `⚠️ Para corregir patrimonio negativo: capitalizar al menos ${h.fmtS(Math.round(capitalNeeded))} de deuda de accionistas (no requiere desembolso de caja).`, fontSize: 8, color: h.COLORS.negative });
    } else {
      lines.push({ text: `Concentración CP: ${h.pct1(ratios.concentracion_cp || 0)} — ${(ratios.concentracion_cp || 0) < 50 ? "favorable (deuda mayormente LP)" : "monitorear presión en CP"}.`, fontSize: 8 });
    }

    h.addInsightBox(pres, slide, {
      title: "Estructura de Financiamiento",
      lines: lines,
      x: 0.4, y: 5.2, w: 12.53, h: 0.85,
      bgColor: patNeg ? h.COLORS.dangerBg : h.COLORS.lightGray
    });
  }

  // Footer — legal alert in diagnostic mode
  const hasLegalAlert = plan.alerts.some(a => a.type === "causal_disolucion");
  const footerSeverity = mode === "status" ? "informational" : (hasLegalAlert ? "critical" : patNeg ? "warning" : "normal");
  h.addFooter(pres, slide,
    slideConfig.footer_text || (mode === "status"
      ? `Estructura de financiamiento al ${data.periodo || "cierre"}.`
      : hasLegalAlert
        ? `⚠️ Art. 407 LGS: Pérdidas > 2/3 capital. Causal de disolución vigente. Acción inmediata: capitalización o aporte.`
        : `Monitorear evolución patrimonial y gestión de deuda comercial.`),
    footerSeverity
  );
  h.addPageNum(slide, slideConfig.page_num);
};
