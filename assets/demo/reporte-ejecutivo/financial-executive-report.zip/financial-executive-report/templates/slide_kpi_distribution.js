/**
 * slide_kpi_distribution.js — KPIs Sectoriales Distribución / Mayorista
 *
 * Faltaba: sólo existía la plantilla de restaurantes, así que los otros ocho
 * sectores caían al fallback y la lámina salía con el texto
 * "[Template: slide_kpi_XXX]" impreso encima. El motor ya calculaba los KPIs
 * sectoriales de distribución con sus benchmarks; nadie los dibujaba.
 *
 * En distribución el margen es fino y el resultado se juega en el capital de
 * trabajo: cuántos días de inventario cargás, en cuántos cobrás y en cuántos
 * pagás. Por eso la lámina ordena los KPIs alrededor del ciclo de conversión
 * y contrasta el crecimiento del inventario contra el de las ventas, que es
 * la señal temprana de sobre-stock.
 */
module.exports = function (pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const mode = plan.mode;

  const sec = ratios.kpis_sectoriales || {};
  const periodos = Object.keys(sec).filter((k) => /^\d{4}$/.test(k)).sort();
  const actual = periodos.length ? sec[periodos[periodos.length - 1]] : {};
  const previo = periodos.length > 1 ? sec[periodos[periodos.length - 2]] : {};
  const B = actual.benchmarks || {};

  h.addHeader(pres, slide, "Capital de Trabajo y Eficiencia — Sector Distribución");

  // ── evaluación contra benchmark sectorial ──
  const entre = (v, par) => Array.isArray(par) && v >= par[0] && v <= par[1];
  const estDso = (v) => (v == null ? "neutral" : entre(v, (B.dso || {}).normal) ? "good"
                        : v > ((B.dso || {}).riesgo || 90) ? "danger" : "warning");
  const estRot = (v) => (v == null ? "neutral" : v >= ((B.rotacion_inv || {}).eficiente || 8) ? "good"
                        : v < ((B.rotacion_inv || {}).lento || 4) ? "danger" : "warning");
  const estCxc = (v) => (v == null ? "neutral" : v >= ((B.cxc_pct_activo || {}).alerta || 40) ? "danger" : "good");
  const estDef = (v) => (v == null ? "neutral" : v >= ((B.dias_efectivo || {}).holgura || 30) ? "good"
                        : v < ((B.dias_efectivo || {}).presion || 15) ? "danger" : "warning");

  const inv = (ratios.ratios || {})[periodos[periodos.length - 1]] || {};
  const cce = (inv.eficiencia || {}).cce_dias;

  h.addSummaryBoxSimple(pres, slide, slideConfig.summary_text ||
    `Inventario ${h.fmt(actual.edad_inventario_dias)} días, cobro ${h.fmt(actual.dso_dias)} días. ` +
    `El ciclo de conversión de efectivo cierra en ${cce == null ? "N/D" : h.fmt(cce)} días: la operación se financia ` +
    `con el crédito de proveedores, así que cualquier acortamiento del plazo de pago se siente de inmediato en la caja.`);

  // ── KPI CARDS ──
  const cards = [
    { label: "Días de inventario", value: h.fmt(actual.edad_inventario_dias), status: estRot(actual.rotacion_inventarios),
      delta: previo.edad_inventario_dias != null ? h.fmtDelta(actual.edad_inventario_dias, previo.edad_inventario_dias) : null },
    { label: "Rotación inventario", value: h.fmtRatio(actual.rotacion_inventarios), status: estRot(actual.rotacion_inventarios),
      delta: previo.rotacion_inventarios != null ? h.fmtDelta(actual.rotacion_inventarios, previo.rotacion_inventarios) : null },
    { label: "Días de cobro (DSO)", value: h.fmt(actual.dso_dias), status: estDso(actual.dso_dias),
      delta: previo.dso_dias != null ? h.fmtDelta(actual.dso_dias, previo.dso_dias) : null },
    { label: "CxC % del activo", value: h.pct1(actual.cxc_pct_activo), status: estCxc(actual.cxc_pct_activo),
      delta: previo.cxc_pct_activo != null ? h.fmtDeltaPP(actual.cxc_pct_activo, previo.cxc_pct_activo) : null },
    { label: "Días de efectivo", value: h.fmt(actual.dias_efectivo), status: estDef(actual.dias_efectivo),
      delta: previo.dias_efectivo != null ? h.fmtDelta(actual.dias_efectivo, previo.dias_efectivo) : null },
  ];
  cards.forEach((k, i) =>
    h.addKPICard(pres, slide, { ...k, x: 0.4 + i * 2.55, y: 1.4, w: 2.35, h: 1.15 }));

  // ── INVENTARIO CONTRA VENTAS ──
  // La señal que importa en distribución: si el stock crece más rápido que la
  // venta, se está comprando para el depósito, no para el cliente.
  const ers = data.estado_resultados || {};
  const bals = data.balance || {};
  if (periodos.length > 1) {
    const p0 = periodos[periodos.length - 2], p1 = periodos[periodos.length - 1];
    const v0 = (ers[p0] || {}).ventas_netas, v1 = (ers[p1] || {}).ventas_netas;
    const i0 = ((bals[p0] || {}).activo_corriente || {}).inventarios;
    const i1 = ((bals[p1] || {}).activo_corriente || {}).inventarios;
    if (v0 && v1 && i0 && i1) {
      const gv = (v1 / v0 - 1) * 100, gi = (i1 / i0 - 1) * 100;
      const brecha = gi - gv;

      slide.addText("Crecimiento del inventario contra crecimiento de las ventas", {
        x: 0.4, y: 2.75, w: 8.5, h: 0.25, fontSize: 9, fontFace: h.FONT, color: C.primary, bold: true });

      const esc = Math.max(Math.abs(gv), Math.abs(gi), 1);
      [["Ventas", gv, C.primary], ["Inventario", gi, brecha > 5 ? C.negative : C.secondary]].forEach((b, i) => {
        const y = 3.1 + i * 0.62;
        slide.addText(b[0], { x: 0.4, y, w: 1.5, h: 0.4, fontSize: 9, fontFace: h.FONT, color: C.darkText, valign: "middle" });
        slide.addShape(pres.shapes.RECTANGLE, {
          x: 1.95, y: y + 0.07, w: Math.max((Math.abs(b[1]) / esc) * 5.2, 0.05), h: 0.28, fill: { color: b[2] } });
        slide.addText(`${b[1] >= 0 ? "+" : "−"}${Math.abs(b[1]).toFixed(1)}%`, {
          x: 1.95 + Math.max((Math.abs(b[1]) / esc) * 5.2, 0.05) + 0.1, y, w: 1.2, h: 0.4,
          fontSize: 9, fontFace: h.FONT, bold: true, color: b[2], valign: "middle" });
      });

      h.addInsightBox(pres, slide, {
        title: brecha > 5 ? "El inventario crece más rápido que la venta" : "Inventario alineado con la venta",
        lines: [
          brecha > 5
            ? `Las existencias suben ${gi.toFixed(1)} % mientras las ventas suben ${gv.toFixed(1)} %: ${brecha.toFixed(1)} puntos de diferencia.`
            : `Existencias ${gi.toFixed(1)} % contra ventas ${gv.toFixed(1)} %: el stock acompaña la operación.`,
          brecha > 5
            ? "Se está acumulando mercadería más rápido de lo que rota. Revisar cobertura por línea antes de la próxima compra."
            : "No hay señal de sobre-stock en el agregado; conviene igual mirar por línea de producto.",
        ],
        x: 7.4, y: 2.95, w: 5.5, h: 1.5, bgColor: brecha > 5 ? C.warningBg : C.lightGray,
      });
    }
  }

  h.addFooter(pres, slide, slideConfig.footer_text ||
    "El ciclo de conversión se sostiene sobre el plazo de proveedores; el inventario es la palanca propia.",
    slideConfig.footer_severity || "normal");
  h.addPageNum(slide, slideConfig.page_num);
};
