/**
 * slide_evolucion.js — Evolución de Indicadores
 *
 * MODE: status ONLY. Replaces slide_conclusiones in status mode.
 *
 * Shows a summary table of all key ratios with:
 *   Actual | Anterior | Variación | Tendencia (↑↓→)
 *
 * NO recommendations. NO risk matrix. NO action verbs.
 * Pure tracking dashboard.
 */

module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;

  h.addHeader(pres, slide, "Evolución de Indicadores Clave");

  h.addSummaryBoxSimple(pres, slide,
    slideConfig.summary_text ||
    `Resumen de la evolución de indicadores principales respecto al periodo anterior. Los colores indican la dirección del cambio: verde = mejora, rojo = deterioro, gris = estable.`
  );

  // Build evolution table
  const prev = ratios.anterior || {};
  const rows = [];

  // Header
  rows.push(h.tableRow(
    ["Indicador", "Actual", "Anterior", "Variación", "Tendencia"],
    { isHeader: true }
  ));

  // Category: LIQUIDEZ
  rows.push([{
    text: "LIQUIDEZ", options: {
      fill: { color: C.subtotalBg }, color: C.primary, bold: true,
      fontSize: 8.5, fontFace: h.FONT, align: "left", colspan: 5,
      border: [{ pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }]
    }
  }]);

  const indicators = [
    // Liquidez
    { name: "Ratio Corriente", curr: ratios.ratio_corriente, prev: prev.ratio_corriente, fmt: "ratio", better: "up" },
    { name: "Prueba Ácida", curr: ratios.prueba_acida, prev: prev.prueba_acida, fmt: "ratio", better: "up" },
    { name: "Días de Efectivo", curr: ratios.dias_cobertura, prev: prev.dias_cobertura, fmt: "days", better: "up" },
    // Solvencia separator
    { separator: "SOLVENCIA" },
    { name: "Endeudamiento", curr: ratios.endeudamiento, prev: prev.endeudamiento, fmt: "pct", better: "down" },
    { name: "Concentración CP", curr: ratios.concentracion_cp, prev: prev.concentracion_cp, fmt: "pct", better: "down" },
    // Rentabilidad separator
    { separator: "RENTABILIDAD" },
    { name: "Margen Bruto", curr: ratios.margen_bruto, prev: prev.margen_bruto, fmt: "pct", better: "up" },
    { name: "Margen Operativo", curr: ratios.margen_operativo, prev: prev.margen_operativo, fmt: "pct", better: "up" },
    { name: "Margen Neto", curr: ratios.margen_neto, prev: prev.margen_neto, fmt: "pct", better: "up" },
    { name: "ROA", curr: ratios.roa, prev: prev.roa, fmt: "pct", better: "up" },
    // Eficiencia separator
    { separator: "EFICIENCIA" },
    { name: "Rotación Inventarios", curr: ratios.rot_inventarios, prev: prev.rot_inventarios, fmt: "ratio", better: "up" },
    { name: "Periodo de Cobro", curr: ratios.per_cobro, prev: prev.per_cobro, fmt: "days", better: "down" },
    { name: "Periodo de Pago", curr: ratios.per_pago, prev: prev.per_pago, fmt: "days", better: "neutral" },
    { name: "CCE", curr: ratios.cce, prev: prev.cce, fmt: "days", better: "down" },
  ];

  let altIdx = 0;
  indicators.forEach(ind => {
    if (ind.separator) {
      rows.push([{
        text: ind.separator, options: {
          fill: { color: C.subtotalBg }, color: C.primary, bold: true,
          fontSize: 8.5, fontFace: h.FONT, align: "left", colspan: 5,
          border: [{ pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }]
        }
      }]);
      altIdx = 0;
      return;
    }

    const curr = ind.curr;
    const prev = ind.prev;
    const currStr = formatValue(curr, ind.fmt);
    const prevStr = prev !== undefined && prev !== null ? formatValue(prev, ind.fmt) : "-";

    // Calculate delta
    let deltaStr = "-";
    let status = "neutral";
    if (prev !== undefined && prev !== null && curr !== undefined && curr !== null) {
      const delta = curr - prev;
      if (ind.fmt === "pct") {
        deltaStr = `${delta >= 0 ? "+" : ""}${delta.toFixed(1)} pp`;
      } else if (ind.fmt === "ratio") {
        deltaStr = `${delta >= 0 ? "+" : ""}${delta.toFixed(2)}x`;
      } else {
        deltaStr = `${delta >= 0 ? "+" : ""}${delta.toFixed(0)} días`;
      }

      // Determine if improvement or deterioration
      const improved = ind.better === "up" ? delta > 0.3
                     : ind.better === "down" ? delta < -0.3
                     : Math.abs(delta) < 0.3;
      const deteriorated = ind.better === "up" ? delta < -0.3
                          : ind.better === "down" ? delta > 0.3
                          : false;

      if (improved) status = "good";
      else if (deteriorated) status = "danger";
      else status = "neutral";
    }

    // Trend arrow
    const arrow = status === "good" ? "↑ Mejora"
                : status === "danger" ? "↓ Deterioro"
                : "→ Estable";

    // Build row with heatmap on trend column
    const baseBg = altIdx % 2 === 0 ? C.white : C.altRow;
    const trendBg = status === "good" ? C.successBg
                  : status === "danger" ? C.dangerBg
                  : C.lightGray;

    const border = [{ pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }, { pt: 0.3, color: "D0D0D0" }];

    rows.push([
      { text: ind.name, options: { fill: { color: baseBg }, color: C.darkText, fontSize: 8.5, fontFace: h.FONT, align: "left", border } },
      { text: currStr, options: { fill: { color: baseBg }, color: C.darkText, fontSize: 8.5, fontFace: h.FONT, align: "right", border } },
      { text: prevStr, options: { fill: { color: baseBg }, color: C.neutral, fontSize: 8.5, fontFace: h.FONT, align: "right", border } },
      { text: deltaStr, options: { fill: { color: trendBg }, color: C.darkText, fontSize: 8.5, fontFace: h.FONT, align: "right", bold: status !== "neutral", border } },
      { text: arrow, options: { fill: { color: trendBg }, color: C.darkText, fontSize: 8.5, fontFace: h.FONT, align: "center", border } },
    ]);

    altIdx++;
  });

  slide.addTable(rows, {
    x: 0.4, y: 1.5, w: 12.53,
    colW: [3.5, 2.0, 2.0, 2.5, 2.53],
    fontSize: 8.5,
    autoPage: false
  });

  // Footer - INFORMATIONAL only, no actions
  h.addFooter(pres, slide,
    slideConfig.footer_text ||
    `Indicadores comparados contra periodo inmediato anterior. Verde = mejora, Rojo = deterioro, Gris = estable (variación < 0.3 pp).`,
    "informational"
  );

  h.addPageNum(slide, slideConfig.page_num);
};


function formatValue(val, fmt) {
  if (val === null || val === undefined) return "-";
  switch (fmt) {
    case "pct": return `${val.toFixed(1)}%`;
    case "ratio": return `${val.toFixed(2)}x`;
    case "days": return `${val.toFixed(0)} días`;
    default: return String(val);
  }
}
