/**
 * slide_egp.js — Estado de Ganancias y Pérdidas
 *
 * MODE TOGGLE:
 *   diagnostic → Tabla 1 periodo + 5 bullets interpretativos + footer accionable
 *   status     → Tabla comparativa (actual|anterior|var|var%) + 2-3 bullets factuales + footer informativo
 */

module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const mode = plan.mode;
  const modeConfig = plan.mode_config;

  // ── HEADER ──
  const titleSuffix = mode === "status" ? "Comparativo" : data.periodo || "Ejercicio";
  h.addHeader(pres, slide, `Estado de Ganancias y Pérdidas — ${titleSuffix}`);

  // ── SUMMARY BOX ──
  // Claude generates this text based on the template key in slideConfig
  // For now, use placeholder that Claude will fill
  const summaryText = slideConfig.summary_text || generateSummary(data, ratios, mode);
  h.addSummaryBoxSimple(pres, slide, summaryText);

  // ── TABLE ──
  const rows = buildEGPTable(data, ratios, mode, h);
  const tableW = mode === "status" ? 9.0 : 7.8;
  const colW = mode === "status"
    ? [3.2, 1.5, 1.5, 1.4, 1.4]   // Concepto | Actual | Anterior | Var S/ | Var %
    : [4.2, 2.0, 1.6];             // Concepto | S/ | %

  slide.addTable(rows, { x: 0.4, y: 1.5, w: tableW, colW, fontSize: 8.5 });

  // ── BULLETS ──
  const bulletX = mode === "status" ? 9.7 : 8.5;
  const bulletW = mode === "status" ? 3.3 : 4.4;
  const bullets = slideConfig.bullets || generateBullets(data, ratios, plan, mode);

  h.addBullets(slide, bullets, bulletX, 1.5, bulletW, 4.8);

  // ── EBITDA INSIGHT BOX (fills empty space between content and footer) ──
  if (mode === "diagnostic" && ratios.ebitda !== undefined) {
    const egp = data.egp;
    const v = egp.ventas_netas;
    const ebit = egp.ebit;
    const deprec = ratios.depreciacion_periodo || (ratios.ebitda - ebit);
    const ebitda = ratios.ebitda;
    const ebitdaSign = ebitda >= 0 ? "positivo" : "negativo";

    // Distortion note
    const difCambio = egp.dif_cambio || 0;
    const hasDist = Math.abs(difCambio) > v * 0.03;
    const distNote = hasDist
      ? `  |  Sin dif. cambio (${h.fmtS(Math.round(difCambio))}), resultado ajustado: ${h.fmtS(Math.round(egp.resultado_ejercicio - difCambio))}`
      : "";

    h.addInsightBox(pres, slide, {
      title: "Análisis de Rentabilidad Ajustada",
      lines: [
        { text: `EBIT: ${h.fmtS(Math.round(ebit))}  +  Depreciación: ${h.fmtS(Math.round(deprec))}  =  EBITDA: ${h.fmtS(Math.round(ebitda))} (${ebitdaSign})`, fontSize: 8.5, bold: true, color: ebitda >= 0 ? "1B5E20" : C.negative },
        { text: `EBITDA ${ebitdaSign} confirma que la operación ${ebitda >= 0 ? "genera" : "no genera"} caja operativa.${distNote}`, fontSize: 8 },
      ],
      x: 0.4, y: 5.2, w: 12.53, h: 0.85,
      bgColor: ebitda >= 0 ? C.successBg : C.lightGray
    });
  }

  // ── FOOTER ──
  const footerSeverity = mode === "status"
    ? "informational"
    : (plan.severity === "critico" ? "critical" : plan.severity === "riesgo" ? "warning" : "normal");

  const footerText = slideConfig.footer_text || generateFooter(data, ratios, mode, plan.severity);
  h.addFooter(pres, slide, footerText, footerSeverity);

  h.addPageNum(slide, slideConfig.page_num);
};


// ═══════════════════════════════════════════════════════
// TABLE BUILDERS
// ═══════════════════════════════════════════════════════

function buildEGPTable(data, ratios, mode, h) {
  const egp = data.egp;
  const rows = [];

  if (mode === "status") {
    // ── COMPARATIVE TABLE: Actual | Anterior | Var S/ | Var % ──
    const prev = data.egp_anterior || {};
    rows.push(h.tableRow(
      ["Concepto", "Actual S/", "Anterior S/", "Var S/", "Var %"],
      { isHeader: true }
    ));

    const items = buildEGPItems(egp, prev);
    items.forEach((item, i) => {
      const opts = item.isSubtotal ? { isSubtotal: true }
                 : item.isTotal ? { isTotal: true }
                 : { altIdx: i };
      rows.push(h.tableRow(item.cells, opts));
    });

  } else {
    // ── DIAGNOSTIC TABLE: Monto | % Vertical ──
    rows.push(h.tableRow(["Concepto", "S/", "%"], { isHeader: true }));

    const ventas = egp.ventas_netas;
    const items = [
      { cells: ["Venta Bruta", h.fmtS(egp.ventas_brutas), h.pct1(egp.ventas_brutas / ventas * 100)], altIdx: 0 },
      { cells: ["  (-) Cortesías y Mermas", h.fmtS(-(egp.ventas_brutas - ventas)), h.pct1(-((egp.ventas_brutas - ventas) / ventas * 100))], altIdx: 1 },
      { cells: ["Ventas Netas", h.fmtS(ventas), "100.0%"], isSubtotal: true },
      { cells: ["  (-) Costo Restaurante", h.fmtS(-egp.costo_ventas), h.pct1(egp.costo_ventas / ventas * 100)], altIdx: 0 },
      { cells: ["Utilidad Bruta", h.fmtS(egp.utilidad_bruta), h.pct1(egp.utilidad_bruta / ventas * 100)], isSubtotal: true },
      { cells: ["  (-) Gastos Restaurante", h.fmtS(-egp.gastos_restaurante), h.pct1(egp.gastos_restaurante / ventas * 100)], altIdx: 0 },
      { cells: ["  (-) Gastos Administrativos", h.fmtS(-egp.gastos_admin), h.pct1(egp.gastos_admin / ventas * 100)], altIdx: 1 },
      { cells: ["Utilidad Operativa (EBIT)", h.fmtS(egp.ebit), h.pct1(egp.ebit / ventas * 100)], isSubtotal: true },
      { cells: ["  (-) Gastos Financieros", h.fmtS(-egp.gastos_financieros), h.pct1(egp.gastos_financieros / ventas * 100)], altIdx: 0 },
    ];

    // Add non-recurring items if material
    if (egp.dif_cambio && Math.abs(egp.dif_cambio) > 0) {
      items.push({ cells: ["  (+) Dif. Cambio Neta", h.fmtS(egp.dif_cambio), h.pct1(egp.dif_cambio / ventas * 100)], altIdx: 1 });
    }
    const otrosTotal = (egp.otros_ingresos || 0) + (egp.auspicios || 0);
    if (otrosTotal > 0) {
      items.push({ cells: ["  (+) Otros Ingresos", h.fmtS(otrosTotal), h.pct1(otrosTotal / ventas * 100)], altIdx: 0 });
    }
    items.push({ cells: ["Resultado del Ejercicio", h.fmtS(egp.resultado_ejercicio), h.pct1(egp.resultado_ejercicio / ventas * 100)], isTotal: true });

    items.forEach((item) => {
      const opts = item.isSubtotal ? { isSubtotal: true }
                 : item.isTotal ? { isTotal: true }
                 : { altIdx: item.altIdx };
      rows.push(h.tableRow(item.cells, opts));
    });
  }

  return rows;
}

function buildEGPItems(egp, prev) {
  // Helper for comparative mode
  const line = (label, curr, prior, opts = {}) => {
    const varS = curr - (prior || 0);
    const varPct = prior && prior !== 0 ? ((curr - prior) / Math.abs(prior) * 100).toFixed(1) + "%" : "-";
    return {
      cells: [label, `S/ ${fmt(curr)}`, `S/ ${fmt(prior || 0)}`, `S/ ${fmt(varS)}`, varPct],
      ...opts
    };
  };

  const fmt = (n) => {
    if (n === null || n === undefined) return "-";
    const abs = Math.abs(n);
    const s = abs >= 1000 ? abs.toLocaleString("en-US", { maximumFractionDigits: 0 }) : abs.toFixed(0);
    return n < 0 ? `-${s}` : s;
  };

  return [
    line("Ventas Netas", egp.ventas_netas, prev.ventas_netas, { isSubtotal: true }),
    line("  (-) Costo de Ventas", -egp.costo_ventas, -(prev.costo_ventas || 0), { altIdx: 0 }),
    line("Utilidad Bruta", egp.utilidad_bruta, prev.utilidad_bruta, { isSubtotal: true }),
    line("  (-) Gastos Operativos", -(egp.gastos_restaurante + egp.gastos_admin),
         -((prev.gastos_restaurante || 0) + (prev.gastos_admin || 0)), { altIdx: 0 }),
    line("Utilidad Operativa", egp.ebit, prev.ebit, { isSubtotal: true }),
    line("Resultado Neto", egp.resultado_ejercicio, prev.resultado_ejercicio, { isTotal: true }),
  ];
}


// ═══════════════════════════════════════════════════════
// COMMENT GENERATORS (fallback when Claude doesn't override)
// ═══════════════════════════════════════════════════════

function generateSummary(data, ratios, mode) {
  const egp = data.egp;
  const v = egp.ventas_netas;
  const mb = ratios.margen_bruto || (egp.utilidad_bruta / v * 100);
  const mo = ratios.margen_operativo || (egp.ebit / v * 100);

  if (mode === "status") {
    // Factual + delta
    return `Ventas netas de S/ ${Math.round(v).toLocaleString("en-US")} con margen bruto de ${mb.toFixed(1)}% y margen operativo de ${mo.toFixed(1)}%. ${mo < 0 ? "La operación registró pérdida operativa." : "La operación fue rentable a nivel operativo."}`;
  } else {
    // Interpretive
    if (mo < -10) {
      return `Las ventas de S/ ${Math.round(v).toLocaleString("en-US")} generaron margen bruto de ${mb.toFixed(1)}%, pero los gastos operativos absorben toda la utilidad bruta y generan una pérdida operativa de ${mo.toFixed(1)}%. La estructura de costos no es sostenible al nivel de ingresos actual.`;
    } else if (mo < 0) {
      return `Las ventas de S/ ${Math.round(v).toLocaleString("en-US")} generaron margen bruto de ${mb.toFixed(1)}%, insuficiente para cubrir gastos operativos. El margen operativo de ${mo.toFixed(1)}% requiere ajuste de costos.`;
    } else {
      return `Las ventas de S/ ${Math.round(v).toLocaleString("en-US")} generaron margen bruto de ${mb.toFixed(1)}% y margen operativo de ${mo.toFixed(1)}%, mostrando una operación rentable.`;
    }
  }
}

function generateBullets(data, ratios, plan, mode) {
  const egp = data.egp;
  const v = egp.ventas_netas;

  if (mode === "status") {
    // 2-3 factual bullets, NO recommendations
    const bullets = [];
    bullets.push(`Ventas netas de S/ ${Math.round(v).toLocaleString("en-US")}. Margen bruto ${(ratios.margen_bruto || 0).toFixed(1)}%.`);
    if (egp.ebit < 0) {
      bullets.push(`Pérdida operativa de S/ ${Math.round(Math.abs(egp.ebit)).toLocaleString("en-US")} (margen: ${(ratios.margen_operativo || 0).toFixed(1)}%).`);
    }
    if (egp.dif_cambio && Math.abs(egp.dif_cambio) > v * 0.05) {
      bullets.push(`Dif. cambio neta de S/ ${Math.round(egp.dif_cambio).toLocaleString("en-US")} impactó el resultado.`);
    }
    return bullets;
  } else {
    // 5 interpretive bullets with dato → causa → acción
    // These are placeholders — Claude should override with richer content
    const bullets = [];
    bullets.push(`Ventas netas de S/ ${Math.round(v).toLocaleString("en-US")} promedian S/ ${Math.round(v / 12).toLocaleString("en-US")}/mes.`);
    bullets.push(`Food cost de ${(ratios.food_cost_pct || egp.costo_ventas / v * 100).toFixed(1)}% sobre ventas.`);
    bullets.push(`Gastos operativos totales representan ${((egp.gastos_restaurante + egp.gastos_admin) / v * 100).toFixed(1)}% de ventas.`);
    if (egp.dif_cambio && Math.abs(egp.dif_cambio) > v * 0.05) {
      bullets.push(`Dif. cambio de S/ ${Math.round(egp.dif_cambio).toLocaleString("en-US")} distorsiona el resultado neto.`);
    }
    bullets.push(`Resultado neto: S/ ${Math.round(egp.resultado_ejercicio).toLocaleString("en-US")} (margen: ${(ratios.margen_neto || 0).toFixed(1)}%).`);
    return bullets;
  }
}

function generateFooter(data, ratios, mode, severity) {
  if (mode === "status") {
    return `Indicadores actualizados al ${data.periodo || "cierre del periodo"}. Los valores se comparan contra el periodo anterior.`;
  } else {
    if (severity === "critico") {
      return `Acción inmediata: reestructurar costos operativos y resolver situación patrimonial para asegurar continuidad operativa.`;
    } else if (severity === "riesgo") {
      return `Monitorear evolución de márgenes en los próximos 3 meses. Si la tendencia persiste, evaluar ajustes en estructura de costos.`;
    } else {
      return `Mantener la gestión actual y buscar oportunidades de optimización en las partidas de mayor incidencia.`;
    }
  }
}
