/**
 * slide_centro_costos.js — Análisis por Centro de Costos (Conditional)
 * Generated when has_centro_costos = true
 * Shows P&L by cost center if data available
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;

  h.addHeader(pres, slide, "Análisis por Centro de Costos");

  h.addSummaryBoxSimple(pres, slide,
    slideConfig.summary_text || `Distribución de costos y gastos por centro operativo. Permite identificar áreas de mayor incidencia.`
  );

  // This template expects Claude to populate data from the CC sheet
  // For now, show placeholder structure
  const ccData = data.complementary.centro_costos || {};
  if (Object.keys(ccData).length === 0) {
    slide.addText("Datos de centros de costo disponibles en el Excel pero requieren extracción manual.\nClaude procesará esta información durante la fase de generación.", {
      x: 1, y: 2.5, w: 11, h: 2,
      fontSize: 11, fontFace: h.FONT, color: C.neutral, align: "center", valign: "middle"
    });
  } else {
    const rows = [h.tableRow(["Centro de Costo", "Ingresos S/", "Costos S/", "Margen S/", "Margen %"], { isHeader: true })];
    let idx = 0;
    Object.entries(ccData).forEach(([cc, vals]) => {
      const margen = (vals.ingresos || 0) - (vals.costos || 0);
      const margenPct = vals.ingresos ? (margen / vals.ingresos * 100) : 0;
      rows.push(h.ratioRow(
        [cc, h.fmtS(vals.ingresos || 0), h.fmtS(vals.costos || 0), h.fmtS(margen), h.pct1(margenPct)],
        margenPct >= 10 ? "good" : margenPct >= 0 ? "warning" : "danger",
        idx++
      ));
    });
    slide.addTable(rows, { x: 0.4, y: 1.5, w: 12.53, colW: [3.5, 2.3, 2.3, 2.3, 2.13], fontSize: 8.5 });
  }

  h.addFooter(pres, slide,
    slideConfig.footer_text || `Análisis por centro de costo basado en la distribución contable del periodo.`,
    plan.mode === "status" ? "informational" : "normal"
  );
  h.addPageNum(slide, slideConfig.page_num);
};
