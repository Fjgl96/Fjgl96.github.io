/**
 * slide_kpi_restaurants.js — KPIs Sectoriales Restaurante
 * diagnostic: horizontal bars (food cost by category) + KPI cards + gastos breakdown
 * status: KPIs with deltas vs prior + trend
 */
module.exports = function(pres, data, ratios, plan, slideConfig, h) {
  const slide = pres.addSlide();
  const C = h.COLORS;
  const mode = plan.mode;
  const v = data.egp.ventas_netas;

  h.addHeader(pres, slide, mode === "status"
    ? "Análisis de Costos y Eficiencia — Evolución"
    : "Análisis de Costos y Eficiencia — Sector Restaurante");

  const primeCostStatus = ratios.prime_cost_pct > 70 ? "danger" : ratios.prime_cost_pct > 65 ? "warning" : "good";
  h.addSummaryBoxSimple(pres, slide,
    slideConfig.summary_text || (mode === "status"
      ? `Food cost ${h.pct1(ratios.food_cost_pct)}, labor cost ${h.pct1(ratios.labor_cost_pct)}, prime cost ${h.pct1(ratios.prime_cost_pct)}.`
      : `Prime cost de ${h.pct1(ratios.prime_cost_pct)} (food ${h.pct1(ratios.food_cost_pct)} + labor ${h.pct1(ratios.labor_cost_pct)}) ${ratios.prime_cost_pct > 70 ? "excede el umbral destructivo de 70%. La operación no genera valor después de costos variables." : "se encuentra en zona de precaución."}`));

  // ── KPI CARDS (5) ──
  const prev = ratios.anterior || {};
  const kpis = [
    { label: "Food Cost %", value: h.pct1(ratios.food_cost_pct), status: ratios.food_cost_pct <= 38 ? "good" : ratios.food_cost_pct <= 42 ? "warning" : "danger",
      delta: mode === "status" ? h.fmtDeltaPP(ratios.food_cost_pct, prev.food_cost_pct) : null },
    { label: "Labor Cost %", value: h.pct1(ratios.labor_cost_pct), status: ratios.labor_cost_pct <= 30 ? "good" : ratios.labor_cost_pct <= 35 ? "warning" : "danger",
      delta: mode === "status" ? h.fmtDeltaPP(ratios.labor_cost_pct, prev.labor_cost_pct) : null },
    { label: "Prime Cost %", value: h.pct1(ratios.prime_cost_pct), status: primeCostStatus,
      delta: mode === "status" ? h.fmtDeltaPP(ratios.prime_cost_pct, prev.prime_cost_pct) : null },
    { label: "Cortesías %", value: h.pct1(ratios.cortesias_pct || 0), status: (ratios.cortesias_pct || 0) <= 2.5 ? "good" : (ratios.cortesias_pct || 0) <= 4 ? "warning" : "danger",
      delta: mode === "status" ? h.fmtDeltaPP(ratios.cortesias_pct, prev.cortesias_pct) : null },
    { label: "Cobertura PE", value: h.pct1(ratios.cobertura_pe_pct || 0), status: (ratios.cobertura_pe_pct || 0) >= 100 ? "good" : (ratios.cobertura_pe_pct || 0) >= 80 ? "warning" : "danger",
      delta: mode === "status" ? h.fmtDeltaPP(ratios.cobertura_pe_pct, prev.cobertura_pe_pct) : null },
  ];

  kpis.forEach((kpi, i) => {
    h.addKPICard(pres, slide, { ...kpi, x: 0.4 + i * 2.55, y: 1.4, w: 2.35, h: mode === "status" ? 1.15 : 1.0 });
  });

  // ── COST BREAKDOWN CHART (horizontal bars) ──
  const costs = data.complementary.cost_categories || {};
  const costEntries = Object.entries(costs).sort((a, b) => b[1] - a[1]).slice(0, 8);
  const totalCV = data.egp.costo_ventas;
  const maxVal = costEntries.length > 0 ? costEntries[0][1] : 1;

  if (costEntries.length > 0) {
    const chartY = mode === "status" ? 2.8 : 2.6;
    const chartH = 3.5;
    const barH = Math.min(0.35, chartH / costEntries.length - 0.05);

    // Title
    slide.addText(mode === "diagnostic" ? "Costo por Categoría (S/)" : "Costo de Ventas por Categoría", {
      x: 0.4, y: chartY - 0.25, w: 8, h: 0.25,
      fontSize: 9, fontFace: h.FONT, color: C.primary, bold: true
    });

    costEntries.forEach((entry, i) => {
      const [cat, val] = entry;
      const pct = val / totalCV * 100;
      const barW = (val / maxVal) * 5.5;
      const yPos = chartY + i * (barH + 0.08);

      // Category label
      slide.addText(cat, {
        x: 0.4, y: yPos, w: 2.8, h: barH,
        fontSize: 7.5, fontFace: h.FONT, color: C.darkText, align: "right", valign: "middle"
      });

      // Bar — SWD rule: Top 1 red (driver), Top 2-3 blue (focus), rest gray (context)
      let barColor;
      if (i === 0) barColor = C.negative;        // #1 driver: red
      else if (i <= 2) barColor = C.primary;       // #2-3: blue (focus)
      else barColor = "D5D5D5";                    // rest: light gray (context)

      slide.addShape(pres.shapes.RECTANGLE, {
        x: 3.3, y: yPos, w: Math.max(barW, 0.1), h: barH,
        fill: { color: barColor }
      });

      // Value label
      slide.addText(`S/ ${Math.round(val).toLocaleString("en-US")} (${pct.toFixed(1)}%)`, {
        x: 3.3 + barW + 0.15, y: yPos, w: 3, h: barH,
        fontSize: 7, fontFace: h.FONT, color: C.darkText, valign: "middle"
      });
    });
  }

  // ── GASTOS BREAKDOWN (right side) ──
  if (mode === "diagnostic") {
    const gastos = data.complementary.gastos_restaurante_detalle || {};
    const gastosAdmin = data.complementary.gastos_admin_detalle || {};
    const rightX = 9.2;

    slide.addText("Estructura de Gastos (% sobre Ventas)", {
      x: rightX, y: 2.35, w: 4, h: 0.25,
      fontSize: 9, fontFace: h.FONT, color: C.primary, bold: true
    });

    const gastoRows = [
      h.tableRow(["Partida", "S/", "% Vtas"], { isHeader: true }),
      h.tableRow(["GASTOS RESTAURANTE", h.fmtS(data.egp.gastos_restaurante), h.pct1(data.egp.gastos_restaurante / v * 100)], { isSubtotal: true }),
    ];
    let gi = 0;
    Object.entries(gastos).forEach(([k, val]) => {
      gastoRows.push(h.tableRow(["  " + k.replace(/_/g, " "), h.fmtS(val), h.pct1(val / v * 100)], { altIdx: gi++ }));
    });
    gastoRows.push(h.tableRow(["GASTOS ADMIN", h.fmtS(data.egp.gastos_admin), h.pct1(data.egp.gastos_admin / v * 100)], { isSubtotal: true }));
    Object.entries(gastosAdmin).forEach(([k, val]) => {
      gastoRows.push(h.tableRow(["  " + k.replace(/_/g, " "), h.fmtS(val), h.pct1(val / v * 100)], { altIdx: gi++ }));
    });

    slide.addTable(gastoRows, {
      x: rightX, y: 2.6, w: 4.0, colW: [2.0, 1.0, 1.0], fontSize: 7.5, autoPage: false
    });
  }

  // Footer
  h.addFooter(pres, slide,
    slideConfig.footer_text || (mode === "status"
      ? `KPIs sectoriales de restaurante al ${data.periodo || "cierre"}.`
      : ratios.prime_cost_pct > 70
        ? `Prime cost > 70% destruye valor. Prioridad: reducir food cost (-6pp) vía renegociación proveedores y rediseño carta.`
        : `Monitorear evolución de food cost y labor cost para mantener prime cost bajo control.`),
    mode === "status" ? "informational" : (primeCostStatus === "danger" ? "critical" : "normal")
  );
  h.addPageNum(slide, slideConfig.page_num);
};
