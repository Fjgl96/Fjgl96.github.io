# Pais: Peru

## Regulacion Tributaria
Impuesto a la Renta: 29.5 pct (regimen general)
IGV: 18 pct (incluido en precios al consumidor)
Recargo al Consumo: 10 pct (restaurantes, opcional, para trabajadores)
UIT 2025: S/ 5,350
Participacion trabajadores: 8 pct comercio, 10 pct industria

## Regulacion Societaria
Art. 220 LGS: Perdidas > 50 pct capital -> obligacion reducir capital
Art. 407 LGS: Perdidas > 2/3 capital (66.7 pct) -> CAUSAL DE DISOLUCION
Accion: junta accionistas para capitalizar, aportar, reducir o disolver.

## Obligaciones Laborales
EsSalud: 9 pct sobre remuneracion (cargo empleador)
SCTR: pension + salud (actividades riesgo)
Gratificaciones: julio y diciembre (1 sueldo cada una)
CTS: aprox 1.17 sueldos/anio
Vacaciones: 30 dias por anio
Asignacion familiar: 10 pct de RMV

## Formato Numerico
Moneda: PEN (S/)
Miles: coma (262,951)
Decimales: punto (15.4 pct)
Negativos: con signo (-6,331)
Ejemplo: S/ 262,951 | -2.4 pct | 0.48x

## Organismos
SUNAT: tributacion | SMV: mercado valores | SBS: sector financiero | SUNAFIL: laboral

## Estacionalidad
Ene-Feb: verano, turismo costa, Lima baja
Marzo: vuelta clases, retail escolar
Julio: fiestas patrias, gratificacion, consumo alto
Nov-Dic: navidad, gratificacion, retail alto
