# Sector: Manufactura

## Identificacion
Triggers: productos terminados, productos en proceso, materia prima, costo produccion, capacidad instalada, planta, maquinaria, mano de obra directa, CIF

## interview_q3_options
Materia prima importada exposicion cambiaria | Estacionalidad produccion | Ampliacion planta o nueva linea | Problemas suministro insumos

## KPIs Especificos

### Costo Unitario = Costo Produccion / Unidades Producidas
Si no hay unidades usar CV/Ventas como proxy.

### Capacidad Utilizada pct = Produccion Real / Capacidad Instalada x 100
>85 optimo, 70-85 normal, <70 subutilizacion. Si no hay dato omitir.

### Rotacion Inventarios por tipo
MP: >8x (<45 dias) | PP: >12x (<30 dias) | PT: >10x (<36 dias)

## Slides Adicionales
1. EFICIENCIA PRODUCTIVA: Rotacion por tipo inventario, estructura costos MP vs MOD vs CIF

## Benchmarks Ratios
Ratio Corriente: riesgo <1.00, adecuado 1.00-1.50, solido >1.50
D/E: conservador <1.00, moderado 1.00-2.50, alto >2.50
Margen Bruto: bajo <20, normal 20-35, solido >35
Margen Op: bajo <6, normal 6-12, solido >12
Margen Neto: bajo <4, normal 4-10, solido >10
ROE: bajo <8, normal 8-20, solido >20

## Alertas
- Inventarios >40 pct activo: capital atrapado evaluar JIT
- Rotacion MP <6x: sobre-stock >60 dias obsolescencia
- Depreciacion alta vs IME: activos envejecidos plan reposicion
