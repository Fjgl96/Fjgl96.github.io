# Sector: Restaurantes / Food Service

## Identificacion
Triggers: food cost, costo de ventas de alimentos, menajes, cortesias, mermas, recargo al consumo, cocina, mozos, chef

## Subsectores
Fine Dining | Casual Dining | Fast Food/QSR | Bar/Cocteleria | Cafeteria

## interview_q3_options
Cobra recargo al consumo 10% | Venta fuerte de licores/vinos | Mes bajo estacionalidad | Remodelacion reciente | Apertura nueva sucursal

## KPIs Especificos

### Food Cost pct = CV / Ventas x 100
Fine Dining: optimo <32, aceptable 32-38, alto >38
Casual: optimo <35, aceptable 35-42, alto >42
Fast Food: optimo <28, aceptable 28-35, alto >35
Bar: optimo <22, aceptable 22-30, alto >30

### Labor Cost pct = (Personal Rest + Personal Admin) / Ventas x 100
Fine Dining: eficiente <30, normal 30-38, alto >38

### Prime Cost pct = Food Cost + Labor Cost
REGLA: Si >70 pct la operacion no es rentable.
Fine Dining: eficiente <60, normal 60-68, alto >68

### Occupancy Cost pct = (Alquiler + Servicios Local) / Ventas x 100
Eficiente <8, normal 8-12, alto >12

### Comisiones TC pct = Comisiones Tarjetas / Ventas x 100
Peru benchmark: 3.25-4.5 pct. Excesivo >5 pct.

### Cortesias y Mermas pct
Controlado <1.5, monitorear 1.5-2.5, problema >2.5

### Food Cost por Categoria (si hay detalle)
Pescados/mariscos: 45-65 pct (>70 alerta)
Carnes/aves: 35-50 pct (>55 alerta)
Licores: 18-25 pct (>30 control barra)
Vinos: 30-45 pct (>50 pricing)
Cerveza: 20-30 pct | Abarrotes: 25-35 pct

### Recargo al Consumo Peru
10 pct sobre subtotal antes de IGV. NO es ingreso del restaurante.
PREGUNTAR: ventas incluyen o excluyen el RC?

## Slides Adicionales
1. ANALISIS DE COSTOS Y EFICIENCIA: Barras H food cost por categoria + Pareto top 10 gastos + KPI cards sectoriales
2. Si hay centro de costos: desglose restaurante vs admin

## Benchmarks Ratios
Ratio Corriente: riesgo <0.60, adecuado 0.60-1.20, solido >1.20
D/E: conservador <2.0, moderado 2.0-4.0, alto >4.0
Margen Bruto: bajo <58, normal 58-66, solido >66 (fine dining)
Margen Op: bajo <5, normal 5-12, solido >12
Margen Neto: bajo <3, normal 3-8, solido >8
ROE: bajo <8, normal 8-20, solido >20

## Alertas
- Prime Cost >70: operacion destruye valor
- Food cost >benchmark+5pp: revisar pricing porciones merma
- Cortesias >2.5: implementar politica autorizacion
- Ocupacion >12: evaluar renegociacion alquiler
