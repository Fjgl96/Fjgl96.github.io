# Sector: Retail / Comercio

## Identificacion
Triggers: tiendas, puntos de venta, ticket promedio, metro cuadrado, merma/shrinkage, rotacion productos, gondola

## interview_q3_options
Temporada alta/baja campanas | Apertura/cierre tiendas | Canal e-commerce activo | Competencia precio agresiva

## KPIs Especificos

### Ventas por m2 = Ventas / m2 area venta
Supermercado: S/ 800-1500/m2/mes. Tienda especializada: S/ 500-2000/m2/mes.
Si no hay m2 omitir.

### Ticket Promedio = Ventas / Transacciones
Si no hay transacciones: Ventas Diarias = Ventas Mensuales / Dias Operativos.

### Shrinkage pct = Merma / Ventas x 100
<1 excelente, 1-2 normal, >2 problema control.

## Slides Adicionales
1. EFICIENCIA COMERCIAL: Ticket promedio, merma, rotacion por categoria si hay detalle

## Benchmarks Ratios
Ratio Corriente: riesgo <0.90, adecuado 0.90-1.40, solido >1.40
D/E: conservador <1.50, moderado 1.50-3.00, alto >3.00
Margen Bruto: bajo <25, normal 25-40, solido >40
Margen Op: bajo <3, normal 3-8, solido >8
Margen Neto: bajo <2, normal 2-5, solido >5
ROE: bajo <8, normal 8-20, solido >20

## Alertas
- Merma >2 pct: control inventarios deficiente
- Inventarios >50 pct activo: capital concentrado en stock
- Margen bruto en caida: presion de precios
