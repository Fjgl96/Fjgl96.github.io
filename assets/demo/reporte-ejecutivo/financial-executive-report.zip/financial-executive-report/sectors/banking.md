# Sector: Banca y Seguros

## Identificacion
Triggers: banco, banca multiple, financiera, seguros, colocaciones, depositos, cartera crediticia, provisiones, SBS, morosidad, capital global, fondeo

## interview_q3_options
Operacion normal | Ciclo crediticio adverso | Cambio regulatorio SBS | Expansion retail/digital | Fusiones o adquisiciones

## KPIs Especificos

### ROE (Prom) = Utilidad Neta / Patrimonio Promedio x 100
Benchmark sistema bancario Peru: bajo <10, normal 10-18, solido >18

### ROA (Prom) = Utilidad Neta / Activo Promedio x 100
Benchmark: bajo <1.0, normal 1.0-2.0, solido >2.0

### Margen Financiero Bruto = (Ing Financieros - Gasto Financieros) / Ing Financieros x 100
Benchmark: bajo <60, normal 60-72, solido >72

### Ratio Eficiencia = Gastos Admin / (Mg Fin Bruto + Ing Serv Fin Netos + ROF) x 100
Menor es mejor. Benchmark: eficiente <36, normal 36-42, ineficiente >42

### Prima por Riesgo = Gasto Provisiones / Promedio Coloc Brutas x 100
Benchmark: bajo <2.0, normal 2.0-3.5, alto >3.5

### Cartera Alto Riesgo (CAR) = (Vencida + Judicial + Refinanc + Reestruc) / Coloc Brutas x 100
Benchmark: bueno <5.0, moderado 5.0-7.0, alto >7.0

### Cobertura CAR = Provisiones / Cartera Alto Riesgo x 100
Benchmark: insuficiente <90, adecuado 90-110, holgado >110

### Ratio Capital Global (RCG) = Patrimonio Efectivo / APR x 100
Minimo regulatorio SBS: 10.0 pct. Benchmark: ajustado 10-13, adecuado 13-17, holgado >17

### Liquidez MN = Activos Liquidos MN / Pasivos CP MN x 100
Minimo SBS: 8 pct. Benchmark: ajustado 8-15, adecuado 15-30, holgado >30

### Liquidez ME = Activos Liquidos ME / Pasivos CP ME x 100
Minimo SBS: 20 pct. Benchmark: ajustado 20-35, adecuado 35-55, holgado >55

### Colocaciones/Depositos = Coloc Brutas / Total Depositos x 100
Benchmark: conservador <90, normal 90-110, agresivo >110

## Mapeo Cuentas Bancarias
La estructura de EEFF bancarios difiere de empresas comerciales:
- Activo: Disponible (caja, BCRP, bancos) | Inversiones Financieras | Colocaciones Netas | Inv en Subsidiarias | IME | Otros
- Pasivo: Obligaciones Publico (vista, ahorro, plazo, CTS) | Dep Sist Financiero | Adeudos | Valores Circulacion | Otros
- Resultados: Ing Financieros - Gasto Financieros = Mg Fin Bruto - Provisiones = Mg Fin Neto + Ing Serv Fin Netos + ROF = Mg Op Bruto - Gastos Admin = Mg Op Neto +/- Otros = UAI - IR = Utilidad Neta
- NO aplican: inventarios, costo de ventas, margen bruto comercial, rotacion inventarios, CCE

## Slides Adicionales
1. KPIs BANCARIOS: tabla peer comparison (BCP vs BBVA vs IBK vs SBP vs Sistema) con ROE, ROA, CAR, eficiencia, prima riesgo
2. CALIDAD CARTERA: evolucion CAR y cobertura, composicion por tipo credito (corporativo, grandes, medianas, pequenas, consumo, hipotecario)
3. FONDEO: doughnut composicion depositos (vista, ahorro, plazo), participacion depositos bajo costo vs activo

## Benchmarks Ratios (adaptados a banca)
ROE: bajo <10, normal 10-18, solido >18
ROA: bajo <1.0, normal 1.0-2.0, solido >2.0
Mg Fin Bruto: bajo <60, normal 60-72, solido >72
Ratio Eficiencia: ineficiente >42, normal 36-42, eficiente <36
CAR: alto >7.0, moderado 5.0-7.0, bueno <5.0
Cobertura CAR: insuficiente <90, adecuado 90-110, holgado >110
RCG: ajustado <13, adecuado 13-17, holgado >17
Prima Riesgo: alto >3.5, normal 2.0-3.5, bajo <2.0

## Alertas
- RCG <12: proximidad al minimo regulatorio, evaluar necesidad capitalizacion
- CAR >8: deterioro significativo, revisar politicas de originacion
- Cobertura CAR <85: provisiones insuficientes, riesgo de requerimiento SBS
- Ratio eficiencia >45: gastos admin presionan rentabilidad
- Concentracion fondeo plazo >40 pct depositos: riesgo refinanciamiento
- Patrimonio negativo o RCG <10: incumplimiento regulatorio SBS

## Fuentes Datos Peru
- SBS: estadisticas sistema financiero (https://www.sbs.gob.pe/estadisticas)
- SMV: EEFF auditados de bancos listados
- Clasificadoras: AAI/FitchRatings, Moody's Local, PCR
- BCRP: Reporte Estabilidad Financiera
