# Sector: Construccion / Inmobiliario

## Identificacion
Triggers: obras en curso, avance de obra, presupuesto de obra, valorizaciones, retencion garantia, subcontratistas, adelantos obra, liquidacion

## interview_q3_options
Obras en ejecucion actualmente | Recibe adelantos de clientes | Demora en valorizaciones/cobros | Proyecto inmobiliario venta departamentos

## KPIs Especificos

### Margen por Proyecto = (Ingreso - Costo) / Ingreso x 100
>15 solido, 10-15 normal, <10 ajustado, <5 riesgo

### Backlog / Ventas = Contratos Pendientes / Ventas Periodo
>12 meses excelente, 6-12 bueno, <6 presion comercial. Si no hay dato omitir.

### Avance vs Presupuesto = Costo Real / Costo Presupuestado x 100
<100 bien, 100-110 sobre-costo controlable, >110 alerta

## Slides Adicionales
1. ANALISIS DE PROYECTOS: Margen por obra, avance vs presupuesto, backlog

## Benchmarks Ratios
Ratio Corriente: riesgo <0.90, adecuado 0.90-1.40, solido >1.40
D/E: conservador <1.50, moderado 1.50-3.00, alto >3.00
Margen Bruto: bajo <15, normal 15-25, solido >25
Margen Op: bajo <5, normal 5-10, solido >10
Margen Neto: bajo <3, normal 3-7, solido >7
ROE: bajo <8, normal 8-20, solido >20

## Alertas
- Obras en curso >50 pct activo: capital concentrado en proyectos
- CxC valorizaciones >60 dias: demora afecta flujo
- Adelantos sin avance: riesgo incumplimiento
