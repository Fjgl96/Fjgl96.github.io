# Sector: Distribución / Wholesale

## Identificación
Triggers: mercaderías, clientes por cobrar alto, líneas de producto, distribuidores,
canales, crédito a clientes, almacén, despacho, flota, productos veterinarios,
importación, tipo de cambio, spread cambiario, factoring, cobranza

## Subsectores
Distribución General | Productos Veterinarios/Agro | Productos Industriales |
Alimentos/FMCG | Tecnología/Equipos | Farmacéutico

## interview_q3_options
Exposición cambiaria USD/PEN | Alta concentración de clientes | Estacionalidad sector |
Cambio de proveedor o línea | Política de crédito modificada | Presión de precios por ciclo

## Preguntas Adicionales (Nivel 2-3)
- ¿Qué porcentaje de ventas/compras son en USD vs moneda local?
- ¿Tienen línea de crédito con proveedores? ¿Plazo?
- ¿Existe concentración de clientes (top 10 > 50% ventas)?
- ¿El sector de sus clientes tiene estacionalidad o ciclos de precios?
- ¿Hay productos con exclusividad o representación de marca?

---

## KPIs Específicos

### Concentración de Clientes = Ventas Top 10 / Ventas Totales × 100
```
<30%    diversificado (bajo riesgo)
30-50%  moderado (monitorear)
50-70%  concentrado (riesgo medio-alto)
>70%    CRÍTICO: dependencia de pocos clientes
```
**Interpretación para veterinarios/agro:** Los clientes son granjas avícolas y porcinas.
Sus márgenes dependen de precios de commodities (huevo, cerdo). Cuando los precios
caen, los clientes resisten aumentos de precio → presión sobre el margen del distribuidor.
Si top 10 >50%, un ciclo bajo del sector avícola puede impactar 50%+ de cobranza.

### DSO = CxC Comerciales / (Ventas / 360)
```
<30 días     excelente (difícil en Perú)
30-60 días   normal para distribución
60-90 días   monitorear → evaluar provisión
>90 días     RIESGO: cartera envejecida, evaluar incobrabilidad
```
**Edge case:** Si ventas son mensuales pero CxC incluye facturas de meses anteriores,
el DSO se infla. Verificar si hay notas de crédito pendientes que distorsionan CxC.

### Rotación de Inventarios = CV / Inventarios
```
>8x (45 días)   eficiente
6-8x (45-60d)   normal
4-6x (60-90d)   lento, capital atrapado
<4x (>90 días)  CRÍTICO: revisar obsolescencia y lotes vencidos
```
**Para productos veterinarios:** Los productos farmacéuticos tienen vida útil limitada.
Rotación <4x puede implicar riesgo de vencimiento además de capital atrapado.

### Margen por Línea de Producto (si hay detalle)
Distribuidores típicamente manejan márgenes brutos entre 10-25% según producto.
- Productos exclusivos/representados: margen más alto (18-25%)
- Commodities/genéricos: margen bajo (8-15%)
- Evaluar si hay subsidios cruzados entre líneas

### Spread Cambiario (si hay operaciones en USD)
```
Exposición neta = (Pasivos USD - Activos USD) × TC
Estructura de cobertura natural:
  - Si compras USD ≈ ventas USD → hedge natural
  - Si deuda USD > ingresos USD → exposición negativa a depreciación PEN
```
**Para distribuidores con proveedores internacionales:**
- Evaluar si precio de venta se indexa a TC (passthrough)
- Si hay desfase temporal entre compra (USD) y cobro (PEN) → riesgo cambiario
- Monitorear pérdida por diferencia de cambio como % de ventas

### Días de Efectivo = Efectivo / ((CV + Gastos Op) / 30)
```
>30 días    holgura operativa
15-30 días  normal
<15 días    presión de liquidez
<7 días     CRÍTICO: riesgo de incumplimiento de nómina/proveedores
```

### Ciclo de Conversión de Efectivo (CCE)
```
CCE = Edad Inventario + Periodo Cobro - Periodo Pago
```
Para distribuidores, el CCE ideal depende de:
- Plazo que dan a clientes vs plazo que reciben de proveedores
- Si CCE > 60 días → evaluar factoring o descuento por pronto pago
- Si CCE negativo → excelente, se financian con proveedores

---

## Slides Adicionales

### 1. ANÁLISIS DE CARTERA Y EFICIENCIA OPERATIVA
Layout: Tipo D (gráfico + tabla)

**Lado izquierdo (gráfico):**
- Barras horizontales: DSO, Rotación Inventarios, Período Pago, CCE
- O si hay detalle: composición de CxC por antigüedad

**Lado derecho (tabla resumen):**
```
| KPI                     | Valor  | Benchmark | Eval  |
|------------------------|--------|-----------|-------|
| DSO (días)             | XX     | 30-60     | 🟢🟡🔴 |
| Rotación Inventarios   | XXx    | >6x       | 🟢🟡🔴 |
| CCE (días)             | XX     | <60       | 🟢🟡🔴 |
| Concentración Top 10   | XX%    | <50%      | 🟢🟡🔴 |
| Días Efectivo          | XX     | >15       | 🟢🟡🔴 |
```

### 2. ANÁLISIS CAMBIARIO (condicional: si hay operaciones USD)
Solo incluir si se detectan cuentas en USD o pérdida por diferencia de cambio.
- Estructura de exposición: Activos USD vs Pasivos USD
- Pérdida/ganancia por TC como % de ventas
- Si hay hedge natural (ventas USD ≈ compras USD), explicar

---

## Benchmarks Ratios Generales

```
Ratio Corriente:    riesgo <0.85   adecuado 0.85-1.30   sólido >1.30
Prueba Ácida:       riesgo <0.50   adecuado 0.50-0.80   sólido >0.80
D/E:                conservador <2.0   moderado 2.0-4.0   alto >4.0
Endeudamiento:      bajo <0.50   moderado 0.50-0.75   alto >0.75
Margen Bruto:       bajo <10%   normal 10-18%   sólido >18%
Margen Operativo:   bajo <2%   normal 2-5%   sólido >5%
Margen Neto:        bajo <1%   normal 1-3%   sólido >3%
ROE: bajo <8, normal 8-20, solido >20
```

**Nota sobre márgenes:** Distribución opera con márgenes bajos pero alto volumen.
Un margen neto de 2% puede ser saludable si la rotación es alta.
Evaluar rentabilidad junto con eficiencia: ROA = Margen × Rotación de Activos.

---

## Alertas Automáticas

```
DSO >90 días          → "Cartera envejecida. Evaluar provisión de incobrables y
                         política de crédito. Considerar factoring."
Concentración >50%    → "Alta dependencia de pocos clientes. Riesgo de concentración.
                         Evaluar programa de diversificación comercial."
Rotación <4x          → "Inventarios lentos (>90 días). Capital atrapado.
                         Revisar productos de baja rotación y riesgo de obsolescencia."
CxC >40% del Activo   → "Portafolio de crédito sobredimensionado. Evaluar factoring
                         o descuento por pronto pago."
Pérdida TC >2% ventas → "Exposición cambiaria material. Evaluar cobertura natural
                         o instrumentos de hedging."
CCE >90 días          → "Ciclo de conversión extenso. Presión sobre capital de trabajo.
                         Renegociar plazos con proveedores o clientes."
D/E >4.0              → "Apalancamiento alto para distribución. Evaluar capacidad de
                         servicio de deuda y riesgo de refinanciamiento."
Margen Bruto <10%     → "Márgenes de distribución bajo presión. Revisar pricing,
                         mix de productos y poder de negociación con proveedores."
```

---

## Contexto Sectorial para Interpretación

### Ciclo del Negocio Agropecuario
Los distribuidores de insumos para granjas (avícolas, porcinas) enfrentan:
- Cuando precio de huevo/cerdo sube → granjas rentables → pagan puntual → DSO bajo
- Cuando precio cae → granjas con margen presionado → resisten aumentos → DSO sube
- Estacionalidad: demanda de insumos puede tener picos por ciclos productivos

### Estructura Típica de un Distribuidor
- Activo concentrado en CxC e Inventarios (60-80% del AC)
- Pasivo concentrado en CxP comerciales (proveedores principales)
- Si tiene exclusividad de marca → poder de pricing, pero dependencia del proveedor
- Costo de capital bajo vs retail porque los ciclos son más predecibles
