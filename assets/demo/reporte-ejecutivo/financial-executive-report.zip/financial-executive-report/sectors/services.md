# Sector: Servicios Profesionales

## Identificacion
Triggers: honorarios, consultoria, asesoria, horas facturables, proyectos, profesionales, staff, outsourcing, BPO

## interview_q3_options
Contratos recurrentes vs proyectos puntuales | Estacionalidad demanda | Crecimiento headcount | Dependencia pocos clientes grandes

## KPIs Especificos

### Revenue per Employee = Ventas / Numero Empleados
Si no hay headcount estimar: Total Remuneraciones / Sueldo Promedio.
Benchmark Peru consultoria: S/ 8000-15000/empleado/mes.

### Utilizacion pct = Horas Facturadas / Horas Disponibles x 100
>75 excelente, 65-75 normal, <65 capacidad ociosa. Si no hay dato omitir.

### Labor Cost pct = Total Remuneraciones / Ventas x 100
Benchmark servicios: 40-60 normal (personal ES el producto).

## Slides Adicionales
1. EFICIENCIA OPERATIVA: Revenue per employee, labor cost, estructura gastos

## Benchmarks Ratios
Ratio Corriente: riesgo <1.00, adecuado 1.00-1.80, solido >1.80
D/E: conservador <1.00, moderado 1.00-2.00, alto >2.00
Margen Bruto: bajo <40, normal 40-60, solido >60
Margen Op: bajo <10, normal 10-20, solido >20
Margen Neto: bajo <8, normal 8-15, solido >15
ROE: bajo <8, normal 8-20, solido >20
ROA: bajo <5, normal 5-12, solido >12

## Alertas
- Labor Cost >65: costo personal excede benchmark
- CxC >3 meses ventas: cobros lentos
- Concentracion >50 pct un cliente: riesgo dependencia
