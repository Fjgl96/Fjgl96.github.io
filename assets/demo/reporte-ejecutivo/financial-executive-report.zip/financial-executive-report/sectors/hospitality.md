# Sector: Hoteleria / Turismo

## Identificacion
Triggers: habitaciones, check-in, check-out, tarifa promedio, ocupacion, revenue per room, housekeeping, OTAs, booking, alimentos y bebidas hotelero

## interview_q3_options
Temporada alta/baja turismo feriados | Dependencia OTAs vs venta directa | Renovacion remodelacion | Nuevo competidor zona

## KPIs Especificos

### RevPAR = Ingresos Habitaciones / Habitaciones Disponibles
O: RevPAR = ADR x Ocupacion pct
Benchmark Peru Lima 4-5 estrellas: USD 50-100/noche.

### ADR = Ingresos Habitaciones / Habitaciones Vendidas
Si no hay detalle omitir.

### Ocupacion pct = Hab Vendidas / Hab Disponibles x 100
>75 excelente, 60-75 normal, <60 preocupante.

### GOP Margin = (Ingresos - Gastos Op) / Ingresos x 100
>35 excelente, 25-35 normal, <25 bajo presion.

## Slides Adicionales
1. EFICIENCIA HOTELERA: RevPAR, ocupacion, GOP margin, mix ingresos hab vs A&B vs otros

## Benchmarks Ratios
Ratio Corriente: riesgo <0.80, adecuado 0.80-1.30, solido >1.30
D/E: conservador <2.00, moderado 2.00-4.00, alto >4.00
Margen Bruto: bajo <50, normal 50-65, solido >65
Margen Op: bajo <10, normal 10-25, solido >25
Margen Neto: bajo <5, normal 5-15, solido >15
ROE: bajo <8, normal 8-20, solido >20

## Alertas
- Ocupacion <50: sub-utilizacion critica pricing dinamico
- Comisiones OTAs >20 pct ventas: desarrollar canal directo
- Alquiler >15 pct ventas: costo infra presiona margenes
- A&B margen negativo: evaluar externalizacion
