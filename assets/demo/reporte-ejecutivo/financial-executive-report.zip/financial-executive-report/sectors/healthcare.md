# Sector: Salud / Clinicas

## Identificacion
Triggers: pacientes, camas, consultas, procedimientos, farmacia, laboratorio, EPS, SIS, seguros, IPRESS, honorarios medicos, insumos medicos

## interview_q3_options
Mix aseguradoras EPS/SIS/particulares | Especialidad principal | Inversion equipamiento medico | Demora pagos aseguradoras

## KPIs Especificos

### Revenue per Cama-Dia = Ingresos / (Camas x Dias Periodo)
Solo clinicas con hospitalizacion. Benchmark Peru: S/ 300-800/cama-dia.

### Ocupacion Camas pct = Dias-Cama Ocupados / Dias-Cama Disponibles x 100
>80 optimo, 65-80 normal, <65 subutilizacion. Si no hay dato omitir.

### Mix Ingresos por Pagador
EPS / SIS / Particular / Otros. Alto pct SIS = menor margen y demora cobro.

## Slides Adicionales
1. EFICIENCIA CLINICA: Mix ingresos por pagador, estructura costos personal vs insumos vs infra

## Benchmarks Ratios
Ratio Corriente: riesgo <1.00, adecuado 1.00-1.50, solido >1.50
D/E: conservador <1.00, moderado 1.00-2.50, alto >2.50
Margen Bruto: bajo <30, normal 30-50, solido >50
Margen Op: bajo <5, normal 5-15, solido >15
Margen Neto: bajo <3, normal 3-10, solido >10
ROE: bajo <8, normal 8-20, solido >20

## Alertas
- CxC EPS/SIS >90 dias: demora sistematica aseguradoras
- Equipamiento depreciacion >70 pct: riesgo operacional
- Personal medico >50 pct ventas: evaluar productividad o pricing
