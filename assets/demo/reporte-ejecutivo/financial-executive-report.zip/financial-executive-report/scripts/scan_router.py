#!/usr/bin/env python3
"""
scan_router.py — Decision Engine for Financial Report V4

Analyzes data.json + ratios.json and produces slide_plan.json
containing ALL routing decisions for report generation.

Usage:
    python scan_router.py data.json ratios.json \
        --sector restaurants --country peru --mode diagnostic \
        --output slide_plan.json
"""

import json
import sys
import argparse
from pathlib import Path


# ─────────────────────────────────────────────────────────────
# LECTURA DE ratios.json
#
# calculate_ratios.py devuelve una estructura ANIDADA:
#   {ratios: {<periodo>: {rentabilidad: {...}, liquidez: {...}}}, variaciones: {...}}
# pero classify_severity leía claves PLANAS (ratios.get("margen_operativo")),
# que nunca existen: devolvían el default y dejaban los seis umbrales del
# clasificador como código muerto. Cualquier empresa con patrimonio sano salía
# "sano" aunque el operativo se hubiera desplomado.
# ─────────────────────────────────────────────────────────────
def _ultimo_periodo(ratios):
    ps = ratios.get("periodos") or sorted(ratios.get("ratios", {}).keys())
    return ps[-1] if ps else None


def rat(ratios, familia, clave, default=0):
    """Lee un ratio del último periodo, sea cual sea la familia."""
    p = _ultimo_periodo(ratios)
    if p is None:
        return default
    v = ratios.get("ratios", {}).get(p, {}).get(familia, {}).get(clave)
    return v if isinstance(v, (int, float)) else default


def var_pct(ratios, clave, default=None):
    """Variación porcentual de una línea contra el periodo anterior."""
    vs = ratios.get("variaciones") or {}
    for _, bloque in vs.items():
        if clave in bloque and isinstance(bloque[clave], dict):
            return bloque[clave].get("pct", default)
    return default


def var_monto(ratios, clave, default=None):
    vs = ratios.get("variaciones") or {}
    for _, bloque in vs.items():
        if clave in bloque and isinstance(bloque[clave], dict):
            return bloque[clave].get("monto", default)
    return default


# ─────────────────────────────────────────────────────────────
# SEVERITY CLASSIFIER
# ─────────────────────────────────────────────────────────────
def classify_severity(ratios, data):
    """
    Clasifica la situación general en 3 niveles.
    Determina tono, colores de cajas, urgencia de footers.
    """
    score = 0  # 0-10: 0-3 sano, 4-6 riesgo, 7+ critico

    pat = data["esf"]["patrimonio"]["total_patrimonio"]
    activo = data["esf"]["totales"]["activo"]

    # Patrimonio negativo = automáticamente crítico
    if pat < 0:
        score += 4

    # Patrimonio < 20% activo
    elif pat / activo < 0.20:
        score += 2

    # EBIT negativo
    if rat(ratios, "rentabilidad", "margen_operativo_pct", 0) < 0:
        score += 2

    # EBIT < -10% ventas
    if rat(ratios, "rentabilidad", "margen_operativo_pct", 0) < -10:
        score += 1

    # Ratio corriente < 0.8
    if rat(ratios, "liquidez", "ratio_corriente", 1) < 0.8:
        score += 1

    # EBITDA negativo
    if rat(ratios, "rentabilidad", "ebitda", 0) < 0:
        score += 1

    # Resultado neto negativo
    if rat(ratios, "rentabilidad", "margen_neto_pct", 0) < 0:
        score += 1

    # ── Deterioro entre periodos ──────────────────────────────────────────
    # Un solo corte no ve una caída. Estas tres sí, y son las que separan a
    # una empresa que está bien de una que venía bien.
    vo = var_pct(ratios, "margen_operativo")
    if vo is not None and vo <= -25:
        score += 2
    elif vo is not None and vo <= -10:
        score += 1

    # Cobertura de intereses: el umbral clásico es 3x; por debajo de 1.5x el
    # resultado operativo ya casi no paga el servicio de deuda.
    cob = rat(ratios, "rentabilidad", "cobertura_intereses", None)
    if isinstance(cob, (int, float)):
        if cob < 1.5:
            score += 3
        elif cob < 3.0:
            score += 1

    if score >= 7:
        return "critico"
    elif score >= 4:
        return "riesgo"
    else:
        return "sano"


# ─────────────────────────────────────────────────────────────
# DISTORTION DETECTOR
# ─────────────────────────────────────────────────────────────
def detect_distortions(data, ratios):
    """
    Identifica datos que no reflejan la realidad operativa.
    Cada distorsión ajusta la interpretación de ratios específicos.
    """
    distortions = []

    pat = data["esf"]["patrimonio"]["total_patrimonio"]
    resultado = data["egp"]["resultado_ejercicio"]

    # Patrimonio negativo → ROE y D/E no interpretables
    if pat < 0:
        distortions.append({
            "type": "patrimonio_negativo",
            "impact": ["roe", "de_ratio"],
            "note": "ROE y D/E no son interpretables con patrimonio negativo. Usar ROA como proxy de rentabilidad.",
            "severity": "critical"
        })

    # Ingresos no recurrentes materiales (>30% del resultado)
    no_recurrentes = abs(data["egp"].get("dif_cambio", 0)) + \
                     abs(data["egp"].get("otros_ingresos", 0)) + \
                     abs(data["egp"].get("auspicios", 0))
    if resultado != 0 and no_recurrentes > abs(resultado) * 0.30:
        adjusted = resultado - data["egp"].get("dif_cambio", 0) - \
                   data["egp"].get("otros_ingresos", 0) - \
                   data["egp"].get("auspicios", 0)
        distortions.append({
            "type": "no_recurrente_material",
            "impact": ["margen_neto"],
            "no_recurrente_total": round(no_recurrentes, 0),
            "resultado_ajustado": round(adjusted, 0),
            "note": f"Resultado depende de ingresos no recurrentes (S/ {no_recurrentes:,.0f}). Sin ellos, resultado sería S/ {adjusted:,.0f}.",
            "severity": "warning"
        })

    # Gastos preoperativos materiales en AC (>15% del AC)
    preop = data["esf"]["activo_corriente"].get("gastos_anticipados", 0)
    total_ac = data["esf"]["activo_corriente"]["total_ac"]
    if total_ac > 0 and preop / total_ac > 0.15:
        distortions.append({
            "type": "preoperativo_material",
            "impact": ["ratio_corriente", "prueba_acida"],
            "preoperativo": round(preop, 0),
            "pct_ac": round(preop / total_ac * 100, 1),
            "note": f"AC incluye gastos preoperativos no líquidos de S/ {preop:,.0f} ({preop/total_ac*100:.1f}% del AC). Liquidez real es menor.",
            "severity": "warning"
        })

    # Deuda concentrada en relacionadas (>80% del pasivo total)
    pasivo_total = data["esf"]["pasivo_corriente"]["total_pc"] + \
                   data["esf"]["pasivo_no_corriente"]["total_pnc"]
    deuda_relacionadas = data["esf"]["pasivo_no_corriente"].get("cxp_accionistas_nc", 0) + \
                         data["esf"]["pasivo_corriente"].get("cxp_relacionadas", 0)
    if pasivo_total > 0 and deuda_relacionadas / pasivo_total > 0.80:
        distortions.append({
            "type": "deuda_relacionadas_dominante",
            "impact": ["endeudamiento", "de_ratio"],
            "deuda_relacionadas": round(deuda_relacionadas, 0),
            "pct_pasivo": round(deuda_relacionadas / pasivo_total * 100, 1),
            "note": f"Deuda con relacionadas (S/ {deuda_relacionadas:,.0f}) es {deuda_relacionadas/pasivo_total*100:.0f}% del pasivo. Capitalizable — no es deuda con terceros.",
            "severity": "info"
        })

    # ── R-DISTORT · PUENTE NO OPERATIVO ───────────────────────────────────
    # La distorsión que ninguna regla de una sola foto puede ver: el resultado
    # neto MEJORA mientras el operativo CAE, y lo que cierra la brecha es una
    # partida que no viene del negocio (diferencia de cambio, venta de activos,
    # otros ingresos de gestión).
    #
    # La regla `no_recurrente_material` de arriba mide el PESO de lo no
    # recurrente en un año suelto: dispararía igual en un año donde el operativo
    # y el neto suben juntos. Esta mide la DIRECCIÓN de los dos resultados y el
    # tamaño del puente entre ellos, que es lo que convierte un buen titular en
    # una lectura equivocada. Por eso es severidad alta y no comentario al pie:
    # quien lee "resultado +10%" y no ve esto, lee exactamente al revés.
    vo = var_pct(ratios, "margen_operativo")
    vn = var_pct(ratios, "resultado_neto")
    mo = var_monto(ratios, "margen_operativo")
    if (vo is not None and vn is not None and vo <= -10 and vn > 0):
        no_op_actual = (data["egp"].get("dif_cambio", 0)
                        + data["egp"].get("otros_ingresos", 0)
                        + data["egp"].get("auspicios", 0))
        brecha = abs(mo or 0)
        if brecha > 0 and abs(no_op_actual) >= brecha * 0.50:
            resultado_sin = resultado - no_op_actual
            distortions.append({
                "type": "puente_no_operativo",
                "impact": ["margen_neto", "resultado_ejercicio", "lectura_general"],
                "var_operativo_pct": vo,
                "var_neto_pct": vn,
                "no_operativo": round(no_op_actual, 0),
                "resultado_sin_no_operativo": round(resultado_sin, 0),
                "note": (f"El resultado operativo cae {abs(vo):.1f}% y el resultado neto sube "
                         f"{vn:.1f}%. El puente entre ambos son S/ {no_op_actual:,.0f} de partidas "
                         f"no operativas. Sin ellas el resultado sería S/ {resultado_sin:,.0f}. "
                         f"La mejora del neto no proviene de la operación."),
                "severity": "critical"
            })

    return distortions


# ─────────────────────────────────────────────────────────────
# ALERT GENERATOR
# ─────────────────────────────────────────────────────────────
def generate_alerts(data, ratios, sector, country):
    """Genera alertas regulatorias y operativas."""
    alerts = []

    pat = data["esf"]["patrimonio"]["total_patrimonio"]
    capital = data["esf"]["patrimonio"].get("capital", 0)
    perdidas_acum = abs(data["esf"]["patrimonio"].get("perdidas_acum", 0))
    resultado = data["esf"]["patrimonio"].get("resultado_ejercicio", 0)

    # Peru: Art. 407 LGS — Causal de disolución
    if country == "peru" and capital > 0:
        total_perdidas = perdidas_acum + abs(min(resultado, 0))
        if total_perdidas > capital * (2/3):
            alerts.append({
                "type": "causal_disolucion",
                "regulation": "Art. 407 LGS",
                "description": f"Pérdidas acumuladas (S/ {total_perdidas:,.0f}) superan 2/3 del capital social (S/ {capital:,.0f}). Causal de disolución vigente.",
                "urgency": "immediate",
                "action": "Convocar junta de accionistas para capitalizar, aportar o disolver."
            })
        elif total_perdidas > capital * 0.50:
            alerts.append({
                "type": "reduccion_capital",
                "regulation": "Art. 220 LGS",
                "description": f"Pérdidas acumuladas (S/ {total_perdidas:,.0f}) superan 50% del capital (S/ {capital:,.0f}). Obligación de reducir capital.",
                "urgency": "short_term",
                "action": "Evaluar reducción de capital o aporte de socios."
            })

    # Liquidez crítica: días de efectivo < 15
    if ratios.get("dias_cobertura", 30) < 15:
        alerts.append({
            "type": "liquidez_critica",
            "description": f"Efectivo cubre solo {ratios['dias_cobertura']:.0f} días de operación (benchmark: 30+ días).",
            "urgency": "immediate",
            "action": "Gestionar línea de crédito o adelanto de proveedores."
        })

    # Restaurants: prime cost > 70%
    if sector == "restaurants" and ratios.get("prime_cost_pct", 0) > 70:
        alerts.append({
            "type": "prime_cost_destructivo",
            "description": f"Prime cost de {ratios['prime_cost_pct']:.1f}% excede 70%. La operación destruye valor antes de costos fijos.",
            "urgency": "short_term",
            "action": "Revisar food cost (porciones, proveedores) y estructura de personal."
        })

    # PE no alcanzado
    if ratios.get("cobertura_pe_pct", 100) < 80:
        alerts.append({
            "type": "pe_no_alcanzado",
            "description": f"Ventas cubren solo {ratios['cobertura_pe_pct']:.1f}% del punto de equilibrio.",
            "urgency": "short_term",
            "action": "Incrementar ventas o reducir costos fijos para alcanzar PE."
        })

    return alerts


# ─────────────────────────────────────────────────────────────
# SLIDE PLAN BUILDER
# ─────────────────────────────────────────────────────────────
def build_slide_list(data, sector, mode):
    """
    Construye la lista de slides a generar y su configuración.
    El 'mode' es el factor determinante de qué slides incluir.
    """
    complementary = data.get("complementary", {})
    periods = data.get("data_quality", {}).get("periods_found", 1)

    slides = []

    # ── PORTADA (siempre) ──
    slides.append({"id": "portada", "type": "cover", "template": "slide_portada"})

    # ── RESUMEN EJECUTIVO ──
    if mode == "diagnostic":
        slides.append({
            "id": "resumen",
            "type": "B",  # KPI cards grid
            "template": "slide_resumen_diagnostic",
            "include_stakeholder": True
        })
    else:  # status
        slides.append({
            "id": "resumen",
            "type": "B",
            "template": "slide_resumen_status",
            "include_stakeholder": False,
            "include_deltas": True
        })

    # ── ESTADO DE RESULTADOS ──
    egp_config = {
        "id": "egp",
        "type": "A",  # Tabla + bullets
        "template": "slide_egp"
    }
    if mode == "status" and periods >= 2:
        egp_config["columns"] = ["actual", "anterior", "variacion", "var_pct"]
        egp_config["comment_depth"] = "light"  # Solo summary, bullets factuales cortos
    else:
        egp_config["columns"] = ["actual", "pct_vertical"]
        egp_config["comment_depth"] = "full"  # 3 capas completas
    slides.append(egp_config)

    # ── SLIDE SECTORIAL ──
    sector_template_map = {
        "restaurants": "slide_kpi_restaurants",
        "distribution": "slide_kpi_distribution",
        "retail": "slide_kpi_retail",
        "construction": "slide_kpi_construction",
    }
    if sector in sector_template_map:
        sect_config = {
            "id": "sectorial",
            "type": "D",  # Chart + tabla
            "template": sector_template_map[sector],
            "benchmark_mode": "sector" if mode == "diagnostic" else "delta"
        }
        slides.append(sect_config)

    # ── ESF ACTIVOS ──
    esf_act_config = {
        "id": "esf_activos",
        "type": "A",
        "template": "slide_esf_activos"
    }
    if mode == "status" and periods >= 2:
        esf_act_config["columns"] = ["actual", "anterior", "variacion", "var_pct"]
        esf_act_config["comment_depth"] = "light"
    else:
        esf_act_config["columns"] = ["actual", "pct_vertical"]
        esf_act_config["comment_depth"] = "full"
    slides.append(esf_act_config)

    # ── ESF PASIVO Y PATRIMONIO ──
    esf_pp_config = {
        "id": "esf_pasivo_patrimonio",
        "type": "A",
        "template": "slide_esf_pasivo"
    }
    if mode == "status" and periods >= 2:
        esf_pp_config["columns"] = ["actual", "anterior", "variacion", "var_pct"]
        esf_pp_config["comment_depth"] = "light"
    else:
        esf_pp_config["columns"] = ["actual", "pct_vertical"]
        esf_pp_config["comment_depth"] = "full"
    slides.append(esf_pp_config)

    # ── RATIOS ──
    ratios_config = {
        "id": "ratios",
        "type": "A",
        "template": "slide_ratios"
    }
    if mode == "diagnostic":
        ratios_config["eval_mode"] = "benchmark"   # Heatmap vs benchmarks
    else:
        ratios_config["eval_mode"] = "delta"        # Flechas ↑↓ vs anterior
    slides.append(ratios_config)

    # ── SLIDES CONDICIONALES ──
    if complementary.get("has_cost_detail") and mode == "diagnostic":
        slides.append({
            "id": "pareto_costos",
            "type": "D",
            "template": "slide_pareto_gastos",
            "comment_depth": "full" if mode == "diagnostic" else "light"
        })

    if complementary.get("has_centro_costos"):
        slides.append({
            "id": "centro_costos",
            "type": "D",
            "template": "slide_centro_costos"
        })

    # ── ESTRUCTURA FINANCIERA ──
    estructura_config = {
        "id": "estructura",
        "type": "C",  # Charts full width
        "template": "slide_estructura"
    }
    if periods >= 2:
        estructura_config["chart_type"] = "stacked_bars"  # Comparativo
    else:
        estructura_config["chart_type"] = "doughnut_pair"
    slides.append(estructura_config)

    # ── CONCLUSIONES (solo diagnostic) vs EVOLUCIÓN (solo status) ──
    if mode == "diagnostic":
        slides.append({
            "id": "conclusiones",
            "type": "E",  # 3 bloques
            "template": "slide_conclusiones",
            "blocks": ["hallazgos", "riesgos", "prioridades"]
        })
    else:
        slides.append({
            "id": "evolucion",
            "type": "A",
            "template": "slide_evolucion",
            "show_trend_arrows": True
        })

    # ── CIERRE (siempre) ──
    slides.append({"id": "cierre", "type": "cover", "template": "slide_cierre"})

    # Asignar page numbers
    for i, s in enumerate(slides):
        s["page_num"] = i + 1

    return slides


# ─────────────────────────────────────────────────────────────
# CHART SELECTOR
# ─────────────────────────────────────────────────────────────
def select_charts(data, ratios, mode):
    """Decide qué tipo de chart usar en cada slide."""
    charts = {}
    complementary = data.get("complementary", {})
    periods = data.get("data_quality", {}).get("periods_found", 1)

    # Estructura: doughnut vs stacked bars
    if periods >= 2:
        charts["estructura"] = "stacked_bars_comparison"
    else:
        charts["estructura"] = "doughnut_pair"

    # Sectorial: pareto vs cards
    if complementary.get("has_cost_detail"):
        charts["sectorial"] = "horizontal_bars_pareto"
    else:
        charts["sectorial"] = "kpi_cards_only"

    # Ventas mensuales: si hay data
    if complementary.get("has_monthly_egp"):
        charts["ventas_trend"] = "line_monthly"

    # Mode-specific
    if mode == "status" and periods >= 2:
        charts["resumen"] = "kpi_cards_with_deltas"
        charts["ratios"] = "table_with_arrows"
    else:
        charts["resumen"] = "kpi_cards_with_semaphore"
        charts["ratios"] = "table_with_heatmap"

    return charts


# ─────────────────────────────────────────────────────────────
# COMMENT TEMPLATE SELECTOR
# ─────────────────────────────────────────────────────────────
def select_comment_templates(ratios, severity, mode):
    """
    Selecciona qué template de comentario usar en cada slide.

    Mode "diagnostic": 3 capas (summary + bullets + footer)
    Mode "status": 1 capa (summary only, factual)
    """
    templates = {}

    # EGP
    if ratios.get("margen_operativo", 0) < -10:
        templates["egp_summary"] = "negative" if mode == "diagnostic" else "delta_negative"
    elif ratios.get("margen_operativo", 0) < 0:
        templates["egp_summary"] = "mixed" if mode == "diagnostic" else "delta_mixed"
    else:
        templates["egp_summary"] = "positive" if mode == "diagnostic" else "delta_positive"

    # ESF Activos
    dias_cob = ratios.get("dias_cobertura", 30)
    if dias_cob < 15:
        templates["esf_act_summary"] = "negative"
    elif dias_cob < 30:
        templates["esf_act_summary"] = "mixed"
    else:
        templates["esf_act_summary"] = "positive"

    # ESF Pasivo
    if ratios.get("patrimonio", 0) < 0:
        templates["esf_pp_summary"] = "alert"
    elif ratios.get("endeudamiento", 0) > 80:
        templates["esf_pp_summary"] = "negative"
    else:
        templates["esf_pp_summary"] = "positive"

    # Footer severity
    if mode == "diagnostic":
        templates["footer_default"] = severity  # sano→normal, riesgo→warning, critico→critical
    else:
        templates["footer_default"] = "informational"  # Nunca accionable en status mode

    return templates


# ─────────────────────────────────────────────────────────────
# MAIN: ASSEMBLE slide_plan.json
# ─────────────────────────────────────────────────────────────
def build_plan(data, ratios, sector, country, mode):
    """Ensambla el plan completo de routing."""

    severity = classify_severity(ratios, data)
    distortions = detect_distortions(data, ratios)

    # Una distorsión crítica no puede convivir con un veredicto "sano": si la
    # lectura del año depende de una partida ajena al negocio, el reporte tiene
    # que entrar con otro tono.
    if any(d.get("severity") == "critical" for d in distortions) and severity == "sano":
        severity = "riesgo"
    alerts = generate_alerts(data, ratios, sector, country)
    slides = build_slide_list(data, sector, mode)
    charts = select_charts(data, ratios, mode)
    comment_templates = select_comment_templates(ratios, severity, mode)

    plan = {
        "version": "4.0",
        "mode": mode,
        "sector": sector,
        "country": country,
        "empresa": data.get("empresa", ""),
        "periodo": data.get("periodo", ""),
        "moneda": data.get("moneda", "PEN"),

        # Routing decisions
        "severity": severity,
        "periods": data.get("data_quality", {}).get("periods_found", 1),
        "data_richness": assess_data_richness(data),

        # Analysis results
        "distortions": distortions,
        "alerts": alerts,

        # Presentation decisions
        "slides": slides,
        "charts": charts,
        "comment_templates": comment_templates,

        # Mode-specific config
        "mode_config": get_mode_config(mode, severity)
    }

    return plan


def assess_data_richness(data):
    """Evalúa cuánta data complementaria hay disponible."""
    comp = data.get("complementary", {})
    score = 0
    if comp.get("has_cost_detail"): score += 1
    if comp.get("has_centro_costos"): score += 1
    if comp.get("has_monthly_egp"): score += 1
    if comp.get("has_gastos_detalle"): score += 1
    if comp.get("has_usd_operations"): score += 1

    if score >= 4: return "rich"
    elif score >= 2: return "standard"
    else: return "minimal"


def get_mode_config(mode, severity):
    """Configuración específica por modo."""
    if mode == "diagnostic":
        return {
            "summary_box_style": "interpretive",   # Hallazgo con implicación
            "bullet_style": "dato_causa_accion",    # 3 capas
            "footer_style": "action_oriented",      # Forward-looking con acción
            "kpi_eval_against": "benchmark",         # Semáforo vs sector
            "include_recommendations": True,
            "include_risk_matrix": True,
            "include_stakeholder_grid": True,
            "table_format": "absolute_vertical",     # Montos + % vertical
            "conclusion_blocks": ["hallazgos", "riesgos", "prioridades"],
            "tone": "critical" if severity == "critico" else "constructive"
        }
    else:  # status
        return {
            "summary_box_style": "factual",         # Hechos + delta
            "bullet_style": "factual_short",        # Solo dato, máx 2-3 bullets
            "footer_style": "informational",        # Sin acciones
            "kpi_eval_against": "prior_period",      # ↑↓ vs anterior
            "include_recommendations": False,
            "include_risk_matrix": False,
            "include_stakeholder_grid": False,
            "table_format": "comparative",           # Actual | Anterior | Var | Var%
            "conclusion_blocks": [],                 # No hay slide de conclusiones
            "tone": "neutral"
        }


# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Scan Router — Financial Report V4")
    parser.add_argument("data_json", help="Path to data.json")
    parser.add_argument("ratios_json", help="Path to ratios.json")
    parser.add_argument("--sector", required=True, help="Sector ID")
    parser.add_argument("--country", default="peru", help="Country ID")
    parser.add_argument("--mode", default="diagnostic", choices=["diagnostic", "status"],
                        help="Report mode: diagnostic (full analysis) or status (tracking)")
    parser.add_argument("--output", default="slide_plan.json", help="Output path")

    args = parser.parse_args()

    with open(args.data_json) as f:
        data = json.load(f)
    with open(args.ratios_json) as f:
        ratios = json.load(f)

    plan = build_plan(data, ratios, args.sector, args.country, args.mode)

    with open(args.output, "w") as f:
        json.dump(plan, f, indent=2, ensure_ascii=False)

    # Summary to stdout
    print(f"✅ Plan generado: {args.output}")
    print(f"   Mode: {plan['mode']}")
    print(f"   Severity: {plan['severity']}")
    print(f"   Slides: {len(plan['slides'])}")
    print(f"   Distortions: {len(plan['distortions'])}")
    print(f"   Alerts: {len(plan['alerts'])}")
    print(f"   Data richness: {plan['data_richness']}")
    print(f"   Recommendations: {'YES' if plan['mode_config']['include_recommendations'] else 'NO'}")


if __name__ == "__main__":
    main()
