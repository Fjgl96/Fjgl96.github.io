#!/usr/bin/env python3
"""
generate_html.py — data.json + ratios.json + slide_plan.json → reporte.html

El flujo declaraba salida HTML interactiva pero no traía generador: lo escribía
el modelo a mano en cada corrida, así que dos corridas sobre el mismo archivo
daban dos reportes distintos. Acá el HTML sale de los mismos JSON que alimentan
el PPTX, con la paleta y los componentes de core/html_style.md.

Single-file: CSS y JS embebidos, sin dependencias más que la tipografía.
El waterfall va en SVG en línea —no hay librería de gráficos— para que el
archivo se abra igual sin red y se imprima bien a PDF.

    python3 generate_html.py data.json ratios.json slide_plan.json reporte.html
"""
import json, sys, html

d, r, plan, salida = (sys.argv[1:5] + ["reporte.html"])[:4]
D = json.load(open(d, encoding="utf-8"))
R = json.load(open(r, encoding="utf-8"))
P = json.load(open(plan, encoding="utf-8"))

PS = R.get("periodos") or D.get("periodos") or []
ACT, ANT = (PS[-1], PS[-2] if len(PS) > 1 else None) if PS else ("", None)
EMP = D.get("empresa", "")
E = lambda s: html.escape(str(s if s is not None else ""))

def num(x, dec=0):
    if not isinstance(x, (int, float)):
        return "—"
    s = f"{abs(x):,.{dec}f}".replace(",", " ")
    return ("−" if x < 0 else "") + s

def pct(x, dec=1):
    return "—" if not isinstance(x, (int, float)) else f"{x:.{dec}f} %"

def rat(p, fam, k, dflt=None):
    v = (R.get("ratios", {}).get(p, {}).get(fam, {}) or {}).get(k)
    return v if isinstance(v, (int, float)) else dflt

def er(p, k, dflt=0):
    v = (D.get("estado_resultados", {}).get(p, {}) or {}).get(k)
    return v if isinstance(v, (int, float)) else dflt

def bg(p, sec, k, dflt=0):
    b = D.get("balance", {}).get(p, {}) or {}
    v = (b.get(sec, {}) or {}).get(k) if sec else b.get(k)
    return v if isinstance(v, (int, float)) else dflt

VAR = (R.get("variaciones") or {}).get(f"{ACT}_vs_{ANT}", {}) if ANT else {}
def var_pct(k):
    return (VAR.get(k) or {}).get("pct")

# ── waterfall en SVG, del resultado operativo al neto ────────────────────────
def waterfall():
    pasos = [("Result. operativo", er(ACT, "margen_operativo"), "base"),
             ("Ing. financieros", er(ACT, "ing_financieros_total"), "d"),
             ("Gastos financieros", -abs(er(ACT, "gastos_financieros")), "d"),
             ("Difer. de cambio", er(ACT, "perdida_diferencia_cambio"), "d"),
             ("Otros ingresos", er(ACT, "otros_ingresos_gestion"), "d"),
             ("Impuesto renta", -abs(er(ACT, "impuesto_renta")), "d"),
             ("Resultado neto", er(ACT, "resultado_ejercicio"), "total")]
    W, H, IZQ, DER, TOP, PISO = 900, 330, 70, 40, 40, 250
    acum, cajas, techo = 0, [], 0
    for et, v, t in pasos:
        if t in ("base", "total"):
            desde, hasta = 0, v; acum = v
        else:
            desde, hasta = acum, acum + v; acum = hasta
        techo = max(techo, desde, hasta)
        cajas.append((et, v, t, desde, hasta))
    if techo <= 0:
        return ""
    # El puente tiene que reconciliar: el último tramo es el resultado neto y
    # tiene que ser la suma de todo lo anterior. Si no cierra, lo que hay es un
    # problema de extracción —una partida sin mapear, o un subtotal contado dos
    # veces— y dibujarlo igual produce un gráfico que miente con confianza.
    esperado = sum(v for _, v, t in pasos if t != "total")
    final = pasos[-1][1]
    if abs(esperado - final) > max(1.0, abs(final) * 0.001):
        return ('<p class="alerta-datos">El puente no reconcilia: los tramos suman '
                f'S/ {num(esperado)} y el resultado declarado es S/ {num(final)} '
                f'(diferencia S/ {num(esperado - final)}). Falta mapear una partida del '
                'estado de resultados; el gráfico no se dibuja hasta resolverlo.</p>')
    util = W - IZQ - DER
    n = len(cajas)
    bw = min(84, (util / n) * 0.78)
    salto = (util - bw) / (n - 1)
    y = lambda v: PISO - (v / techo) * (PISO - TOP)
    out = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Puente del resultado operativo al resultado neto">',
           f'<line x1="{IZQ}" y1="{PISO}" x2="{W-DER}" y2="{PISO}" stroke="#CFE0F2" stroke-width="1.4"/>']
    for i, (et, v, t, desde, hasta) in enumerate(cajas):
        x = IZQ + i * salto
        yt, yb = y(max(desde, hasta)), y(min(desde, hasta))
        alto = max(yb - yt, 2)
        col = "#173B6C" if t == "base" else ("#0F6B46" if t == "total" else ("#149DDD" if v >= 0 else "#B33A3A"))
        etiqueta = num(v) if t in ("base", "total") else (("+" if v >= 0 else "−") + num(abs(v)))
        out.append(f'<rect x="{x:.1f}" y="{yt:.1f}" width="{bw:.1f}" height="{alto:.1f}" rx="3" fill="{col}" fill-opacity="{1 if t in ("base","total") else 0.9}"/>')
        out.append(f'<text x="{x+bw/2:.1f}" y="{yt-8:.1f}" text-anchor="middle" class="wv" fill="{col}">{etiqueta}</text>')
        out.append(f'<text x="{x+bw/2:.1f}" y="{PISO+18:.1f}" text-anchor="middle" class="we">{E(et)}</text>')
        if i:
            ye = y(cajas[i-1][4])
            out.append(f'<line x1="{IZQ+(i-1)*salto+bw:.1f}" y1="{ye:.1f}" x2="{x:.1f}" y2="{ye:.1f}" stroke="#CFE0F2" stroke-width="1.2" stroke-dasharray="3 3"/>')
    out.append("</svg>")
    return "".join(out)

# ── KPI cards ────────────────────────────────────────────────────────────────
def kpi(label, valor, estado="neutral", delta=None, ref=None):
    dl = f'<span class="kpi-delta {"positive" if (delta or 0) >= 0 else "negative"}">{"↑" if (delta or 0) >= 0 else "↓"} {pct(abs(delta))}</span>' if isinstance(delta, (int, float)) else ""
    rf = f'<span class="kpi-ref">vs {E(ref)}</span>' if ref else ""
    return (f'<div class="kpi-card" data-status="{estado}"><span class="kpi-label">{E(label)}</span>'
            f'<span class="kpi-value">{valor}</span>{dl}{rf}</div>')

def sem(v, bueno, malo, invertido=False):
    if not isinstance(v, (int, float)): return "neutral"
    if invertido: return "good" if v <= bueno else ("danger" if v >= malo else "warning")
    return "good" if v >= bueno else ("danger" if v <= malo else "warning")

def fila(nombre, k, dec=0, clase=""):
    a = er(ANT, k) if ANT else None
    b = er(ACT, k)
    v = (b - a) if isinstance(a, (int, float)) else None
    vp = (v / abs(a) * 100) if v is not None and a else None
    neg = ' class="neg"' if isinstance(v, (int, float)) and v < 0 else ""
    return (f'<tr class="{clase}"><td>{E(nombre)}</td><td class="n">{num(a, dec)}</td>'
            f'<td class="n">{num(b, dec)}</td><td class="n"{neg}>{num(v, dec) if v is not None else "—"}</td>'
            f'<td class="n"{neg}>{pct(vp) if vp is not None else "—"}</td></tr>')

# ── láminas ──────────────────────────────────────────────────────────────────
S = []
S.append(f'''<section class="slide portada"><div>
  <p class="eyebrow">Reporte ejecutivo · Diagnóstico</p>
  <h1>{E(EMP)}</h1>
  <p class="sub">Estados financieros {E(PS[0]) if PS else ""} – {E(ACT)} · Sector distribución · Perú</p>
  <p class="sub small">Moneda: soles · Severidad del diagnóstico: <b>{E(P.get("severity","").upper())}</b></p>
</div></section>''')

sv = P.get("severity", "")
S.append(f'''<section class="slide"><div class="slide-header"><h2>Resumen ejecutivo</h2></div>
<div class="summary-box"><p><em>Las ventas crecen {pct(var_pct("ventas"))} pero el resultado operativo cae {pct(abs(var_pct("margen_operativo") or 0))}.
La mejora del resultado neto no proviene de la operación.</em></p></div>
<div class="kpi-grid">
  {kpi("Ventas netas", num(er(ACT,"ventas_netas")), "neutral", var_pct("ventas"), num(er(ANT,"ventas_netas")) if ANT else None)}
  {kpi("Margen bruto", pct(rat(ACT,"rentabilidad","margen_bruto_pct")), sem(rat(ACT,"rentabilidad","margen_bruto_pct"),20,14), None, pct(rat(ANT,"rentabilidad","margen_bruto_pct")) if ANT else None)}
  {kpi("Result. operativo", num(er(ACT,"margen_operativo")), "danger", var_pct("margen_operativo"), num(er(ANT,"margen_operativo")) if ANT else None)}
  {kpi("Resultado neto", num(er(ACT,"resultado_ejercicio")), "warning", var_pct("resultado_neto"), num(er(ANT,"resultado_ejercicio")) if ANT else None)}
  {kpi("ROE", pct(rat(ACT,"rentabilidad","roe")), sem(rat(ACT,"rentabilidad","roe"),15,8))}
  {kpi("Ratio corriente", f'{rat(ACT,"liquidez","ratio_corriente",0):.2f}', sem(rat(ACT,"liquidez","ratio_corriente"),1.2,1.0))}
  {kpi("Endeudamiento", pct(rat(ACT,"solvencia","endeudamiento",0)*100 if (rat(ACT,"solvencia","endeudamiento",0) or 0)<=1 else rat(ACT,"solvencia","endeudamiento")), sem(rat(ACT,"solvencia","endeudamiento",0),0.5,0.7,invertido=True))}
  {kpi("Cobertura intereses", f'{rat(ACT,"rentabilidad","cobertura_intereses",0):.2f}x', sem(rat(ACT,"rentabilidad","cobertura_intereses"),3,1.5))}
  {kpi("Días inventario", num(rat(ACT,"eficiencia","edad_inventario_dias")), "warning")}
  {kpi("Días cobro", num(rat(ACT,"eficiencia","periodo_cobro_dias")), "good")}
</div>
<div class="slide-footer" data-severity="warning"><p><em>El diagnóstico general se clasifica como <b>{E(sv)}</b>: la rentabilidad operativa se deteriora aunque los indicadores de cierre mejoren.</em></p></div>
</section>''')

S.append(f'''<section class="slide"><div class="slide-header"><h2>Estado de resultados</h2></div>
<div class="summary-box"><p><em>Se vendió más y se ganó menos: la utilidad bruta cae {pct(abs(var_pct("margen_bruto") or 0))} en soles mientras las ventas suben {pct(var_pct("ventas"))}.</em></p></div>
<table class="fin-table"><thead><tr><th>Concepto</th><th class="n">{E(ANT or "")}</th><th class="n">{E(ACT)}</th><th class="n">Var S/</th><th class="n">Var %</th></tr></thead><tbody>
{fila("Ventas netas","ventas_netas")}
{fila("Costo de ventas","costo_ventas")}
{fila("Utilidad bruta","margen_bruto",0,"subtotal")}
{fila("Gastos operativos","gastos_operativos_total")}
{fila("Resultado operativo","margen_operativo",0,"subtotal")}
{fila("Gastos financieros","gastos_financieros")}
{fila("Diferencia de cambio","perdida_diferencia_cambio")}
{fila("Resultado del ejercicio","resultado_ejercicio",0,"total")}
</tbody></table>
<div class="slide-footer" data-severity="critical"><p><em>El margen bruto perdió {num(abs((rat(ACT,"rentabilidad","margen_bruto_pct") or 0)-(rat(ANT,"rentabilidad","margen_bruto_pct") or 0))*100)} puntos básicos y el operativo {num(abs((rat(ACT,"rentabilidad","margen_operativo_pct") or 0)-(rat(ANT,"rentabilidad","margen_operativo_pct") or 0))*100)}.</em></p></div>
</section>''')

dist = [x for x in P.get("distortions", []) if x.get("type") == "puente_no_operativo"]
nota = dist[0]["note"] if dist else "El resultado neto incorpora partidas ajenas a la operación."
S.append(f'''<section class="slide"><div class="slide-header"><h2>Del resultado operativo al resultado neto</h2></div>
<div class="summary-box"><p><em>{E(nota)}</em></p></div>
<div class="chart">{waterfall()}</div>
<div class="slide-footer" data-severity="critical"><p><em>Sin el efecto cambiario, el ejercicio habría sido peor que el anterior en todas las líneas.</em></p></div>
</section>''')

sec = (R.get("kpis_sectoriales") or {}).get(ACT, {})
seca = (R.get("kpis_sectoriales") or {}).get(ANT, {}) if ANT else {}
inv_a = bg(ANT, "activo_corriente", "inventarios") if ANT else 0
inv_b = bg(ACT, "activo_corriente", "inventarios")
g_inv = (inv_b/inv_a - 1)*100 if inv_a else None
g_ven = var_pct("ventas")
S.append(f'''<section class="slide"><div class="slide-header"><h2>Capital de trabajo · sector distribución</h2></div>
<div class="summary-box"><p><em>Las existencias crecen {pct(g_inv)} mientras las ventas crecen {pct(g_ven)}: se acumula inventario más rápido de lo que se vende.</em></p></div>
<div class="kpi-grid">
  {kpi("Días de inventario", num(sec.get("edad_inventario_dias")), "warning", None, num(seca.get("edad_inventario_dias")) if seca else None)}
  {kpi("Rotación inventario", f'{sec.get("rotacion_inventarios",0):.2f}x', "warning")}
  {kpi("Días de cobro", num(sec.get("dso_dias")), "good")}
  {kpi("CxC % del activo", pct(sec.get("cxc_pct_activo")), "good")}
  {kpi("Días de efectivo", num(sec.get("dias_efectivo")), "danger")}
</div>
<table class="fin-table"><thead><tr><th>Concepto</th><th class="n">{E(ANT or "")}</th><th class="n">{E(ACT)}</th><th class="n">Var %</th></tr></thead><tbody>
<tr><td>Existencias</td><td class="n">{num(inv_a)}</td><td class="n">{num(inv_b)}</td><td class="n neg">{pct(g_inv)}</td></tr>
<tr><td>Ventas netas</td><td class="n">{num(er(ANT,"ventas_netas") if ANT else None)}</td><td class="n">{num(er(ACT,"ventas_netas"))}</td><td class="n">{pct(g_ven)}</td></tr>
</tbody></table>
<div class="slide-footer" data-severity="warning"><p><em>El ciclo de conversión se sostiene sobre el plazo de proveedores; el inventario es la palanca propia.</em></p></div>
</section>''')

def rfila(nombre, v, fmt, estado):
    return f'<tr><td>{E(nombre)}</td><td class="n">{fmt}</td><td class="eval-{estado}">{"Cumple" if estado=="good" else ("Observación" if estado=="warning" else "Fuera de benchmark")}</td></tr>'
S.append(f'''<section class="slide"><div class="slide-header"><h2>Ratios financieros</h2></div>
<div class="summary-box"><p><em>La liquidez mejora y el endeudamiento cede, pero la cobertura de intereses se reduce a la mitad.</em></p></div>
<table class="fin-table"><thead><tr><th>Ratio</th><th class="n">{E(ACT)}</th><th>Estado</th></tr></thead><tbody>
{rfila("Ratio corriente", f'{rat(ACT,"liquidez","ratio_corriente",0):.2f}', f'{rat(ACT,"liquidez","ratio_corriente",0):.2f}', sem(rat(ACT,"liquidez","ratio_corriente"),1.2,1.0))}
{rfila("Prueba ácida", f'{rat(ACT,"liquidez","prueba_acida",0):.2f}', f'{rat(ACT,"liquidez","prueba_acida",0):.2f}', sem(rat(ACT,"liquidez","prueba_acida"),1.0,0.7))}
{rfila("Margen bruto", "", pct(rat(ACT,"rentabilidad","margen_bruto_pct")), sem(rat(ACT,"rentabilidad","margen_bruto_pct"),20,14))}
{rfila("Margen operativo", "", pct(rat(ACT,"rentabilidad","margen_operativo_pct")), sem(rat(ACT,"rentabilidad","margen_operativo_pct"),8,4))}
{rfila("Margen neto", "", pct(rat(ACT,"rentabilidad","margen_neto_pct")), sem(rat(ACT,"rentabilidad","margen_neto_pct"),5,2))}
{rfila("ROE", "", pct(rat(ACT,"rentabilidad","roe")), sem(rat(ACT,"rentabilidad","roe"),15,8))}
{rfila("Cobertura de intereses", "", f'{rat(ACT,"rentabilidad","cobertura_intereses",0):.2f}x', sem(rat(ACT,"rentabilidad","cobertura_intereses"),3,1.5))}
</tbody></table>
<p class="leyenda">Cumple · Observación · Fuera de benchmark — umbrales del módulo sectorial de distribución.</p>
</section>''')

S.append(f'''<section class="slide"><div class="slide-header"><h2>Conclusiones</h2></div>
<div class="three-blocks">
  <div class="bloque"><h3><span class="dot rojo"></span>Hallazgos</h3><ul>
    <li>La utilidad bruta cae {pct(abs(var_pct("margen_bruto") or 0))} con ventas al alza: el margen se comprime.</li>
    <li>El resultado operativo retrocede {pct(abs(var_pct("margen_operativo") or 0))}.</li>
    <li>La mejora del neto proviene de la diferencia de cambio, no de la operación.</li>
  </ul></div>
  <div class="bloque"><h3><span class="dot ambar"></span>Riesgos</h3><ul>
    <li>Cobertura de intereses en {rat(ACT,"rentabilidad","cobertura_intereses",0):.2f}x, desde {rat(ANT,"rentabilidad","cobertura_intereses",0):.2f}x.</li>
    <li>Existencias creciendo {pct(g_inv)} contra ventas {pct(g_ven)}.</li>
    <li>El resultado depende de una partida que la empresa no controla.</li>
  </ul></div>
  <div class="bloque"><h3><span class="dot verde"></span>Prioridades</h3><ul>
    <li><b>0–3 meses.</b> Revisar política de precios y descuentos por línea.</li>
    <li><b>3–6 meses.</b> Plan de reducción de inventario y cobertura cambiaria.</li>
    <li><b>6–12 meses.</b> Reestructurar el costo financiero.</li>
  </ul></div>
</div>
</section>''')

S.append(f'''<section class="slide portada"><div>
  <p class="eyebrow">Fin del reporte</p>
  <h1>{E(EMP)}</h1>
  <p class="sub">Documento generado automáticamente a partir de los estados financieros.
     Las observaciones contables se detallan en la minuta adjunta.</p>
</div></section>''')

dots = "".join(f'<button class="nav-dot" onclick="ir({i})" aria-label="Lámina {i+1}"></button>' for i in range(len(S)))

CSS = """
:root{--primary:#0B5394;--primary-dark:#073B6B;--secondary:#1B7F9B;--negative:#CC0000;
--warning:#E67E22;--success:#27AE60;--bg-slide:#F8FAFC;--bg-summary:#EBF2FA;
--bg-table-alt:#F8F9FA;--bg-footer:#F2F4F6;--bg-danger:#F8D7DA;--bg-warning:#FFF3CD;
--bg-success:#D1E7DD;--text:#1A202C;--text-2:#4A5568;--muted:#718096;--line:#E2E8F0}
*{box-sizing:border-box}
body{margin:0;background:var(--bg-slide);color:var(--text);
 font-family:Inter,-apple-system,"Segoe UI",sans-serif;font-size:15px;line-height:1.55}
.slide{background:#fff;max-width:1080px;margin:0 auto 26px;padding:clamp(22px,4vw,44px);
 border:1px solid var(--line);border-radius:12px;box-shadow:0 1px 3px rgba(16,42,67,.06)}
.slide-header h2{margin:0 0 14px;font-size:clamp(1.15rem,2.4vw,1.6rem);color:var(--primary-dark);
 font-weight:700;letter-spacing:-.01em}
.portada{background:linear-gradient(135deg,#0B5394,#073B6B);color:#fff;border:none;
 min-height:300px;display:flex;align-items:center}
.portada h1{margin:6px 0 12px;font-size:clamp(1.5rem,4vw,2.5rem);font-weight:700}
.eyebrow{margin:0;font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;opacity:.82;font-weight:600}
.sub{margin:0;opacity:.9}.sub.small{font-size:.85rem;margin-top:8px;opacity:.75}
.summary-box{background:var(--bg-summary);border-left:4px solid var(--primary);
 padding:13px 17px;border-radius:0 8px 8px 0;margin:0 0 18px}
.summary-box p{margin:0;font-size:.95rem}
.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(158px,1fr));gap:10px;margin-bottom:18px}
.kpi-card{background:var(--bg-footer);border-radius:9px;padding:12px 14px;display:flex;flex-direction:column;gap:2px}
.kpi-card[data-status=good]{background:var(--bg-success)}
.kpi-card[data-status=warning]{background:var(--bg-warning)}
.kpi-card[data-status=danger]{background:var(--bg-danger)}
.kpi-label{font-size:.7rem;letter-spacing:.06em;text-transform:uppercase;color:var(--text-2);font-weight:600}
.kpi-value{font-size:1.3rem;font-weight:700;color:var(--primary-dark);font-variant-numeric:tabular-nums}
.kpi-delta{font-size:.78rem;font-weight:700}
.kpi-delta.positive{color:var(--success)}.kpi-delta.negative{color:var(--negative)}
.kpi-ref{font-size:.7rem;color:var(--muted);font-style:italic}
.fin-table{width:100%;border-collapse:collapse;margin:0 0 16px;font-size:.9rem}
.fin-table th{background:var(--primary);color:#fff;padding:9px 11px;text-align:left;font-weight:600;font-size:.78rem;
 letter-spacing:.04em;text-transform:uppercase}
.fin-table td{padding:8px 11px;border-bottom:1px solid var(--line)}
.fin-table .n{text-align:right;font-variant-numeric:tabular-nums}
.fin-table tr:nth-child(even) td{background:var(--bg-table-alt)}
.fin-table .subtotal td{font-weight:600;background:#E8E8E8}
.fin-table .total td{font-weight:700;background:var(--primary);color:#fff}
.fin-table td.neg{color:var(--negative)}
.fin-table .total td.neg{color:#FFD9D9}
.eval-good{background:var(--bg-success)}.eval-warning{background:var(--bg-warning)}.eval-danger{background:var(--bg-danger)}
.slide-footer{background:var(--bg-footer);border-radius:8px;padding:11px 15px;margin-top:4px}
.slide-footer p{margin:0;font-size:.86rem;color:var(--text-2)}
.slide-footer[data-severity=warning]{background:var(--bg-warning)}
.slide-footer[data-severity=critical]{background:var(--bg-danger)}
.chart{margin:6px 0 16px}.chart svg{width:100%;height:auto;display:block}
.wv{font:700 12px Inter,sans-serif}.we{font:600 10px Inter,sans-serif;fill:#5F7391}
.three-blocks{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:16px}
.bloque{background:var(--bg-footer);border-radius:9px;padding:14px 16px}
.bloque h3{margin:0 0 8px;font-size:.85rem;display:flex;align-items:center;gap:7px}
.bloque ul{margin:0;padding-left:17px}.bloque li{font-size:.86rem;margin-bottom:6px;color:var(--text-2)}
.dot{width:10px;height:10px;border-radius:50%;display:inline-block}
.dot.rojo{background:var(--negative)}.dot.ambar{background:#FFC107}.dot.verde{background:var(--success)}
.leyenda{font-size:.76rem;color:var(--muted);margin:0}
.alerta-datos{background:var(--bg-danger);border-left:4px solid var(--negative);padding:13px 17px;border-radius:0 8px 8px 0;margin:0 0 18px;font-size:.9rem}
.slide-nav{position:fixed;right:14px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;gap:7px;z-index:9}
.nav-dot{width:9px;height:9px;border-radius:50%;border:1px solid var(--primary);background:#fff;cursor:pointer;padding:0}
.nav-dot.active{background:var(--primary)}
@media print{
 body{background:#fff}
 .slide{break-after:page;page-break-after:always;box-shadow:none;border:none;margin:0;max-width:none;min-height:auto}
 .slide:last-child{break-after:auto;page-break-after:auto}
 .slide-nav{display:none}
 .portada{-webkit-print-color-adjust:exact;print-color-adjust:exact}
 *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
"""

JS = """
const laminas=[...document.querySelectorAll('.slide')],dots=[...document.querySelectorAll('.nav-dot')];
function ir(i){laminas[i]&&laminas[i].scrollIntoView({behavior:'smooth',block:'start'})}
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){
  const i=laminas.indexOf(e.target);dots.forEach((d,k)=>d.classList.toggle('active',k===i));}}),{threshold:.4});
laminas.forEach(l=>io.observe(l));
addEventListener('keydown',e=>{const a=dots.findIndex(d=>d.classList.contains('active'));
 if(e.key==='ArrowDown'||e.key==='ArrowRight'){e.preventDefault();ir(Math.min(a+1,laminas.length-1))}
 if(e.key==='ArrowUp'||e.key==='ArrowLeft'){e.preventDefault();ir(Math.max(a-1,0))}});
"""

open(salida, "w", encoding="utf-8").write(f'''<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reporte Financiero — {E(EMP)} — {E(ACT)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>{CSS}</style></head><body>
<nav class="slide-nav">{dots}</nav>
{"".join(S)}
<script>{JS}</script></body></html>''')
print(f"✅ HTML generado: {salida} ({len(S)} láminas)")
