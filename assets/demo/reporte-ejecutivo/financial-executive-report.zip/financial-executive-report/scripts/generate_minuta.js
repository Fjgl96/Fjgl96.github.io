#!/usr/bin/env node
/**
 * generate_minuta.js — Minuta de Observaciones Contables V4.1
 *
 * Lee data.json y genera un .docx profesional con observaciones
 * de inconsistencias para coordinación con el área contable.
 *
 * Usage:
 *   node generate_minuta.js data.json [ratios.json] minuta_contable.docx
 *
 * Requiere: npm install -g docx
 */

const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
        LevelFormat, PageBreak } = require("docx");
const fs = require("fs");
const path = require("path");

// ════════════════════════════════════════════════════════════
// CONFIGURATION
// ════════════════════════════════════════════════════════════
const COLORS = {
  primary: "0B5394",
  headerBg: "D5E8F0",
  criticalBg: "F8D7DA",
  warningBg: "FFF3CD",
  okBg: "D1E7DD",
  neutralBg: "F2F4F6",
  darkText: "2D3748",
};

const BORDER = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const BORDERS = { top: BORDER, bottom: BORDER, left: BORDER, right: BORDER };
const CELL_MARGINS = { top: 60, bottom: 60, left: 100, right: 100 };
const TABLE_WIDTH = 9360; // US Letter with 1" margins

// ════════════════════════════════════════════════════════════
// VALIDATION ENGINE
// ════════════════════════════════════════════════════════════
// ────────────────────────────────────────────────────────────
// LECTURA TOLERANTE DE CUENTAS
//
// El data.json puede venir del parser automático o de una extracción manual,
// y cada origen nombra las cuentas distinto (capital / capital_social,
// resultado_ejercicio / resultado_periodo, total_ac / total_activo_corriente).
// Antes se leía un solo nombre y, si no coincidía, la cuenta valía 0 y la
// minuta reportaba un descuadre que no existe. Un falso positivo en un
// documento que va a contabilidad cuesta más que un hallazgo omitido: quema
// la confianza en todos los demás.
// ────────────────────────────────────────────────────────────
function pick(obj, ...alias) {
  for (const a of alias) {
    const v = (obj || {})[a];
    if (typeof v === "number") return v;
  }
  return 0;
}

// Suma TODAS las partidas numéricas de una sección, salvo sus propios totales.
// Es correcto sea cual sea el plan de cuentas; una lista fija de nombres no.
function sumaPartidas(seccion) {
  let t = 0;
  for (const [k, v] of Object.entries(seccion || {})) {
    if (typeof v === "number" && !/^total/i.test(k)) t += v;
  }
  return t;
}

function runChecks(data, ratios) {
  const findings = [];
  const esf = data.esf || {};
  const egp = data.egp || {};
  const totales = esf.totales || {};
  const pat = esf.patrimonio || {};
  const ac = esf.activo_corriente || {};
  const anc = esf.activo_no_corriente || {};
  const pc = esf.pasivo_corriente || {};
  const pnc = esf.pasivo_no_corriente || {};

  // ── 1. ECUACIÓN PATRIMONIAL ──
  const activo = totales.activo || 0;
  const pasivoPatrimonio = totales.pasivo_patrimonio || 0;
  if (activo > 0 && pasivoPatrimonio > 0) {
    const diff = Math.abs(activo - pasivoPatrimonio);
    if (diff > 1) {
      findings.push({
        section: "Ecuación Patrimonial",
        type: "critical",
        description: `Total Activo (S/ ${fmt(activo)}) ≠ Total Pasivo + Patrimonio (S/ ${fmt(pasivoPatrimonio)}). Diferencia: S/ ${fmt(diff)}.`,
        action: "Verificar sumas del balance. Posible partida no clasificada o error de digitación."
      });
    } else {
      findings.push({
        section: "Ecuación Patrimonial",
        type: "ok",
        description: `Total Activo (S/ ${fmt(activo)}) = Total Pasivo + Patrimonio (S/ ${fmt(pasivoPatrimonio)}). Cuadra correctamente.`,
        action: "Ninguna."
      });
    }
  }

  // ── 2. CONSISTENCIA EGP ↔ ESF ──
  const resultadoEGP = egp.resultado_ejercicio;
  const resultadoESF = pat.resultado_ejercicio;
  if (resultadoEGP !== undefined && resultadoESF !== undefined) {
    const diff = Math.abs(resultadoEGP - resultadoESF);
    if (diff > 100) {
      findings.push({
        section: "Consistencia EGP ↔ ESF",
        type: "critical",
        description: `Resultado del Ejercicio difiere entre estados: EGP (S/ ${fmt(resultadoEGP)}) vs ESF (S/ ${fmt(resultadoESF)}). Diferencia material: S/ ${fmt(diff)}.`,
        action: "Revisar hojas del Excel fuente. Posible que el EGP y el Balance se prepararon en distintas fechas o con distintos ajustes. Conciliar antes de presentar al directorio."
      });
    } else if (diff > 1) {
      findings.push({
        section: "Consistencia EGP ↔ ESF",
        type: "warning",
        description: `Diferencia menor entre Resultado EGP (S/ ${fmt(resultadoEGP)}) y ESF (S/ ${fmt(resultadoESF)}): S/ ${fmt(diff)}.`,
        action: "Diferencia probablemente por redondeo. Verificar y uniformizar."
      });
    } else {
      findings.push({
        section: "Consistencia EGP ↔ ESF",
        type: "ok",
        description: `Resultado del Ejercicio coincide entre EGP y ESF: S/ ${fmt(resultadoEGP)}.`,
        action: "Ninguna."
      });
    }
  }

  // ── 3. COMPOSICIÓN DEL PATRIMONIO ──
  const capital = pick(pat, "capital", "capital_social");
  const reservas = pick(pat, "reservas", "reserva_legal");
  let perdidasAcum = pick(pat, "perdidas_acum", "resultados_acum", "resultados_acumulados");
  const resultadoEj = pick(pat, "resultado_ejercicio", "resultado_periodo", "resultado_del_periodo");
  const totalPat = pick(pat, "total_patrimonio", "total_pat");

  // perdidas_acum might be stored as positive in some formats
  if (perdidasAcum > 0 && totalPat < capital) perdidasAcum = -perdidasAcum;

  const computedPat = capital + reservas + perdidasAcum + resultadoEj;
  const patDiff = Math.abs(computedPat - totalPat);
  if (patDiff > 100 && totalPat !== 0) {
    findings.push({
      section: "Composición del Patrimonio",
      type: "warning",
      description: `Capital (S/ ${fmt(capital)}) + Reservas (S/ ${fmt(reservas)}) + Resultados Acum (S/ ${fmt(perdidasAcum)}) + Resultado Ej (S/ ${fmt(resultadoEj)}) = S/ ${fmt(computedPat)}. Total declarado: S/ ${fmt(totalPat)}. Diferencia: S/ ${fmt(patDiff)}.`,
      action: "Verificar si hay partidas de patrimonio no contempladas (revaluación, ajustes de conversión, otros). Detallar composición."
    });
  }

  // ── 4. PATRIMONIO NEGATIVO ──
  if (totalPat < 0) {
    findings.push({
      section: "Alerta Regulatoria",
      type: "critical",
      description: `Patrimonio negativo: S/ ${fmt(totalPat)}. Las pérdidas acumuladas han consumido el capital social de S/ ${fmt(capital)}.`,
      action: "Evaluar aplicación del Art. 407 LGS (causal de disolución si pérdidas > 2/3 del capital). Preparar informe para junta de accionistas con opciones: capitalización de deuda, aporte fresco de capital, o reducción de capital."
    });
  }

  // ── 5. SALDOS INUSUALES ──
  const checkUnusual = (name, val, expectPositive) => {
    if (val === undefined || val === null) return;
    if (expectPositive && val < -10) {
      findings.push({
        section: "Saldos Inusuales",
        type: "warning",
        description: `${name} presenta saldo negativo: S/ ${fmt(val)}.`,
        action: `Verificar si corresponde a reclasificación, anticipo o error de registro.`
      });
    }
  };
  checkUnusual("Efectivo y Equivalentes", ac.efectivo, true);
  checkUnusual("CxC Comerciales", ac.cxc_comerciales, true);
  checkUnusual("Mercaderías", ac.mercaderias, true);
  checkUnusual("Tributos por Pagar", pc.tributos_pagar, true);

  // ── 6. PARTIDAS MATERIALES SIN DETALLE ──
  const preop = ac.gastos_anticipados || 0;
  if (preop > 0 && activo > 0 && preop / activo > 0.08) {
    findings.push({
      section: "Partidas Materiales",
      type: "warning",
      description: `Gastos Anticipados/Preoperativos: S/ ${fmt(preop)} (${(preop / activo * 100).toFixed(1)}% del activo). Partida material que requiere detalle.`,
      action: "Solicitar desglose de gastos preoperativos. ¿Corresponden a nueva apertura, depósitos, seguros? Evaluar si deben reclasificarse o provisionarse."
    });
  }

  const cxpAccLP = pnc.cxp_accionistas_nc || 0;
  const totalPasivo = (pc.total_pc || 0) + (pnc.total_pnc || 0);
  if (cxpAccLP > 0 && totalPasivo > 0 && cxpAccLP / totalPasivo > 0.70) {
    findings.push({
      section: "Partidas Materiales",
      type: "warning",
      description: `CxP Accionistas LP: S/ ${fmt(cxpAccLP)} (${(cxpAccLP / totalPasivo * 100).toFixed(0)}% del pasivo total). Concentración extrema en deuda con relacionadas.`,
      action: "Solicitar contratos o acuerdos de préstamo con socios. Verificar condiciones (tasa, plazo, garantías). Evaluar si procede capitalización parcial para mejorar situación patrimonial."
    });
  }

  // ── 7. DEPRECIACIÓN ──
  const imeBruto = anc.ime_bruto || 0;
  const depAcum = Math.abs(anc.depreciacion || 0);
  if (imeBruto > 0 && depAcum > 0) {
    const pctDep = depAcum / imeBruto * 100;
    if (pctDep < 5) {
      findings.push({
        section: "Depreciación",
        type: "info",
        description: `Depreciación acumulada es solo ${pctDep.toFixed(1)}% del IME bruto (S/ ${fmt(depAcum)} de S/ ${fmt(imeBruto)}). Activos recientes o depreciación insuficiente.`,
        action: "Verificar que las tasas de depreciación aplicadas sean correctas según SUNAT (edificios 5%, maquinaria 10%, equipos diversos 10%, cómputo 25%). Si los activos son recientes, documentar fecha de alta."
      });
    }
  }

  // ── 8. NO RECURRENTES ──
  const difCambio = egp.dif_cambio || 0;
  const otrosIng = (egp.otros_ingresos || 0) + (egp.auspicios || 0);
  const ventas = egp.ventas_netas || 1;
  if (Math.abs(difCambio) > ventas * 0.05) {
    findings.push({
      section: "Partidas No Recurrentes",
      type: "warning",
      description: `Diferencia en cambio neta: S/ ${fmt(difCambio)} (${(difCambio / ventas * 100).toFixed(1)}% de ventas). Partida material no recurrente que distorsiona el resultado.`,
      action: "Separar el efecto de dif. cambio en el análisis. Documentar si corresponde a operaciones USD (CxP/CxC en dólares) o a posición de cambio activa. No proyectar como ingreso recurrente."
    });
  }
  if (otrosIng > ventas * 0.03) {
    findings.push({
      section: "Partidas No Recurrentes",
      type: "info",
      description: `Otros ingresos + auspicios: S/ ${fmt(otrosIng)} (${(otrosIng / ventas * 100).toFixed(1)}% de ventas).`,
      action: "Detallar origen de otros ingresos. Verificar si son recurrentes o extraordinarios para efecto de proyecciones."
    });
  }

  // ── 9. SUBTOTALES AC/PC ──
  const acItems = sumaPartidas(ac);
  const acTotal = pick(ac, "total_ac", "total_activo_corriente");
  if (acTotal > 0 && Math.abs(acItems - acTotal) > acTotal * 0.02) {
    findings.push({
      section: "Subtotales",
      type: "warning",
      description: `Suma de partidas AC (S/ ${fmt(acItems)}) difiere del total AC declarado (S/ ${fmt(acTotal)}) en S/ ${fmt(Math.abs(acItems - acTotal))}.`,
      action: "Posible partida de AC no mapeada en el sistema. Verificar si hay 'Otros activos corrientes' u otra cuenta no capturada."
    });
  }

  // ── 10. COHERENCIA DE ENCABEZADOS Y ESTRUCTURA ──
  // Los chequeos de arriba son aritméticos: miran si los números cuadran.
  // Estos miran si el archivo DICE lo que los números son. Un estado cuyo
  // encabezado declara un corte distinto al de sus cifras hace que el reporte
  // entero salga rotulado mal, y ninguna suma lo delata.
  const enc = data._encabezados || {};
  const MES = { "enero":1,"febrero":2,"marzo":3,"abril":4,"mayo":5,"junio":6,"julio":7,
                "agosto":8,"setiembre":9,"septiembre":9,"octubre":10,"noviembre":11,"diciembre":12 };
  function mesDe(txt) {
    if (!txt) return null;
    const t = String(txt).toLowerCase();
    const num = t.match(/(\d{1,2})\s*\/\s*\d{4}/);      // 11/2027
    if (num) return parseInt(num[1], 10);
    const fecha = t.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/); // 31/10/2028
    if (fecha) return parseInt(fecha[2], 10);
    for (const [n, m] of Object.entries(MES)) if (t.includes(n)) return m;
    return null;
  }

  for (const [periodo, e] of Object.entries(enc)) {
    const mBal = mesDe((e.balance || {}).periodo_declarado);
    const mEr  = mesDe((e.estado_resultados || {}).periodo_declarado);

    // D1 · el ER declara un corte distinto al del balance del mismo ejercicio
    if (mBal && mEr && mBal !== mEr) {
      findings.push({
        section: "Coherencia de Periodos",
        type: "warning",
        description: `En ${periodo} el estado de resultados declara "${(e.estado_resultados||{}).periodo_declarado}" mientras el balance declara "${(e.balance||{}).periodo_declarado}". Las cifras del estado de resultados concilian con el balance de cierre.`,
        action: "Confirmar con contabilidad el corte real del estado de resultados y corregir el encabezado. Si las cifras son de cierre, el encabezado debe decir 31 de diciembre."
      });
    }

    // D3 · el rótulo de la columna no coincide con el título de la hoja
    for (const [cual, etiqueta] of [["balance","balance"],["estado_resultados","estado de resultados"]]) {
      const h = e[cual] || {};
      const mTit = mesDe(h.periodo_declarado);
      const mCol = mesDe(h.rotulo_columna);
      if (mTit && mCol && mTit !== mCol) {
        findings.push({
          section: "Coherencia de Periodos",
          type: "warning",
          description: `En ${periodo}, el ${etiqueta} se titula "${h.periodo_declarado}" pero su columna de datos está rotulada "${h.rotulo_columna}".`,
          action: "Resolver a qué corte corresponde la columna y unificar el rótulo con el título de la hoja."
        });
      }
    }
  }

  // D2 · el plan de cuentas cambia entre ejercicios
  const ers = data.estado_resultados || {};
  const periodos = Object.keys(ers).sort();
  if (periodos.length >= 2) {
    const prev = new Set(Object.keys(ers[periodos[periodos.length - 2]] || {}));
    const act = Object.keys(ers[periodos[periodos.length - 1]] || {});
    const nuevas = act.filter((k) => !prev.has(k) && typeof ers[periodos[periodos.length-1]][k] === "number");
    if (nuevas.length) {
      const detalle = nuevas.map((k) => `${k} (S/ ${fmt(ers[periodos[periodos.length-1]][k])})`).join(", ");
      findings.push({
        section: "Comparabilidad entre Periodos",
        type: "warning",
        description: `El ejercicio ${periodos[periodos.length-1]} reporta ${nuevas.length} cuenta(s) de resultados que no existían en ${periodos[periodos.length-2]}: ${detalle}.`,
        action: "Confirmar si se trata de un gasto nuevo o de una reclasificación de cuentas existentes. La variación entre periodos no es comparable hasta resolverlo, y el reporte debe llevar la salvedad."
      });
    }
  }

  return findings;
}


// ────────────────────────────────────────────────────────────
// VERIFICACIONES QUE PASARON
//
// Una minuta que sólo lista problemas se lee como alarmista y contabilidad la
// recibe a la defensiva. Decir también qué se revisó y salió bien la convierte
// en un control: el lector sabe qué quedó cubierto y qué no.
// ────────────────────────────────────────────────────────────
function runPassed(data) {
  const ok = [];
  const bals = data.balance || {};
  const ers = data.estado_resultados || {};
  const periodos = Object.keys(bals).sort();

  for (const p of periodos) {
    const b = bals[p] || {};
    const activo = pick(b, "total_activo");
    const pasivo = pick(b, "total_pasivo");
    const pat = pick(b.patrimonio || {}, "total_patrimonio", "total_pat");
    if (activo && Math.abs(activo - (pasivo + pat)) < 1) {
      ok.push({ section: "Verificaciones que Pasaron", type: "ok",
        description: `Ecuación patrimonial ${p}: activo S/ ${fmt(activo)} = pasivo S/ ${fmt(pasivo)} + patrimonio S/ ${fmt(pat)}.`,
        action: "Sin acción requerida." });
    }
    const rEr = pick(ers[p] || {}, "resultado_ejercicio", "resultado_periodo");
    const rBg = pick(b.patrimonio || {}, "resultado_ejercicio", "resultado_periodo");
    if (rEr && rBg && Math.abs(rEr - rBg) < 1) {
      ok.push({ section: "Verificaciones que Pasaron", type: "ok",
        description: `Consistencia ${p}: el resultado del estado de resultados (S/ ${fmt(rEr)}) coincide con el declarado en el patrimonio.`,
        action: "Sin acción requerida." });
    }
  }
  return ok;
}

// ════════════════════════════════════════════════════════════
// DOCUMENT GENERATION
// ════════════════════════════════════════════════════════════
function buildDocument(data, findings) {
  const empresa = data.empresa || "Empresa";
  const periodo = data.periodo || "Periodo no especificado";
  const fecha = new Date().toLocaleDateString("es-PE", { year: "numeric", month: "long", day: "numeric" });

  const criticals = findings.filter(f => f.type === "critical");
  const warnings = findings.filter(f => f.type === "warning");
  const infos = findings.filter(f => f.type === "info");
  const oks = findings.filter(f => f.type === "ok");

  const children = [];

  // ── TÍTULO ──
  children.push(new Paragraph({
    heading: HeadingLevel.HEADING_1,
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
    children: [new TextRun({ text: "MINUTA DE OBSERVACIONES CONTABLES", bold: true, size: 28, font: "Arial", color: COLORS.primary })]
  }));
  children.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 100 },
    children: [new TextRun({ text: `${empresa} — ${periodo}`, size: 22, font: "Arial", color: COLORS.darkText })]
  }));
  children.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 300 },
    children: [new TextRun({ text: `Fecha de emisión: ${fecha}  |  Documento de uso interno — Coordinación con Contabilidad`, size: 18, font: "Arial", color: "6C757D", italics: true })]
  }));

  // ── RESUMEN ──
  children.push(new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 200, after: 100 },
    children: [new TextRun({ text: "1. Resumen de Hallazgos", bold: true, size: 24, font: "Arial" })]
  }));

  const resumenText = criticals.length > 0
    ? `Se identificaron ${criticals.length} observación(es) crítica(s), ${warnings.length} advertencia(s) y ${infos.length} nota(s) informativa(s). Se recomienda atender las observaciones críticas antes de la presentación de los estados financieros al directorio.`
    : warnings.length > 0
      ? `No se detectaron inconsistencias críticas. Se identificaron ${warnings.length} advertencia(s) que requieren revisión y ${infos.length} nota(s) informativa(s).`
      : `No se detectaron inconsistencias materiales en los estados financieros revisados. Los EEFF están listos para presentación.`;

  children.push(new Paragraph({
    spacing: { after: 200 },
    children: [new TextRun({ text: resumenText, size: 20, font: "Arial" })]
  }));

  // ── TABLA RESUMEN ──
  if (findings.length > 0) {
    children.push(buildSummaryTable(findings));
  }

  // ── DETALLE POR SECCIÓN ──
  children.push(new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 300, after: 100 },
    children: [new TextRun({ text: "2. Detalle de Observaciones", bold: true, size: 24, font: "Arial" })]
  }));

  // Group by section
  const sections = {};
  findings.forEach(f => {
    if (!sections[f.section]) sections[f.section] = [];
    sections[f.section].push(f);
  });

  Object.entries(sections).forEach(([sectionName, items]) => {
    children.push(new Paragraph({
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 80 },
      children: [new TextRun({ text: sectionName, bold: true, size: 22, font: "Arial", color: COLORS.primary })]
    }));

    items.forEach((item, i) => {
      const severityLabel = item.type === "critical" ? "🔴 CRÍTICO" : item.type === "warning" ? "🟡 ADVERTENCIA" : item.type === "ok" ? "✅ OK" : "ℹ️ INFORMATIVO";
      children.push(new Paragraph({
        spacing: { after: 60 },
        children: [
          new TextRun({ text: `${severityLabel}: `, bold: true, size: 20, font: "Arial" }),
          new TextRun({ text: item.description, size: 20, font: "Arial" })
        ]
      }));
      children.push(new Paragraph({
        spacing: { after: 140 },
        indent: { left: 360 },
        children: [
          new TextRun({ text: "Acción sugerida: ", bold: true, size: 19, font: "Arial", italics: true, color: "6C757D" }),
          new TextRun({ text: item.action, size: 19, font: "Arial", italics: true, color: "6C757D" })
        ]
      }));
    });
  });

  // ── PIE ──
  children.push(new Paragraph({
    spacing: { before: 400 },
    border: { top: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC", space: 8 } },
    children: [new TextRun({ text: "Este documento fue generado automáticamente a partir del análisis de los estados financieros proporcionados. Las observaciones deben ser validadas por el equipo contable antes de tomar acciones correctivas.", size: 17, font: "Arial", color: "6C757D", italics: true })]
  }));

  return new Document({
    styles: {
      default: { document: { run: { font: "Arial", size: 20 } } },
      paragraphStyles: [
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 28, bold: true, font: "Arial" },
          paragraph: { spacing: { before: 240, after: 240 }, outlineLevel: 0 } },
        { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 24, bold: true, font: "Arial" },
          paragraph: { spacing: { before: 180, after: 180 }, outlineLevel: 1 } },
        { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 22, bold: true, font: "Arial" },
          paragraph: { spacing: { before: 120, after: 120 }, outlineLevel: 2 } },
      ]
    },
    sections: [{
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
        }
      },
      children
    }]
  });
}

function buildSummaryTable(findings) {
  const colWidths = [1800, 4560, 1200, 1800];
  const headerCells = ["Sección", "Descripción", "Severidad", "Acción"].map(text =>
    new TableCell({
      borders: BORDERS,
      width: { size: colWidths[["Sección", "Descripción", "Severidad", "Acción"].indexOf(text)], type: WidthType.DXA },
      margins: CELL_MARGINS,
      shading: { fill: COLORS.headerBg, type: ShadingType.CLEAR },
      children: [new Paragraph({ children: [new TextRun({ text, bold: true, size: 18, font: "Arial", color: COLORS.primary })] })]
    })
  );

  const rows = [new TableRow({ children: headerCells })];

  findings.filter(f => f.type !== "ok").forEach(f => {
    const bgColor = f.type === "critical" ? COLORS.criticalBg : f.type === "warning" ? COLORS.warningBg : COLORS.neutralBg;
    const sevLabel = f.type === "critical" ? "Crítico" : f.type === "warning" ? "Advertencia" : "Info";
    const cells = [
      f.section,
      f.description.length > 120 ? f.description.substring(0, 117) + "..." : f.description,
      sevLabel,
      f.action.length > 80 ? f.action.substring(0, 77) + "..." : f.action
    ].map((text, i) =>
      new TableCell({
        borders: BORDERS,
        width: { size: colWidths[i], type: WidthType.DXA },
        margins: CELL_MARGINS,
        shading: i === 2 ? { fill: bgColor, type: ShadingType.CLEAR } : undefined,
        children: [new Paragraph({ children: [new TextRun({ text, size: 17, font: "Arial" })] })]
      })
    );
    rows.push(new TableRow({ children: cells }));
  });

  return new Table({
    width: { size: TABLE_WIDTH, type: WidthType.DXA },
    columnWidths: colWidths,
    rows
  });
}

// ════════════════════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════════════════════
function fmt(n) {
  if (n === null || n === undefined) return "-";
  return Math.round(n).toLocaleString("en-US");
}

// ════════════════════════════════════════════════════════════
// CLI
// ════════════════════════════════════════════════════════════
async function main() {
  const args = process.argv.slice(2);
  if (args.length < 2) {
    console.log("Usage: node generate_minuta.js <data.json> [ratios.json] <output.docx>");
    process.exit(1);
  }

  const dataPath = args[0];
  const outputPath = args.length === 3 ? args[2] : args[1];
  const ratiosPath = args.length === 3 ? args[1] : null;

  const data = JSON.parse(fs.readFileSync(dataPath, "utf8"));
  const ratios = ratiosPath && fs.existsSync(ratiosPath)
    ? JSON.parse(fs.readFileSync(ratiosPath, "utf8"))
    : {};

  console.log(`📋 Generando minuta de observaciones para ${data.empresa || "Empresa"}...`);

  const findings = runChecks(data, ratios).concat(runPassed(data));
  const doc = buildDocument(data, findings);
  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outputPath, buffer);

  const criticals = findings.filter(f => f.type === "critical").length;
  const warnings = findings.filter(f => f.type === "warning").length;
  const infos = findings.filter(f => f.type === "info").length;

  console.log(`✅ Minuta generada: ${outputPath}`);
  console.log(`   🔴 Críticos: ${criticals}`);
  console.log(`   🟡 Advertencias: ${warnings}`);
  console.log(`   ℹ️  Informativos: ${infos}`);

  if (criticals > 0) {
    console.log(`\n⚠️  HAY OBSERVACIONES CRÍTICAS. Coordinar con contabilidad antes de generar reporte ejecutivo.`);
  }
}

main().catch(err => { console.error("❌ Error:", err.message); process.exit(1); });
