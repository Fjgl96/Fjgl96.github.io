#!/usr/bin/env node
/**
 * generate_pptx.js — Report Generation Engine V4
 *
 * Reads data.json + ratios.json + slide_plan.json
 * Applies modular templates from templates/
 * Outputs reporte.pptx
 *
 * Usage:
 *   node generate_pptx.js data.json ratios.json slide_plan.json output.pptx
 */

const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");
const helpers = require(path.join(__dirname, "..", "templates", "base.js"));

// ════════════════════════════════════════════════════════════
// TEMPLATE REGISTRY
// ════════════════════════════════════════════════════════════
// Each template is a function(pres, slide, data, ratios, plan, slideConfig, helpers)
// Templates are loaded dynamically from the templates/ directory.
// If a template file doesn't exist, falls back to a generic handler.

function loadTemplate(templateName) {
  const templatePath = path.join(__dirname, "..", "templates", `${templateName}.js`);
  if (fs.existsSync(templatePath)) {
    return require(templatePath);
  }
  return null;
}

// ════════════════════════════════════════════════════════════
// BUILT-IN TEMPLATES (for portada and cierre which are simple)
// ════════════════════════════════════════════════════════════
function slidePortada(pres, data, ratios, plan, slideConfig) {
  const C = helpers.COLORS;
  const slide = pres.addSlide();
  slide.background = { color: C.primary };

  const empresa = plan.empresa || data.empresa || "Empresa";
  const periodo = plan.periodo || data.periodo || "";

  slide.addText(empresa, {
    x: 0.5, y: 1.8, w: 12.33, h: 1,
    fontSize: 36, fontFace: helpers.FONT, color: C.white, bold: true, align: "center"
  });

  // Mode badge
  const modeLabel = plan.mode === "status" ? "Status Ejecutivo" : "Reporte Financiero Ejecutivo";
  slide.addText(modeLabel, {
    x: 0.5, y: 3.2, w: 12.33, h: 0.6,
    fontSize: 18, fontFace: helpers.FONT, color: C.portadaAccent, align: "center"
  });

  slide.addShape(pres.shapes.LINE, {
    x: 4.5, y: 3.0, w: 4.33, h: 0,
    line: { color: C.portadaAccent, width: 1 }
  });

  slide.addText(periodo, {
    x: 0.5, y: 4.0, w: 12.33, h: 0.5,
    fontSize: 14, fontFace: helpers.FONT, color: C.portadaAccent, align: "center"
  });

  slide.addText("Información preparada para uso interno", {
    x: 0.5, y: 6.5, w: 12.33, h: 0.4,
    fontSize: 9, fontFace: helpers.FONT, color: C.portadaMuted, align: "center"
  });
}

function slideCierre(pres, data, ratios, plan, slideConfig) {
  const C = helpers.COLORS;
  const slide = pres.addSlide();
  slide.background = { color: C.primary };

  const empresa = plan.empresa || data.empresa || "Empresa";
  const modeLabel = plan.mode === "status" ? "Status Ejecutivo" : "Reporte Financiero Ejecutivo";

  slide.addText(empresa, {
    x: 0.5, y: 2.3, w: 12.33, h: 0.8,
    fontSize: 24, fontFace: helpers.FONT, color: C.white, bold: true, align: "center"
  });
  slide.addText(modeLabel, {
    x: 0.5, y: 3.1, w: 12.33, h: 0.5,
    fontSize: 14, fontFace: helpers.FONT, color: C.portadaAccent, align: "center"
  });
  slide.addShape(pres.shapes.LINE, {
    x: 4.5, y: 3.8, w: 4.33, h: 0,
    line: { color: C.portadaAccent, width: 1 }
  });
  slide.addText(
    "Información preparada para uso interno.\nLas proyecciones y recomendaciones son estimaciones basadas en la información contable proporcionada.",
    {
      x: 1.5, y: 4.3, w: 10.33, h: 0.8,
      fontSize: 10, fontFace: helpers.FONT, color: C.portadaMuted, align: "center"
    }
  );
}

// ════════════════════════════════════════════════════════════
// FALLBACK: Generic slide when template not found
// ════════════════════════════════════════════════════════════
function slideFallback(pres, data, ratios, plan, slideConfig) {
  const slide = pres.addSlide();
  helpers.addHeader(pres, slide, `[Template: ${slideConfig.template}]`);
  helpers.addSummaryBoxSimple(pres, slide,
    `Template "${slideConfig.template}" no encontrado. Slide ID: ${slideConfig.id}. Generar manualmente.`
  );
  slide.addText(JSON.stringify(slideConfig, null, 2), {
    x: 0.5, y: 1.5, w: 12, h: 5,
    fontSize: 7, fontFace: "Consolas", color: helpers.COLORS.neutral
  });
}

// ════════════════════════════════════════════════════════════
// MAIN GENERATION PIPELINE
// ════════════════════════════════════════════════════════════
async function generate(dataPath, ratiosPath, planPath, outputPath) {
  // Load inputs
  const data = JSON.parse(fs.readFileSync(dataPath, "utf8"));
  const ratios = JSON.parse(fs.readFileSync(ratiosPath, "utf8"));
  const plan = JSON.parse(fs.readFileSync(planPath, "utf8"));

  // Create presentation
  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE";  // 13.33 x 7.5
  pres.author = "Reporte Financiero V4";
  pres.title = `${plan.empresa} — ${plan.mode === "status" ? "Status" : "Diagnóstico"} ${plan.periodo}`;

  console.log(`📊 Generating ${plan.mode.toUpperCase()} report for ${plan.empresa}`);
  console.log(`   Slides: ${plan.slides.length}`);
  console.log(`   Severity: ${plan.severity}`);
  console.log(`   Mode config: recommendations=${plan.mode_config.include_recommendations}`);

  // Built-in templates
  const BUILTIN = {
    "slide_portada": slidePortada,
    "slide_cierre": slideCierre,
  };

  // Generate each slide in plan order
  for (const slideConfig of plan.slides) {
    const templateName = slideConfig.template;

    // Check built-in first
    if (BUILTIN[templateName]) {
      BUILTIN[templateName](pres, data, ratios, plan, slideConfig);
      console.log(`   ✅ ${slideConfig.id} (built-in: ${templateName})`);
      continue;
    }

    // Try loading external template
    const template = loadTemplate(templateName);
    if (template) {
      template(pres, data, ratios, plan, slideConfig, helpers);
      console.log(`   ✅ ${slideConfig.id} (template: ${templateName})`);
    } else {
      // Fallback
      slideFallback(pres, data, ratios, plan, slideConfig);
      console.log(`   ⚠️  ${slideConfig.id} (FALLBACK — template not found: ${templateName})`);
    }
  }

  // Save
  await pres.writeFile({ fileName: outputPath });
  console.log(`\n✅ Report saved: ${outputPath}`);
}

// ════════════════════════════════════════════════════════════
// CLI
// ════════════════════════════════════════════════════════════
const args = process.argv.slice(2);
if (args.length < 4) {
  console.log("Usage: node generate_pptx.js <data.json> <ratios.json> <slide_plan.json> <output.pptx>");
  process.exit(1);
}

generate(args[0], args[1], args[2], args[3])
  .then(() => process.exit(0))
  .catch(err => { console.error("❌ Error:", err); process.exit(1); });
