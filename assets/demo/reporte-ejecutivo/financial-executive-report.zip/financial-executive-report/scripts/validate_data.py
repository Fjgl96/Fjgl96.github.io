#!/usr/bin/env python3
"""
Validador de datos financieros.
Lee un JSON con los estados financieros y verifica consistencia.

Uso:
    python scripts/validate_data.py data.json
    cat data.json | python scripts/validate_data.py

Input JSON esperado:
{
  "periodos": ["2024", "2025"],
  "moneda": "PEN",
  "balance": {
    "2025": {
      "activo_corriente": {
        "efectivo": 1000000,
        "cuentas_por_cobrar": 5000000,
        "inventarios": 3000000,
        "otros_activos_corrientes": 200000,
        "total_activo_corriente": 9200000
      },
      "activo_no_corriente": {
        "inmuebles_maquinaria_equipo": 4000000,
        "depreciacion_acumulada": -1000000,
        "intangibles": 100000,
        "otros_activos_no_corrientes": 0,
        "total_activo_no_corriente": 3100000
      },
      "total_activo": 12300000,
      "pasivo_corriente": {
        "cuentas_por_pagar": 6000000,
        "tributos_por_pagar": 500000,
        "remuneraciones_por_pagar": 300000,
        "otras_cuentas_por_pagar": 200000,
        "total_pasivo_corriente": 7000000
      },
      "pasivo_no_corriente": {
        "deuda_largo_plazo": 1000000,
        "otros_pasivos_no_corrientes": 0,
        "total_pasivo_no_corriente": 1000000
      },
      "total_pasivo": 8000000,
      "patrimonio": {
        "capital": 2000000,
        "resultados_acumulados": 1500000,
        "resultado_del_periodo": 800000,
        "total_patrimonio": 4300000
      },
      "total_pasivo_patrimonio": 12300000
    }
  },
  "estado_resultados": {
    "2025": {
      "ventas_netas": 50000000,
      "costo_ventas": -42500000,
      "margen_bruto": 7500000,
      "gastos_administracion": -2000000,
      "gastos_ventas": -1500000,
      "gastos_distribucion": -500000,
      "otros_gastos_operativos": 0,
      "margen_operativo": 3500000,
      "gastos_financieros": -800000,
      "diferencia_cambio": -200000,
      "ingresos_financieros": 50000,
      "otros_ingresos_gastos": 100000,
      "utilidad_antes_impuestos": 2650000,
      "impuesto_renta": -780000,
      "participaciones": -70000,
      "resultado_ejercicio": 1800000
    }
  }
}

Output JSON:
{
  "valid": true/false,
  "errors": [...],
  "warnings": [...],
  "summary": {
    "periodos_detectados": 2,
    "modo_sugerido": "multiperiodo",
    "moneda": "PEN",
    "tiene_presupuesto": false
  }
}
"""

import json
import sys
from pathlib import Path

TOLERANCE = 0.001  # 0.1% tolerance for balance check


def load_data(source=None):
    """Load JSON from file path or stdin."""
    if source and Path(source).exists():
        with open(source, 'r', encoding='utf-8') as f:
            return json.load(f)
    else:
        return json.load(sys.stdin)


def validate_balance_equation(balance: dict, periodo: str) -> list:
    """Verify Total Activo = Total Pasivo + Patrimonio."""
    errors = []
    total_activo = balance.get('total_activo', 0)
    total_pasivo = balance.get('total_pasivo', 0)
    total_patrimonio = balance.get('patrimonio', {}).get('total_patrimonio', 0)
    total_pp = balance.get('total_pasivo_patrimonio', total_pasivo + total_patrimonio)

    if total_activo == 0:
        errors.append(f"[{periodo}] Total Activo es 0 o no está presente.")
        return errors

    diff_pct = abs(total_activo - total_pp) / abs(total_activo)
    if diff_pct > TOLERANCE:
        errors.append(
            f"[{periodo}] Ecuación patrimonial NO cuadra: "
            f"Total Activo ({total_activo:,.0f}) ≠ Total P+P ({total_pp:,.0f}). "
            f"Diferencia: {abs(total_activo - total_pp):,.0f} ({diff_pct:.2%})"
        )

    # Verify subtotals
    ac = balance.get('activo_corriente', {})
    ac_items_sum = sum(
        v for k, v in ac.items()
        if k != 'total_activo_corriente' and isinstance(v, (int, float))
    )
    ac_total = ac.get('total_activo_corriente', 0)
    if ac_total != 0:
        diff = abs(ac_items_sum - ac_total) / abs(ac_total)
        if diff > TOLERANCE:
            errors.append(
                f"[{periodo}] Subtotal Activo Corriente no cuadra: "
                f"suma partidas ({ac_items_sum:,.0f}) vs total ({ac_total:,.0f})"
            )

    return errors


def validate_resultado_consistency(balance: dict, er: dict, periodo: str) -> tuple:
    """
    Verify Resultado del Periodo (BG) matches Resultado del Ejercicio (ER).
    
    Returns (errors, warnings) tuple.
    This is a CRITICAL cross-check: if these don't match, the entire report
    loses credibility with any CFO or board member.
    """
    errors = []
    warnings = []
    resultado_bg = balance.get('patrimonio', {}).get('resultado_del_periodo', None)
    resultado_er = er.get('resultado_ejercicio', None)

    if resultado_bg is not None and resultado_er is not None:
        diff = abs(resultado_bg - resultado_er)
        if diff > 100:
            # Material difference → ERROR (blocks report generation)
            errors.append(
                f"[{periodo}] ❌ RESULTADO EGP ≠ ESF: "
                f"Estado de Resultados ({resultado_er:,.0f}) difiere del Balance ({resultado_bg:,.0f}) "
                f"en S/ {diff:,.0f}. ESTE ERROR DESTRUYE CREDIBILIDAD. "
                f"Acción: verificar hojas del Excel fuente — posible copia de distinto corte."
            )
        elif diff > 1:
            # Minor difference → WARNING (proceed with caution)
            warnings.append(
                f"[{periodo}] ⚠️ Resultado EGP ({resultado_er:,.0f}) vs ESF ({resultado_bg:,.0f}) "
                f"difieren en S/ {diff:,.0f}. Diferencia menor pero reportar al cliente."
            )
    elif resultado_bg is None and resultado_er is not None:
        warnings.append(
            f"[{periodo}] Resultado del Ejercicio no encontrado en el Balance General. "
            f"Usando valor del EGP (S/ {resultado_er:,.0f}). Verificar con usuario."
        )
    elif resultado_bg is not None and resultado_er is None:
        warnings.append(
            f"[{periodo}] Resultado del Ejercicio no encontrado en el EGP. "
            f"Usando valor del Balance (S/ {resultado_bg:,.0f}). Verificar con usuario."
        )

    return errors, warnings


def validate_missing_fields(balance: dict, er: dict, periodo: str) -> list:
    """Check for critical missing fields."""
    warnings = []

    critical_bg = ['total_activo', 'total_pasivo']
    for field in critical_bg:
        if balance.get(field) in (None, 0):
            warnings.append(f"[{periodo}] Campo crítico '{field}' es 0 o no está en el Balance.")

    critical_er = ['ventas_netas', 'resultado_ejercicio']
    for field in critical_er:
        if er.get(field) in (None, 0):
            warnings.append(f"[{periodo}] Campo crítico '{field}' es 0 o no está en el ER.")

    # Check for EBITDA possibility
    ac = balance.get('activo_no_corriente', {})
    if 'depreciacion_acumulada' not in ac and ac.get('depreciacion_acumulada') is None:
        warnings.append(
            f"[{periodo}] Depreciación acumulada no separada en BG. "
            f"EBITDA se reportará como N/D."
        )

    return warnings


def check_edge_cases(balance: dict, er: dict, periodo: str) -> list:
    """Detect edge cases that affect ratio calculations."""
    warnings = []
    patrimonio = balance.get('patrimonio', {}).get('total_patrimonio', 0)
    pasivo_cte = balance.get('pasivo_corriente', {}).get('total_pasivo_corriente', 0)
    ventas = er.get('ventas_netas', 0)

    if patrimonio < 0:
        warnings.append(
            f"[{periodo}] ⚠️ PATRIMONIO NEGATIVO ({patrimonio:,.0f}). "
            f"ROE y D/E se reportarán como N/A. La empresa tiene pérdidas acumuladas "
            f"que superan el capital. Esto debe destacarse en conclusiones."
        )
    if patrimonio == 0:
        warnings.append(f"[{periodo}] Patrimonio = 0. ROE y D/E serán N/A (división por cero).")

    if pasivo_cte == 0:
        warnings.append(f"[{periodo}] Pasivo Corriente = 0. Ratios de liquidez serán N/A.")

    if ventas == 0:
        warnings.append(f"[{periodo}] Ventas Netas = 0. Márgenes y rotaciones serán N/A.")

    return warnings


def validate_patrimonio_composition(balance: dict, periodo: str) -> list:
    """Verify that patrimonio components sum to total_patrimonio."""
    warnings = []
    pat = balance.get('patrimonio', {})
    total_stated = pat.get('total_patrimonio', 0)
    
    capital = pat.get('capital', 0)
    reservas = pat.get('reservas', 0)
    resultados_acum = pat.get('resultados_acumulados', pat.get('perdidas_acum', 0))
    resultado_ej = pat.get('resultado_del_periodo', 0)
    
    # Make perdidas_acum negative if stored as positive
    if resultados_acum > 0 and total_stated < capital:
        resultados_acum = -resultados_acum
    
    computed = capital + reservas + resultados_acum + resultado_ej
    diff = abs(computed - total_stated)
    
    if diff > 100 and total_stated != 0:
        warnings.append(
            f"[{periodo}] Patrimonio declarado ({total_stated:,.0f}) ≠ suma componentes ({computed:,.0f}). "
            f"Capital ({capital:,.0f}) + Reservas ({reservas:,.0f}) + Resultados Acum ({resultados_acum:,.0f}) "
            f"+ Resultado Ej ({resultado_ej:,.0f}) = {computed:,.0f}. Diferencia: {diff:,.0f}."
        )
    
    return warnings


def determine_mode(data: dict) -> dict:
    """Determine analysis mode and summary."""
    periodos = data.get('periodos', [])
    tiene_presupuesto = 'presupuesto' in data
    n_periodos = len(periodos)

    if n_periodos >= 2 and tiene_presupuesto:
        modo = 'completo'
    elif n_periodos >= 2:
        modo = 'multiperiodo'
    elif tiene_presupuesto:
        modo = 'comparativo'
    else:
        modo = 'simple'

    return {
        'periodos_detectados': n_periodos,
        'modo_sugerido': modo,
        'moneda': data.get('moneda', 'PEN'),
        'tiene_presupuesto': tiene_presupuesto,
        'periodos': periodos,
    }


def validate(data: dict) -> dict:
    """Run all validations and return results."""
    errors = []
    warnings = []

    periodos = data.get('periodos', [])
    balances = data.get('balance', {})
    ers = data.get('estado_resultados', {})

    for periodo in periodos:
        bg = balances.get(periodo, {})
        er = ers.get(periodo, {})

        if not bg:
            errors.append(f"[{periodo}] No se encontró Balance General.")
            continue
        if not er:
            warnings.append(f"[{periodo}] No se encontró Estado de Resultados. Análisis limitado.")

        errors.extend(validate_balance_equation(bg, periodo))
        if er:
            resultado_errors, resultado_warnings = validate_resultado_consistency(bg, er, periodo)
            errors.extend(resultado_errors)
            warnings.extend(resultado_warnings)
            warnings.extend(validate_missing_fields(bg, er, periodo))
            warnings.extend(check_edge_cases(bg, er, periodo))
        warnings.extend(validate_patrimonio_composition(bg, periodo))

    summary = determine_mode(data)

    return {
        'valid': len(errors) == 0,
        'errors': errors,
        'warnings': warnings,
        'summary': summary,
    }


if __name__ == '__main__':
    source = sys.argv[1] if len(sys.argv) > 1 else None
    try:
        data = load_data(source)
        result = validate(data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result['valid'] else 1)
    except json.JSONDecodeError as e:
        print(json.dumps({'valid': False, 'errors': [f'JSON inválido: {e}'], 'warnings': [], 'summary': {}}))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({'valid': False, 'errors': [f'Error inesperado: {e}'], 'warnings': [], 'summary': {}}))
        sys.exit(1)
