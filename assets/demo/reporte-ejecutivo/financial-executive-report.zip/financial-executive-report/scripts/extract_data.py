#!/usr/bin/env python3
"""
extract_data.py — Automatic Excel Parser for Financial Reports V4

Parses Peruvian accounting Excel files (ESF + EGP) into standardized data.json.
Handles multiple Excel formats with heuristic detection.

Usage:
    python extract_data.py /path/to/excel.xlsx --sector restaurants --output data.json
"""

import json
import sys
import argparse
import re
from pathlib import Path

try:
    import openpyxl
except ImportError:
    print("ERROR: pip install openpyxl --break-system-packages")
    sys.exit(1)


# ─────────────────────────────────────────────────────────────
# ACCOUNT NAME MAPPING (Peruvian PCGE → standardized keys)
# ─────────────────────────────────────────────────────────────
ACCOUNT_MAP = {
    # Activo Corriente
    "efectivo": ["efectivo y equivalente", "caja y bancos", "efectivo", "cash"],
    "cxc_comerciales": ["cuentas por cobrar comerciales", "clientes", "deudores comerciales", "cxc comercial"],
    "cxc_personal": ["cuentas por cobrar acc", "cuentas por cobrar al personal", "cuentas por cobrar personal", "cxc personal", "cxc acc"],
    "cxc_diversas": ["cuentas por cobrar diversas", "cxc diversas", "otras cuentas por cobrar corriente"],
    "gastos_anticipados": ["servicios y otros contratados por anticipado", "gastos pagados por anticipado",
                           "gastos contratados por anticipado", "contratados por anticipado",
                           "gastos anticipados", "gastos preoperativos", "cargas diferidas"],
    "mercaderias": ["existencias", "mercaderias", "mercaderías", "materias primas", "mercaderias y materias"],
    "suministros_menajes": ["mat. auxiliar", "suministros", "menajes", "materiales auxiliares"],
    "otros_activos_corr": ["otros activos"],
    # Activo No Corriente
    "ime_bruto": ["inmuebles", "maquinaria y equipo", "activo fijo", "ppe", "propiedad planta"],
    "depreciacion": ["depreciación", "depreciacion acumulada", "deprec"],
    "intangibles": ["intangibles", "activos intangibles"],
    "otras_cxc_nc": ["otras cuentas por cobrar", "cxc no corriente", "inversiones"],
    # Pasivo Corriente
    "sobregiros": ["sobregiros", "prestamos bancarios cp", "obligaciones financieras cp"],
    "tributos_pagar": ["tributos por pagar", "tributos", "impuestos por pagar"],
    "remuneraciones_pagar": ["remuneraciones por pagar", "remuneraciones", "sueldos por pagar"],
    "cxp_comerciales": ["cuentas por pagar comerciales", "proveedores", "cxp comercial"],
    "cxp_relacionadas": ["cxp comerciales-relacionadas", "cuentas por pagar relacionadas", "partes relacionadas cp"],
    "cxp_diversas": ["cuentas por pagar diversas", "cxp diversas", "otras cuentas por pagar"],
    "provisiones": ["provisiones", "provisiones diversas"],
    # Pasivo No Corriente
    "cxp_accionistas_nc": ["cuentas por pagar accionistas", "prestamos accionistas", "deuda accionistas",
                            "cxp accionistas nc", "cuentas por pagar acc"],
    "oblig_fin_lp": ["obligaciones financieras", "deuda largo plazo", "prestamos bancarios lp"],
    # Patrimonio
    "capital": ["capital social", "capital"],
    "reservas": ["reservas", "reserva legal"],
    "resultados_acum": ["resultados acumulados", "utilidades retenidas"],
    "perdidas_acum": ["pérdidas acumuladas", "perdidas acumuladas"],
    "resultado_ejercicio": ["resultado del ejercicio", "resultado del periodo", "utilidad del ejercicio", "resultado neto"],
}

EGP_MAP = {
    "ventas_brutas": ["venta bruta", "ventas brutas", "ingresos brutos"],
    "mermas": ["mermas"],
    "cortesias": ["cortesias", "cortesías"],
    "consumos_internos": ["consumos internos"],
    "ventas_netas": ["ventas netas", "ingresos netos", "ingresos operacionales"],
    "costo_ventas": ["costo restaurante", "costo de ventas", "costo servicio", "costo de servicio",
                     "costo de restaurante", "cost of sales"],
    "utilidad_bruta": ["utilidad bruta", "margen bruto", "ganancia bruta"],
    "gastos_restaurante": ["gastos de restaurante", "gastos operativos", "gastos de operación"],
    "gastos_admin": ["gastos administrativos", "gastos de administración", "gastos admin"],
    "gastos_ventas": ["gastos de venta", "gastos de ventas", "gastos comerciales"],
    "ebit": ["utilidad de operacion", "utilidad operativa", "resultado operativo"],
    "gastos_financieros": ["gastos financieros"],
    "ingresos_financieros": ["ingresos financieros"],
    "dif_cambio": ["diferencia de cambio", "ganancia (pérdida) diferencia", "diferencia en cambio", "dif. cambio"],
    # El SUBTOTAL del bloque va primero a propósito. "OTROS INGRESOS Y GASTOS"
    # es el encabezado que carga la suma del bloque —diferencia de cambio más
    # otros ingresos— y contiene la cadena "otros ingresos", así que sin una
    # clave propia se lo llevaba `otros_ingresos` y la partida quedaba contada
    # dos veces: una dentro del subtotal y otra en su propia línea.
    "otros_ing_gastos_bloque": ["otros ingresos y gastos"],
    "otros_ingresos": ["otros ingresos de gestion", "otros ingresos", "ingresos diversos"],
    "auspicios": ["auspicios"],
    "impuesto_renta": ["impuesto sobre la renta", "impuesto a la renta",
                       "gasto en impuesto", "participaciones e impuesto"],
    "utilidad_antes_impuestos": ["utilidad antes de imp", "resultado antes de imp"],
    "resultado_ejercicio": ["resultado del ejercicio", "utilidad neta", "resultado neto"],
    "depreciacion": ["depreciacion y amortizacion", "depreciación", "deprec"],
    "ebitda": ["ebitda"],
}

# Sub-items of gastos for breakdown
GASTO_SUB_MAP = {
    "cargas_personal": ["cargas de personal", "remuneraciones", "personal"],
    "servicios_terceros": ["servicios prestados por terceros", "servicios terceros", "servicios"],
    "tributos_gasto": ["tributos"],
    "cargas_diversas": ["cargas diversas de gestion", "cargas diversas", "diversos"],
    "provisiones_gasto": ["provisiones del ejercicio", "provisiones"],
}

# ─────────────────────────────────────────────────────────────
# BANKING ACCOUNT MAPS (SBS / BCRP structure)
# ─────────────────────────────────────────────────────────────
BANKING_ASSET_MAP = {
    # Activo — Disponible
    "disponible_caja": ["caja y canje", "caja"],
    "disponible_bcrp": ["bcrp", "banco central de reserva"],
    "disponible_bancos": ["depositos en bancos", "bancos del pais", "bancos del exterior"],
    "disponible_total": ["total disponible", "fondos disponibles"],
    # Activo — Inversiones
    "inversiones_fin": ["inversiones financieras", "inversiones disponibles para la venta",
                        "inversiones a vencimiento", "inversiones negociacion"],
    # Activo — Créditos
    "colocaciones_brutas": ["colocaciones brutas", "creditos directos brutos", "cartera bruta"],
    "provisiones_credito": ["provisiones para creditos", "provision para creditos directos",
                            "menos provisiones"],
    "colocaciones_netas": ["colocaciones netas", "creditos directos netos", "cartera neta"],
    # Cartera alto riesgo (para CAR)
    "cartera_vencida": ["cartera vencida", "creditos vencidos"],
    "cartera_judicial": ["cartera judicial", "creditos en cobranza judicial"],
    "cartera_refinanciada": ["creditos refinanciados", "cartera refinanciada"],
    "cartera_reestructurada": ["creditos reestructurados", "cartera reestructurada"],
    # Activo — Otros
    "inversiones_subsidiarias": ["inversiones en subsidiarias", "participaciones"],
    "ime_bruto_bancario": ["inmuebles mobiliario y equipo", "activo fijo bancario"],
    "otros_activos": ["otros activos", "activos intangibles bancarios"],
}

BANKING_PASIVO_MAP = {
    # Obligaciones con el Público
    "dep_vista": ["depositos a la vista", "obligaciones a la vista", "cuentas corrientes"],
    "dep_ahorro": ["depositos de ahorro", "cuentas de ahorro"],
    "dep_plazo": ["depositos a plazo", "certificados de deposito"],
    "dep_cts": ["depositos cts", "compensacion tiempo de servicios", "cts"],
    "dep_total": ["total depositos", "obligaciones con el publico total"],
    # Fondeo institucional
    "dep_sist_fin": ["depositos del sistema financiero", "depositos empresas del sistema financiero"],
    "adeudos": ["adeudos y obligaciones financieras", "adeudos al bcrp", "adeudos exterior"],
    "valores_circulacion": ["valores en circulacion", "bonos corporativos", "bonos subordinados"],
    "otros_pasivos": ["otros pasivos", "cuentas por pagar"],
    # Patrimonio
    "capital_bancario": ["capital social", "capital"],
    "reservas_bancarias": ["reservas", "reserva legal"],
    "resultados_acum_bancario": ["resultados acumulados", "utilidades no distribuidas"],
    "resultado_bancario": ["resultado del ejercicio", "utilidad neta del ejercicio"],
    "patrimonio_efectivo": ["patrimonio efectivo", "capital regulatorio", "tier 1"],
}

BANKING_EGP_MAP = {
    # Ingresos Financieros
    "ing_fin_colocaciones": ["intereses y comisiones por colocaciones", "ingresos por creditos",
                             "intereses por creditos directos"],
    "ing_fin_inversiones": ["intereses por inversiones", "ingresos por inversiones financieras"],
    "ing_fin_disponible": ["ingresos por disponible", "intereses por fondos disponibles"],
    "ing_fin_otros": ["otros ingresos financieros"],
    "ing_financieros_total": ["total ingresos financieros", "ingresos financieros"],
    # Gastos Financieros
    "gasto_fin_depositos": ["intereses por depositos", "intereses obligaciones con el publico"],
    "gasto_fin_adeudos": ["intereses por adeudos", "intereses adeudos y obligaciones financieras"],
    "gasto_fin_valores": ["intereses por valores en circulacion"],
    "gasto_fin_otros": ["otros gastos financieros"],
    "gastos_financieros_total": ["total gastos financieros", "gastos financieros"],
    # Margen Financiero
    "margen_fin_bruto": ["margen financiero bruto"],
    "gasto_provisiones": ["gasto por provisiones", "provisiones para creditos directos",
                          "provision creditos directos", "provision para incobrabilidad"],
    "margen_fin_neto": ["margen financiero neto"],
    # Ingresos por Servicios
    "ing_serv_fin_netos": ["ingresos por servicios financieros netos", "ingresos netos por servicios"],
    "ing_serv_brutos": ["ingresos por servicios financieros"],
    "gasto_serv": ["gastos por servicios financieros"],
    # ROF
    "rof": ["resultado en operaciones financieras", "rof", "ganancia en inversiones"],
    # Resultado Operacional
    "margen_op_bruto": ["margen operacional bruto", "resultado de operacion bruto"],
    "gastos_admin": ["gastos de administracion", "gastos administrativos"],
    "margen_op_neto": ["margen operacional neto", "resultado de operacion neto"],
    # Resultado Final
    "provisiones_otras": ["provisiones por contingencias", "otras provisiones"],
    "otros_ingresos_gastos": ["otros ingresos y gastos", "resultado extraordinario"],
    "impuesto_renta": ["impuesto a la renta", "participaciones e impuesto"],
    "utilidad_neta_bancaria": ["utilidad neta", "resultado neto del ejercicio"],
    # Activos ponderados por riesgo (APR)
    "apr": ["activos ponderados por riesgo", "apr"],
}

BANKING_RATIOS_EXTRA_MAP = {
    # Liquidity ratios SBS
    "activos_liquidos_mn": ["activos liquidos mn", "activos liquidos moneda nacional"],
    "activos_liquidos_me": ["activos liquidos me", "activos liquidos moneda extranjera"],
    "pasivos_cp_mn": ["pasivos cp mn", "pasivos corto plazo moneda nacional"],
    "pasivos_cp_me": ["pasivos cp me", "pasivos corto plazo moneda extranjera"],
}

COST_CATEGORY_MAP = {
    "cerveza": ["cerveza"],
    "licores": ["licores", "cremas"],
    "vinos": ["vinos"],
    "gaseosas": ["gaseosa", "agua mineral", "bebidas"],
    "abarrotes": ["abarrotes"],
    "carnes": ["carnes", "aves", "congelados"],
    "frutas": ["frutas", "fruta fresca"],
    "lacteos": ["lacteos", "lácteos"],
    "pescados": ["pescados", "mariscos"],
    "verduras": ["verduras", "tubérculos", "tuberculos"],
    "compras_inafectas": ["compras inafectas", "inafectas"],
}


def normalize(text):
    """Normalize text for matching."""
    if not isinstance(text, str):
        return ""
    return re.sub(r'\s+', ' ', text.strip().lower())


def fold(text):
    """Minúsculas sin tildes. Un plan de cuentas real escribe la misma cuenta
    con y sin acento en la misma planilla; sin plegar, media tabla no matchea."""
    t = normalize(text)
    for a, b in (("á","a"),("é","e"),("í","i"),("ó","o"),("ú","u"),("ü","u"),("ñ","n")):
        t = t.replace(a, b)
    return t


def match_account(label, account_map):
    """Find the best matching key for a label."""
    label_norm = fold(label)
    if not label_norm:
        return None
    for key, patterns in account_map.items():
        for pattern in patterns:
            if fold(pattern) in label_norm:
                return key
    return None


# ─────────────────────────────────────────────────────────────
# SHEET DISCOVERY
# ─────────────────────────────────────────────────────────────
def leer_encabezado(ws):
    """Lo que la hoja DICE de sí misma: su título, el periodo que declara y el
    rótulo de su columna de datos. El título es la forma fiable de saber qué
    estado es —el nombre de la pestaña lo abrevia de mil maneras («BG», «ERF»,
    «EEFF 24»)— y el periodo y el rótulo se necesitan después, porque cuando no
    coinciden entre sí el reporte entero sale rotulado mal."""
    enc = {"titulo": "", "periodo_declarado": "", "rotulo_columna": ""}
    for r in range(1, min(12, ws.max_row + 1)):
        for c in range(1, min(9, ws.max_column + 1)):
            v = ws.cell(row=r, column=c).value
            if not isinstance(v, str):
                continue
            t = fold(v)
            if "estado de" in t or "balance general" in t:
                if not enc["titulo"]:
                    enc["titulo"] = v.strip()
            elif t.startswith("al ") and not enc["periodo_declarado"]:
                enc["periodo_declarado"] = v.strip()
            elif re.fullmatch(r"\d{1,2}/\d{4}", v.strip()) and not enc["rotulo_columna"]:
                enc["rotulo_columna"] = v.strip()
    return enc


def anio_de(*textos):
    for t in textos:
        m = re.search(r"(19|20)\d{2}", str(t or ""))
        if m:
            return m.group(0)
    return None


def discover_sheets(wb):
    """Identify which sheets contain ESF, EGP, and complementary data.

    Se clasifica por el TÍTULO que la hoja lleva adentro y, sólo como respaldo,
    por el nombre de la pestaña. Antes se miraba únicamente el nombre contra una
    lista corta de palabras clave, así que un libro con pestañas «BG 2027» y
    «ERF 2027» —las dos abreviaturas más comunes en Perú— no encontraba nada.

    Además se agrupa POR EJERCICIO: un libro con una hoja por año y por estado
    es lo normal en un cierre comparativo, y guardar una sola hoja por tipo
    descartaba todos los periodos menos el último.
    """
    sheets = {}
    por_periodo = {"balance": {}, "er": {}}
    encabezados = {}

    for name in wb.sheetnames:
        n = fold(name)
        ws = wb[name]
        enc = leer_encabezado(ws)
        t = fold(enc["titulo"])

        es_bal = ("situacion financiera" in t or "balance general" in t
                  or any(k in n for k in ["esf", "balance", "situacion financiera", "bg"]))
        es_er = ("estado de resultados" in t or "ganancias y perdidas" in t
                 or any(k in n for k in ["egp", "resultado", "ganancias", "perdidas", "income", "erf", "eerr"]))
        # El título manda: si dice lo que es, no se discute con el nombre.
        if "situacion financiera" in t or "balance general" in t:
            es_er = False
        elif "estado de resultados" in t or "ganancias y perdidas" in t:
            es_bal = False

        anio = anio_de(enc["periodo_declarado"], name)

        if es_bal:
            sheets["esf"] = name
            por_periodo["balance"][anio or name] = name
            encabezados.setdefault(anio or name, {})["balance"] = enc
        elif es_er:
            sheets["egp"] = name
            por_periodo["er"][anio or name] = name
            encabezados.setdefault(anio or name, {})["estado_resultados"] = enc
        elif any(k in n for k in ["bg analitico", "balance analitico", "analitico"]):
            sheets["bg_analitico"] = name
        elif any(k in n for k in ["pcge", "plan contable"]):
            sheets["pcge"] = name
        elif any(k in n for k in ["costo", "cost"]):
            sheets["costos"] = name
        elif any(k in n for k in ["centro", "cc"]):
            sheets["centro_costos"] = name
        elif any(k in n for k in ["planilla", "personal", "rrhh"]):
            sheets["planilla"] = name
        elif any(k in n for k in ["gastos detalle", "detalle gastos"]):
            sheets["gastos_detalle"] = name

    # El último ejercicio es el que manda para las vistas de periodo único.
    periodos = sorted(set(list(por_periodo["balance"]) + list(por_periodo["er"])))
    if periodos:
        ult = periodos[-1]
        if ult in por_periodo["balance"]:
            sheets["esf"] = por_periodo["balance"][ult]
        if ult in por_periodo["er"]:
            sheets["egp"] = por_periodo["er"][ult]
    sheets["_por_periodo"] = por_periodo
    sheets["_encabezados"] = encabezados
    sheets["_periodos"] = periodos
    return sheets


# ─────────────────────────────────────────────────────────────
# ESF PARSER
# ─────────────────────────────────────────────────────────────
def parse_esf(ws):
    """Parse Balance Sheet (Estado de Situación Financiera)."""
    result = {
        "activo_corriente": {},
        "activo_no_corriente": {},
        "pasivo_corriente": {},
        "pasivo_no_corriente": {},
        "patrimonio": {},
        "totales": {},
    }

    # Pares etiqueta-valor, AGRUPADOS POR COLUMNA.
    #
    # Un balance peruano suele venir en dos columnas: el activo a la izquierda
    # y el pasivo con el patrimonio a la derecha, ambos avanzando en paralelo
    # sobre las mismas filas. Recorriendo fila por fila, la secuencia queda
    # intercalada (efectivo, proveedores, clientes, tributos…) y el seguimiento
    # de sección —que es secuencial, se apoya en las filas de total— termina
    # asignando cuentas del activo al pasivo.
    #
    # Se leen los grupos de columnas por separado y en orden: primero el bloque
    # de la izquierda de arriba abajo, después el de la derecha. Así la
    # secuencia vuelve a ser la del documento y los totales delimitan bien.
    por_columna = {}
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, values_only=False):
        cells = [(c.column, c.value) for c in row if c.value is not None]
        for i, (col, val) in enumerate(cells):
            if isinstance(val, str) and len(val.strip()) > 2:
                for j in range(i + 1, min(i + 3, len(cells))):
                    _, next_val = cells[j]
                    if isinstance(next_val, (int, float)):
                        por_columna.setdefault(col, []).append((val.strip(), next_val))
                        break
                else:
                    # Un rótulo sin cifra al lado igual importa: los
                    # encabezados de sección ("PASIVO Y PATRIMONIO") no llevan
                    # número y son los que mueven el puntero de sección.
                    por_columna.setdefault(col, []).append((val.strip(), None))

    pairs = []
    for col in sorted(por_columna):
        pairs.extend(por_columna[col])

    # Map to structured output
    # Detect sections by total rows
    section = "activo_corriente"  # default start
    for label, value in pairs:
        label_lower = fold(label)
        if value is None and not any(
                k in label_lower for k in ["activo", "pasivo", "patrimonio"]):
            continue

        # Section detection via totals
        if "total activo corriente" in label_lower:
            result["activo_corriente"]["total_ac"] = value
            section = "activo_no_corriente"
            continue
        elif "total activo no corriente" in label_lower:
            result["activo_no_corriente"]["total_anc"] = value
            continue
        elif "total activo" in label_lower and "corriente" not in label_lower:
            result["totales"]["activo"] = value
            continue
        elif "total pasivo corriente" in label_lower:
            result["pasivo_corriente"]["total_pc"] = value
            section = "pasivo_no_corriente"
            continue
        elif "total pasivo no corriente" in label_lower:
            result["pasivo_no_corriente"]["total_pnc"] = value
            section = "patrimonio"
            continue
        elif "total patrimonio" in label_lower:
            result["patrimonio"]["total_patrimonio"] = value
            continue
        elif "total pasivo y patrimonio" in label_lower:
            result["totales"]["pasivo_patrimonio"] = value
            continue

        # Encabezados de sección (van sin cifra al lado).
        #
        # Antes se comparaba contra una lista de coincidencia exacta y
        # "PASIVO Y PATRIMONIO" —el encabezado del bloque derecho en casi todo
        # balance a dos columnas— contenía las dos palabras, así que no
        # activaba ninguna rama y el puntero se quedaba en el activo: todo el
        # pasivo terminaba archivado como activo no corriente.
        encabezados_seccion = [
            ("activo no corriente", "activo_no_corriente"),
            ("activo corriente", "activo_corriente"),
            ("pasivo no corriente", "pasivo_no_corriente"),
            ("pasivo corriente", "pasivo_corriente"),
            ("pasivo y patrimonio", "pasivo_corriente"),
            ("patrimonio", "patrimonio"),
            ("activo", "activo_corriente"),
        ]
        if value is None:
            for texto, destino in encabezados_seccion:
                if label_lower.strip() == texto or label_lower.strip().startswith(texto):
                    section = destino
                    break
            continue

        # Map account
        if value is None:
            continue
        key = match_account(label, ACCOUNT_MAP)
        if key:
            result[section][key] = value

    return result


# ─────────────────────────────────────────────────────────────
# EGP PARSER
# ─────────────────────────────────────────────────────────────
def parse_egp(ws):
    """Parse Income Statement (Estado de Ganancias y Pérdidas)."""
    result = {}
    monthly = {}
    gastos_rest_detalle = {}
    gastos_admin_detalle = {}
    cost_categories = {}

    # Find header row to identify column structure
    header_row = None
    total_col = None
    month_cols = {}

    MONTH_NAMES = {
        "enero": "ENE", "febrero": "FEB", "marzo": "MAR", "abril": "ABR",
        "mayo": "MAY", "junio": "JUN", "julio": "JUL", "agosto": "AGO",
        "septiembre": "SEP", "octubre": "OCT", "noviembre": "NOV", "diciembre": "DIC"
    }

    for row in ws.iter_rows(min_row=1, max_row=15, values_only=False):
        for c in row:
            if isinstance(c.value, str):
                val_lower = normalize(c.value)
                if "total" in val_lower and any(y in val_lower for y in ["2024", "2025", "2026", "anual"]):
                    total_col = c.column
                    header_row = c.row
                for month_name, month_code in MONTH_NAMES.items():
                    if month_name in val_lower:
                        month_cols[c.column] = month_code

    if not total_col:
        # Fallback: look for the rightmost numeric column
        for row in ws.iter_rows(min_row=1, max_row=15, values_only=False):
            for c in row:
                if isinstance(c.value, str) and "descripcion" in normalize(c.value):
                    header_row = c.row
                    break

    if not total_col:
        # ── MODO SIMPLE: estado de resultados de dos columnas ──
        #
        # El recorrido de abajo asume una planilla de gestión: etiqueta fija en
        # la columna B, una columna por mes y una columna "TOTAL <año>". Un
        # estado de resultados de cierre no tiene nada de eso: es una lista de
        # etiqueta y monto, y la etiqueta rara vez cae justo en B. Sin este
        # modo el parser devolvía cero líneas sobre un archivo perfectamente
        # legible.
        #
        # Se toma, por fila, la primera celda de texto como etiqueta y la
        # primera numérica que la siga como valor. La PRIMERA aparición manda:
        # estos estados repiten el subtotal arriba y abajo del bloque
        # ("UTILIDAD BRUTA" … "Total UTILIDAD BRUTA") y ambos valen lo mismo.
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row, values_only=False):
            celdas = [(c.column, c.value) for c in row if c.value is not None]
            etiqueta = valor = None
            for col, v in celdas:
                if etiqueta is None and isinstance(v, str) and len(v.strip()) > 2:
                    etiqueta = v.strip()
                elif etiqueta is not None and isinstance(v, (int, float)):
                    valor = v
                    break
            if etiqueta is None or valor is None:
                continue
            clave = match_account(etiqueta, EGP_MAP)
            if clave and clave not in result:
                result[clave] = valor
            # Toda línea numérica se conserva con su nombre propio: es lo que
            # permite después detectar que el plan de cuentas cambió entre
            # ejercicios, que a nivel de subtotales no se ve.
            slug = re.sub(r"[^a-z0-9]+", "_", fold(etiqueta)).strip("_")
            if slug and not slug.startswith("total_"):
                result.setdefault("_lineas", {})[slug] = valor
        return result, monthly, gastos_rest_detalle, gastos_admin_detalle, cost_categories

    # Parse data rows
    current_section = None  # Track if we're inside gastos_restaurante, gastos_admin, etc.

    for row in ws.iter_rows(min_row=(header_row or 7) + 1, max_row=ws.max_row, values_only=False):
        label = None
        total_value = None
        monthly_values = {}

        for c in row:
            if c.column == 2 and isinstance(c.value, str):  # Column B = label
                label = c.value.strip()
            if total_col and c.column == total_col and isinstance(c.value, (int, float)):
                total_value = c.value
            if c.column in month_cols and isinstance(c.value, (int, float)):
                monthly_values[month_cols[c.column]] = c.value

        if not label or total_value is None:
            # Check if this is a section header (label only, no value)
            if label:
                label_lower = normalize(label)
                if "gastos de restaurante" in label_lower or "gastos operativos" in label_lower:
                    current_section = "gastos_restaurante"
                elif "gastos administrativos" in label_lower:
                    current_section = "gastos_admin"
                elif "gastos preoperativos" in label_lower:
                    current_section = "gastos_preoperativos"
                elif "gastos de ventas" in label_lower:
                    current_section = "gastos_ventas"
                elif any(k in label_lower for k in ["utilidad", "resultado", "ebit", "venta"]):
                    current_section = None  # Reset on main line items
            continue

        # Map to EGP structure
        key = match_account(label, EGP_MAP)
        if key:
            result[key] = total_value
            if monthly_values:
                monthly[key] = monthly_values

        # Track sub-items for gastos breakdown
        sub_key = match_account(label, GASTO_SUB_MAP)
        if sub_key and current_section:
            if current_section == "gastos_restaurante":
                gastos_rest_detalle[sub_key] = total_value
            elif current_section == "gastos_admin":
                gastos_admin_detalle[sub_key] = total_value

        # Track cost categories
        cat_key = match_account(label, COST_CATEGORY_MAP)
        if cat_key:
            cost_categories[label.strip()] = total_value

        # Store monthly ventas for trend
        if key == "ventas_netas" and monthly_values:
            monthly["ventas_netas"] = monthly_values
        if key == "costo_ventas" and monthly_values:
            monthly["costo_ventas"] = monthly_values

    return result, monthly, gastos_rest_detalle, gastos_admin_detalle, cost_categories


# ─────────────────────────────────────────────────────────────
# COMPLEMENTARY DATA DETECTION
# ─────────────────────────────────────────────────────────────
def detect_complementary(sheets, cost_categories, monthly, gastos_rest, gastos_admin):
    """Assess what complementary data is available."""
    return {
        "has_cost_detail": len(cost_categories) >= 3,
        "has_centro_costos": "centro_costos" in sheets,
        "has_monthly_egp": len(monthly) >= 2,
        "has_gastos_detalle": len(gastos_rest) >= 2 or len(gastos_admin) >= 2,
        "has_usd_operations": False,  # TODO: detect from PCGE or account names
        "cost_categories": cost_categories,
        "gastos_restaurante_detalle": gastos_rest,
        "gastos_admin_detalle": gastos_admin,
    }


# ─────────────────────────────────────────────────────────────
# SECTOR AUTO-DETECTION
# ─────────────────────────────────────────────────────────────
def parse_esf_banking(ws):
    """Parse banking Balance Sheet using SBS-standard account structure."""
    result = {
        "disponible": {},
        "inversiones": {},
        "colocaciones": {},
        "cartera_alto_riesgo": {},
        "otros_activos": {},
        "obligaciones_publico": {},
        "fondeo_institucional": {},
        "otros_pasivos": {},
        "patrimonio": {},
        "totales": {},
    }

    pairs = []
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, values_only=False):
        cells = [(c.column, c.value) for c in row if c.value is not None]
        for i, (col, val) in enumerate(cells):
            if isinstance(val, str) and len(val.strip()) > 2:
                for j in range(i + 1, min(i + 3, len(cells))):
                    _, next_val = cells[j]
                    if isinstance(next_val, (int, float)):
                        pairs.append((val.strip(), next_val))
                        break

    section = "disponible"
    for label, value in pairs:
        label_lower = fold(label)
        if value is None and not any(
                k in label_lower for k in ["activo", "pasivo", "patrimonio"]):
            continue

        # Section transitions via totals
        if "total disponible" in label_lower:
            result["disponible"]["total_disponible"] = value
            section = "inversiones"
            continue
        elif "total inversiones" in label_lower:
            result["inversiones"]["total_inversiones"] = value
            section = "colocaciones"
            continue
        elif "total activo" in label_lower and "no corriente" not in label_lower:
            result["totales"]["activo"] = value
            continue
        elif "total depositos" in label_lower or "total obligaciones con el publico" in label_lower:
            result["obligaciones_publico"]["total_dep"] = value
            section = "fondeo_institucional"
            continue
        elif "total pasivo" in label_lower and "corriente" not in label_lower:
            result["totales"]["pasivo"] = value
            section = "patrimonio"
            continue
        elif "total patrimonio" in label_lower:
            result["patrimonio"]["total_patrimonio"] = value
            continue
        elif "total pasivo y patrimonio" in label_lower:
            result["totales"]["pasivo_patrimonio"] = value
            continue

        # Map using banking asset map
        key_a = match_account(label, BANKING_ASSET_MAP)
        if key_a:
            result[section][key_a] = value
            continue

        key_p = match_account(label, BANKING_PASIVO_MAP)
        if key_p:
            result[section][key_p] = value

    return result


def parse_egp_banking(ws):
    """Parse banking Income Statement (SBS margin cascade structure)."""
    result = {}
    pairs = []

    # Detect total column (annual/total)
    total_col = None
    for row in ws.iter_rows(min_row=1, max_row=15, values_only=False):
        for c in row:
            if isinstance(c.value, str):
                val_lower = normalize(c.value)
                if "total" in val_lower and any(y in val_lower for y in ["2024", "2025", "2026", "anual"]):
                    total_col = c.column

    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, values_only=False):
        cells = [(c.column, c.value) for c in row if c.value is not None]
        label = None
        value = None
        for col, val in cells:
            if col == 2 and isinstance(val, str):
                label = val.strip()
            if total_col and col == total_col and isinstance(val, (int, float)):
                value = val
            elif not total_col and isinstance(val, (int, float)) and label:
                value = val  # fallback: first numeric after label

        if label and value is not None:
            pairs.append((label, value))

    for label, value in pairs:
        key = match_account(label, BANKING_EGP_MAP)
        if key:
            result[key] = value

    return result


def detect_sector(wb, egp_data):
    """Try to auto-detect the business sector from Excel content."""
    all_text = ""
    for name in wb.sheetnames:
        ws = wb[name]
        for row in ws.iter_rows(min_row=1, max_row=min(30, ws.max_row), values_only=True):
            for cell in row:
                if isinstance(cell, str):
                    all_text += " " + cell.lower()

    if any(k in all_text for k in ["colocaciones", "depositos a plazo", "cartera crediticia",
                                    "morosidad", "sbs", "patrimonio efectivo", "bcrp",
                                    "fondeo", "ratio de capital global", "apr"]):
        return "banking"
    elif any(k in all_text for k in ["food cost", "restaurante", "menajes", "cortesias", "cortesías", "cocina", "chef"]):
        return "restaurants"
    elif any(k in all_text for k in ["obras en curso", "avance de obra", "construccion"]):
        return "construction"
    elif any(k in all_text for k in ["mercaderias", "existencias", "distribu"]):
        if "costo de ventas" in all_text and egp_data.get("gastos_ventas", 0) > 0:
            return "distribution"
        return "retail"
    elif any(k in all_text for k in ["honorarios", "consultoria", "servicio profesional"]):
        return "services"
    elif any(k in all_text for k in ["habitacion", "hospedaje", "turismo"]):
        return "hospitality"
    elif any(k in all_text for k in ["clinica", "paciente", "salud"]):
        return "healthcare"
    elif any(k in all_text for k in ["produccion", "manufactura", "fabrica"]):
        return "manufacturing"

    return "services"  # default fallback


# ─────────────────────────────────────────────────────────────
# DATA QUALITY CHECK
# ─────────────────────────────────────────────────────────────
def check_quality(esf, egp):
    """Validate data consistency."""
    warnings = []
    activo = esf.get("totales", {}).get("activo", 0)
    pp = esf.get("totales", {}).get("pasivo_patrimonio", 0)

    balance_check = abs(activo - pp) < 1.0 if activo and pp else False
    if not balance_check:
        warnings.append(f"Balance no cuadra: Activo={activo:.0f} vs P+P={pp:.0f}")

    # Banking ESF uses "disponible" instead of "activo_corriente"
    is_banking = "disponible" in esf

    if not is_banking:
        # Check preoperativos (commercial sectors only)
        preop = esf.get("activo_corriente", {}).get("gastos_anticipados", 0)
        total_ac = esf.get("activo_corriente", {}).get("total_ac", 1)
        if preop > total_ac * 0.15:
            warnings.append(f"Gastos preoperativos S/{preop:,.0f} en AC ({preop/total_ac*100:.0f}%)")

    # Check patrimonio negativo
    pat = esf.get("patrimonio", {}).get("total_patrimonio", 0)
    if pat < 0:
        warnings.append(f"Patrimonio negativo: S/ {pat:,.0f}")

    # Completeness score
    if is_banking:
        required_fields_banking = ["disponible_total", "colocaciones_netas", "dep_total", "capital_bancario"]
        found = sum(1 for f in required_fields_banking
                    if any(f in v for v in esf.values() if isinstance(v, dict)))
        completeness = found / len(required_fields_banking)
    else:
        required_fields = ["efectivo", "cxp_comerciales", "total_ac", "total_pc"]
        found = sum(1 for f in required_fields if esf.get("activo_corriente", {}).get(f) is not None
                    or esf.get("pasivo_corriente", {}).get(f) is not None)
        completeness = found / len(required_fields)

    # Periods detection (check if there are 2024 columns)
    periods = 1  # default

    return {
        "balance_check": balance_check,
        "completeness": round(completeness, 2),
        "periods_found": periods,
        "warnings": warnings,
    }


# ─────────────────────────────────────────────────────────────
# MAIN: ASSEMBLE data.json
# ─────────────────────────────────────────────────────────────
# Traducción entre los dos nombres que conviven en el flujo: el parser produce
# `esf`/`egp` con nombres cortos, y el motor de ratios lee `balance`/
# `estado_resultados` con nombres largos. El data.json sale con las dos vistas
# para que ninguna etapa tenga que adivinar.
MAPA_BALANCE = {
    "activo_corriente": {"cxc_comerciales": "cuentas_por_cobrar", "mercaderias": "inventarios",
                         "suministros_menajes": "suministros", "total_ac": "total_activo_corriente"},
    "activo_no_corriente": {"depreciacion": "depreciacion_acumulada", "total_anc": "total_activo_no_corriente"},
    "pasivo_corriente": {"cxp_comerciales": "cuentas_por_pagar", "total_pc": "total_pasivo_corriente"},
    "pasivo_no_corriente": {"total_pnc": "total_pasivo_no_corriente"},
    "patrimonio": {"capital": "capital_social", "resultados_acum": "resultados_acumulados",
                   "resultado_ejercicio": "resultado_periodo"},
}
MAPA_ER = {
    "utilidad_bruta": "margen_bruto", "ebit": "margen_operativo",
    "ingresos_financieros": "ing_financieros_total", "dif_cambio": "perdida_diferencia_cambio",
    "otros_ingresos": "otros_ingresos_gestion",
}


def _vista_balance(esf):
    """esf (nombres del parser) → balance (nombres del motor de ratios)."""
    out = {}
    for seccion, cuentas in esf.items():
        if seccion == "totales" or not isinstance(cuentas, dict):
            continue
        mapa = MAPA_BALANCE.get(seccion, {})
        out[seccion] = {mapa.get(k, k): v for k, v in cuentas.items()}
    tot = esf.get("totales", {})
    out["total_activo"] = tot.get("activo")
    pc = (esf.get("pasivo_corriente") or {}).get("total_pc") or 0
    pnc = (esf.get("pasivo_no_corriente") or {}).get("total_pnc") or 0
    out["total_pasivo"] = round(pc + pnc, 2)
    return out


def _vista_er(egp):
    out = {MAPA_ER.get(k, k): v for k, v in egp.items() if isinstance(v, (int, float))}
    # Las líneas que no corresponden a una cuenta conocida se conservan con su
    # propio nombre. Sirven para comparar el plan de cuentas entre ejercicios:
    # una categoría de gasto que aparece de un año al otro no se ve en los
    # subtotales, y sin verla la variación se lee como gasto nuevo cuando puede
    # ser una reclasificación.
    for k, v in (egp.get("_lineas") or {}).items():
        out.setdefault(k, v)
    return out


def extract(excel_path, sector_hint=None):
    """Main extraction pipeline. Multiperiodo: una hoja por ejercicio y estado."""
    wb = openpyxl.load_workbook(excel_path, data_only=True)

    sheets = discover_sheets(wb)
    periodos = sheets.get("_periodos") or []
    por_periodo = sheets.get("_por_periodo") or {"balance": {}, "er": {}}
    print(f"📋 Sheets discovered: { {k: v for k, v in sheets.items() if not k.startswith('_')} }")
    if periodos:
        print(f"🗓️  Periodos: {', '.join(periodos)}")

    if "esf" not in sheets:
        print("⚠️ No ESF sheet found. Looking for BG Analítico...")
        if "bg_analitico" in sheets:
            sheets["esf"] = sheets["bg_analitico"]
        else:
            print("❌ Cannot find balance sheet. Manual extraction needed.")
            return None
    if "egp" not in sheets:
        print("❌ Cannot find income statement. Manual extraction needed.")
        return None

    _egp_raw, _, _, _, _ = parse_egp(wb[sheets["egp"]])
    detected_sector = detect_sector(wb, _egp_raw)
    sector = sector_hint or detected_sector
    print(f"🏢 Sector: {sector} (detected: {detected_sector})")

    banca = sector == "banking"
    p_esf = parse_esf_banking if banca else parse_esf

    # ── vista multiperiodo ──
    balance, estado_resultados = {}, {}
    for p in periodos:
        if p in por_periodo["balance"]:
            balance[p] = _vista_balance(p_esf(wb[por_periodo["balance"][p]]))
        if p in por_periodo["er"]:
            e = parse_egp_banking(wb[por_periodo["er"][p]]) if banca else parse_egp(wb[por_periodo["er"][p]])[0]
            estado_resultados[p] = _vista_er(e)

    # ── vista de periodo único, para las etapas que leen esf/egp ──
    if banca:
        esf = parse_esf_banking(wb[sheets["esf"]])
        egp = parse_egp_banking(wb[sheets["egp"]])
        monthly, gastos_rest, gastos_admin, cost_cats = {}, {}, {}, {}
    else:
        esf = parse_esf(wb[sheets["esf"]])
        egp, monthly, gastos_rest, gastos_admin, cost_cats = parse_egp(wb[sheets["egp"]])
    print(f"✅ ESF parsed: {sum(len(v) for v in esf.values() if isinstance(v, dict))} accounts")
    print(f"✅ EGP parsed: {len(egp)} line items, {len(monthly)} monthly series")

    complementary = detect_complementary(sheets, cost_cats, monthly, gastos_rest, gastos_admin)
    print(f"📊 Complementary: cost_detail={complementary['has_cost_detail']}, "
          f"monthly={complementary['has_monthly_egp']}, "
          f"gastos_detail={complementary['has_gastos_detalle']}")

    quality = check_quality(esf, egp)
    quality["periods_found"] = max(len(periodos), 1)
    print(f"✅ Quality: balance={'OK' if quality['balance_check'] else 'FAIL'}, "
          f"completeness={quality['completeness']:.0%}, periodos={quality['periods_found']}")

    empresa = ""
    for row in wb[sheets["esf"]].iter_rows(min_row=1, max_row=5, values_only=True):
        for cell in row:
            if isinstance(cell, str) and any(x in cell.lower() for x in ("s.a.c", "s.r.l", "e.i.r.l", "s.a.")):
                empresa = cell.strip()
                break

    data = {
        "empresa": empresa,
        "periodo": periodos[-1] if periodos else "",
        "periodos": periodos,
        "moneda": "PEN",
        "sector": sector,
        "balance": balance,
        "estado_resultados": estado_resultados,
        "esf": esf,
        "egp": egp,
        "monthly": monthly,
        "complementary": complementary,
        "data_quality": quality,
        "_encabezados": sheets.get("_encabezados", {}),
        "_meta": {
            "source_file": str(excel_path),
            "sheets_used": {k: v for k, v in sheets.items() if not k.startswith("_")},
            "sector_detected": detected_sector,
            "sector_used": sector,
        }
    }
    return data


def main():
    parser = argparse.ArgumentParser(description="Extract financial data from Excel")
    parser.add_argument("excel_path", help="Path to Excel file")
    parser.add_argument("--sector", default=None, help="Sector hint (auto-detected if not provided)")
    parser.add_argument("--output", default="data.json", help="Output path")

    args = parser.parse_args()

    data = extract(args.excel_path, args.sector)
    if data is None:
        print("❌ Extraction failed.")
        sys.exit(1)

    with open(args.output, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Data extracted: {args.output}")
    print(f"   Empresa: {data['empresa']}")
    print(f"   Accounts: ESF={sum(len(v) for v in data['esf'].values() if isinstance(v, dict))}, "
          f"EGP={len(data['egp'])}")
    print(f"   Warnings: {data['data_quality']['warnings']}")


if __name__ == "__main__":
    main()
