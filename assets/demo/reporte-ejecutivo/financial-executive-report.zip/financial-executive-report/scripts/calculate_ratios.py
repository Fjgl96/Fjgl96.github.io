#!/usr/bin/env python3
"""
Calculadora determinística de ratios financieros con soporte sectorial.
Lee un JSON estandarizado y produce ratios + variaciones + KPIs sectoriales.

Uso:
    python scripts/calculate_ratios.py data.json
    python scripts/calculate_ratios.py data.json --sector restaurants
    python scripts/calculate_ratios.py data.json --sector distribution

Sectores soportados: restaurants, distribution, retail, construction,
                      manufacturing, services, healthcare, hospitality

Output JSON: ver docstring de calculate_all()
"""

import json
import sys
from pathlib import Path


# =============================================================================
# UTILIDADES
# =============================================================================

def safe_div(numerator, denominator, default="N/A"):
    """Safe division that handles zero, None, and negative denominators."""
    if numerator is None or denominator is None:
        return default
    if denominator == 0:
        return default
    return numerator / denominator


def safe_pct(numerator, denominator, default="N/A"):
    """Safe percentage calculation."""
    result = safe_div(numerator, denominator, default)
    if result == default:
        return default
    return round(result * 100, 1)


def safe_round(value, decimals=2):
    """Round if numeric, pass through otherwise."""
    if isinstance(value, (int, float)):
        return round(value, decimals)
    return value


def variation(current, previous):
    """Calculate absolute and percentage variation."""
    if current is None or previous is None:
        return {"monto": "N/A", "pct": "N/A"}
    monto = current - previous
    if previous == 0:
        pct = "N/A" if monto == 0 else "Nuevo"
    else:
        pct = round((monto / abs(previous)) * 100, 1)
    return {"monto": round(monto, 0), "pct": pct}


def get_bg_value(balance, *keys):
    """Navigate nested balance dict to get a value."""
    current = balance
    for key in keys:
        if isinstance(current, dict):
            current = current.get(key)
        else:
            return None
    return current if isinstance(current, (int, float)) else None


def evaluate_vs_benchmark(value, thresholds, labels=None):
    """
    Evaluate a value against benchmark thresholds.
    thresholds: dict with 'riesgo', 'adecuado', 'solido' ranges or (low, high) tuple.
    Returns: {"valor": value, "evaluacion": "riesgo"|"adecuado"|"solido", "color": hex}
    """
    if not isinstance(value, (int, float)):
        return {"valor": value, "evaluacion": "N/A", "color": "F2F4F6"}

    labels = labels or {"bajo": "riesgo", "medio": "adecuado", "alto": "solido"}

    if isinstance(thresholds, dict):
        low = thresholds.get('riesgo_max', thresholds.get('low'))
        high = thresholds.get('solido_min', thresholds.get('high'))
    elif isinstance(thresholds, (list, tuple)) and len(thresholds) == 2:
        low, high = thresholds
    else:
        return {"valor": value, "evaluacion": "N/A", "color": "F2F4F6"}

    if value < low:
        return {"valor": value, "evaluacion": "riesgo", "color": "F8D7DA"}
    elif value > high:
        return {"valor": value, "evaluacion": "solido", "color": "D1E7DD"}
    else:
        return {"valor": value, "evaluacion": "adecuado", "color": "FFF3CD"}


# =============================================================================
# RATIOS ESTÁNDAR (todos los sectores)
# =============================================================================

def calculate_liquidez(bg):
    """Ratios de liquidez."""
    ac = get_bg_value(bg, 'activo_corriente', 'total_activo_corriente') or 0
    pc = get_bg_value(bg, 'pasivo_corriente', 'total_pasivo_corriente') or 0
    inv = get_bg_value(bg, 'activo_corriente', 'inventarios') or 0
    suministros = get_bg_value(bg, 'activo_corriente', 'suministros') or 0
    efectivo = get_bg_value(bg, 'activo_corriente', 'efectivo') or 0

    return {
        "ratio_corriente": safe_round(safe_div(ac, pc)),
        "prueba_acida": safe_round(safe_div(ac - inv - suministros, pc)),
        "capital_trabajo": round(ac - pc, 0),
        "ratio_efectivo": safe_round(safe_div(efectivo, pc)),
    }


def calculate_solvencia(bg):
    """Ratios de solvencia / endeudamiento."""
    total_pasivo = get_bg_value(bg, 'total_pasivo') or 0
    total_patrimonio = get_bg_value(bg, 'patrimonio', 'total_patrimonio')
    total_activo = get_bg_value(bg, 'total_activo') or 0
    pc = get_bg_value(bg, 'pasivo_corriente', 'total_pasivo_corriente') or 0

    if total_patrimonio is not None and total_patrimonio <= 0:
        de = "N/A (Patrimonio ≤ 0)"
    else:
        de = safe_round(safe_div(total_pasivo, total_patrimonio))

    return {
        "pasivo_patrimonio": de,
        "endeudamiento": safe_round(safe_div(total_pasivo, total_activo)),
        "concentracion_cp": safe_pct(pc, total_pasivo),
        "concentracion_lp": safe_pct(total_pasivo - pc, total_pasivo),
    }


def calculate_rentabilidad(bg, er):
    """Ratios de rentabilidad."""
    ventas = er.get('ventas_netas') or 0
    mg_bruto = er.get('margen_bruto') or 0
    mg_operativo = er.get('margen_operativo') or 0
    resultado = er.get('resultado_ejercicio') or 0
    total_patrimonio = get_bg_value(bg, 'patrimonio', 'total_patrimonio')
    total_activo = get_bg_value(bg, 'total_activo') or 0

    if total_patrimonio is not None and total_patrimonio <= 0:
        roe = "N/A (Patrimonio ≤ 0)"
    else:
        roe = safe_pct(resultado, total_patrimonio)

    depreciacion = get_bg_value(bg, 'activo_no_corriente', 'depreciacion_acumulada')
    ebitda = "N/D"
    margen_ebitda = "N/D"

    gastos_financieros = er.get('gastos_financieros', 0)
    if gastos_financieros and gastos_financieros != 0:
        cobertura = safe_round(safe_div(mg_operativo, abs(gastos_financieros)))
    else:
        cobertura = "N/A (Sin gastos financieros)"

    return {
        "margen_bruto_pct": safe_pct(mg_bruto, ventas),
        "margen_operativo_pct": safe_pct(mg_operativo, ventas),
        "margen_neto_pct": safe_pct(resultado, ventas),
        "roe": roe,
        "roa": safe_pct(resultado, total_activo),
        "ebitda": ebitda,
        "margen_ebitda": margen_ebitda,
        "cobertura_intereses": cobertura,
    }


def calculate_eficiencia(bg, er, bg_anterior=None):
    """Ratios de eficiencia / actividad y CCE."""
    ventas = abs(er.get('ventas_netas', 0) or 0)
    costo = abs(er.get('costo_ventas', 0) or 0)

    inv = get_bg_value(bg, 'activo_corriente', 'inventarios') or 0
    cxc = get_bg_value(bg, 'activo_corriente', 'cuentas_por_cobrar') or 0
    cxp = get_bg_value(bg, 'pasivo_corriente', 'cuentas_por_pagar') or 0

    if bg_anterior:
        inv_ant = get_bg_value(bg_anterior, 'activo_corriente', 'inventarios') or inv
        cxc_ant = get_bg_value(bg_anterior, 'activo_corriente', 'cuentas_por_cobrar') or cxc
        cxp_ant = get_bg_value(bg_anterior, 'pasivo_corriente', 'cuentas_por_pagar') or cxp
        inv_prom = (inv + inv_ant) / 2
        cxc_prom = (cxc + cxc_ant) / 2
        cxp_prom = (cxp + cxp_ant) / 2
    else:
        inv_prom = inv
        cxc_prom = cxc
        cxp_prom = cxp

    rot_inv = safe_div(costo, inv_prom)
    rot_cxc = safe_div(ventas, cxc_prom)
    rot_cxp = safe_div(costo, cxp_prom)

    edad_inv = safe_div(360, rot_inv) if isinstance(rot_inv, (int, float)) else "N/A"
    periodo_cobro = safe_div(360, rot_cxc) if isinstance(rot_cxc, (int, float)) else "N/A"
    periodo_pago = safe_div(360, rot_cxp) if isinstance(rot_cxp, (int, float)) else "N/A"

    if all(isinstance(v, (int, float)) for v in [edad_inv, periodo_cobro, periodo_pago]):
        cce = round(edad_inv + periodo_cobro - periodo_pago, 0)
    else:
        cce = "N/A"

    recursos_cce = round(inv + cxc - cxp, 0)

    return {
        "rotacion_inventarios": safe_round(rot_inv),
        "edad_inventario_dias": safe_round(edad_inv, 0) if isinstance(edad_inv, (int, float)) else edad_inv,
        "rotacion_cxc": safe_round(rot_cxc),
        "periodo_cobro_dias": safe_round(periodo_cobro, 0) if isinstance(periodo_cobro, (int, float)) else periodo_cobro,
        "rotacion_cxp": safe_round(rot_cxp),
        "periodo_pago_dias": safe_round(periodo_pago, 0) if isinstance(periodo_pago, (int, float)) else periodo_pago,
        "cce_dias": cce,
        "recursos_cce": recursos_cce,
    }


def calculate_dupont(bg, er):
    """Análisis DuPont del ROE."""
    ventas = er.get('ventas_netas') or 0
    resultado = er.get('resultado_ejercicio') or 0
    total_activo = get_bg_value(bg, 'total_activo') or 0
    total_patrimonio = get_bg_value(bg, 'patrimonio', 'total_patrimonio')

    if total_patrimonio is None or total_patrimonio <= 0:
        return {"dupont": "N/A (Patrimonio ≤ 0)"}

    margen_neto = safe_div(resultado, ventas)
    rotacion_activos = safe_div(ventas, total_activo)
    multiplicador_capital = safe_div(total_activo, total_patrimonio)

    if all(isinstance(v, (int, float)) for v in [margen_neto, rotacion_activos, multiplicador_capital]):
        roe_dupont = round(margen_neto * rotacion_activos * multiplicador_capital * 100, 1)
    else:
        roe_dupont = "N/A"

    return {
        "margen_neto": safe_pct(resultado, ventas),
        "rotacion_activos": safe_round(rotacion_activos),
        "multiplicador_capital": safe_round(multiplicador_capital),
        "roe_dupont": roe_dupont,
    }


def calculate_ebitda_multiperiodo(balances, ers, periodos):
    """Approximate EBITDA using depreciation delta between periods."""
    results = {}
    sorted_periodos = sorted(periodos)

    for i, periodo in enumerate(sorted_periodos):
        bg = balances.get(periodo, {})
        er = ers.get(periodo, {})
        mg_op = er.get('margen_operativo', 0) or 0
        dep_actual = get_bg_value(bg, 'activo_no_corriente', 'depreciacion_acumulada')

        if i > 0 and dep_actual is not None:
            dep_anterior = get_bg_value(
                balances.get(sorted_periodos[i-1], {}),
                'activo_no_corriente', 'depreciacion_acumulada'
            )
            if dep_anterior is not None:
                dep_periodo = abs(dep_actual) - abs(dep_anterior)
                ebitda = mg_op + abs(dep_periodo)
                ventas = er.get('ventas_netas', 0) or 0
                results[periodo] = {
                    "ebitda": round(ebitda, 0),
                    "depreciacion_periodo": round(abs(dep_periodo), 0),
                    "margen_ebitda": safe_pct(ebitda, ventas),
                }
                continue

        results[periodo] = {
            "ebitda": "N/D",
            "depreciacion_periodo": "N/D",
            "margen_ebitda": "N/D",
        }

    return results


def calculate_punto_equilibrio(er):
    """Punto de equilibrio operativo."""
    ventas = er.get('ventas_netas', 0) or 0
    cv = abs(er.get('costo_ventas', 0) or 0)
    gastos_adm = abs(er.get('gastos_administracion', 0) or 0)
    gastos_vta = abs(er.get('gastos_ventas', 0) or 0)
    gastos_dist = abs(er.get('gastos_distribucion', 0) or 0)

    gastos_fijos = gastos_adm + gastos_vta + gastos_dist
    mc_ratio = safe_div(ventas - cv, ventas)

    if isinstance(mc_ratio, (int, float)) and mc_ratio > 0:
        pe = round(gastos_fijos / mc_ratio, 0)
        cobertura_pe = safe_pct(ventas, pe) if pe > 0 else "N/A"
    else:
        pe = "N/A"
        cobertura_pe = "N/A"

    return {
        "punto_equilibrio": pe,
        "gastos_fijos": round(gastos_fijos, 0),
        "margen_contribucion_pct": safe_pct(ventas - cv, ventas),
        "cobertura_pe_pct": cobertura_pe,
    }


# =============================================================================
# KPIs SECTORIALES
# =============================================================================

def kpis_restaurants(bg, er, extra_data=None):
    """KPIs específicos para restaurantes / food service."""
    ventas = er.get('ventas_netas', 0) or 0
    cv = abs(er.get('costo_ventas', 0) or 0)
    extra = extra_data or {}

    # Food cost
    food_cost_pct = safe_pct(cv, ventas)

    # Labor cost (personal total / ventas)
    personal_total = abs(er.get('gastos_personal', 0) or 0)
    if personal_total == 0:
        personal_adm = abs(extra.get('personal_administracion', 0) or 0)
        personal_op = abs(extra.get('personal_operativo', 0) or 0)
        personal_total = personal_adm + personal_op
    labor_cost_pct = safe_pct(personal_total, ventas)

    # Prime cost
    if isinstance(food_cost_pct, (int, float)) and isinstance(labor_cost_pct, (int, float)):
        prime_cost_pct = round(food_cost_pct + labor_cost_pct, 1)
    else:
        prime_cost_pct = "N/A"

    # Occupancy cost
    alquiler = abs(extra.get('alquiler', 0) or er.get('alquiler', 0) or 0)
    servicios_local = abs(extra.get('servicios_basicos', 0) or 0)
    occupancy_pct = safe_pct(alquiler + servicios_local, ventas)

    # Comisiones TC
    comisiones_tc = abs(extra.get('comisiones_tarjetas', 0) or 0)
    comisiones_tc_pct = safe_pct(comisiones_tc, ventas)

    # Recargo al consumo (si aplica)
    recargo = extra.get('recargo_consumo', 0) or 0

    result = {
        "food_cost_pct": food_cost_pct,
        "labor_cost_pct": labor_cost_pct,
        "prime_cost_pct": prime_cost_pct,
        "occupancy_cost_pct": occupancy_pct,
        "comisiones_tc_pct": comisiones_tc_pct,
        "recargo_consumo": round(recargo, 0) if recargo else 0,
    }

    # Food cost por categoría si hay detalle
    categorias = extra.get('costo_por_categoria', {})
    if categorias:
        result["food_cost_detalle"] = {}
        for cat, monto in categorias.items():
            result["food_cost_detalle"][cat] = {
                "monto": round(abs(monto), 0),
                "pct_ventas": safe_pct(abs(monto), ventas),
            }

    # Benchmarks
    result["benchmarks"] = {
        "food_cost": {"fine_dining": (32, 38), "casual": (35, 42), "fast_food": (28, 35)},
        "prime_cost": {"fine_dining": (60, 68), "casual": (62, 70), "fast_food": (55, 65)},
        "occupancy": (8, 12),
        "comisiones_tc": (3.25, 4.5),
    }

    return result


def kpis_distribution(bg, er, extra_data=None):
    """KPIs específicos para distribución / wholesale."""
    ventas = abs(er.get('ventas_netas', 0) or 0)
    cv = abs(er.get('costo_ventas', 0) or 0)
    extra = extra_data or {}

    cxc = get_bg_value(bg, 'activo_corriente', 'cuentas_por_cobrar') or 0
    inv = get_bg_value(bg, 'activo_corriente', 'inventarios') or 0
    efectivo = get_bg_value(bg, 'activo_corriente', 'efectivo') or 0
    total_activo = get_bg_value(bg, 'total_activo') or 0

    gastos_op = abs(er.get('gastos_administracion', 0) or 0) + \
                abs(er.get('gastos_ventas', 0) or 0)

    # DSO
    dso = safe_round(safe_div(cxc, safe_div(ventas, 360)))

    # Rotación inventarios
    rot_inv = safe_round(safe_div(cv, inv))
    edad_inv = safe_round(safe_div(360, rot_inv), 0) if isinstance(rot_inv, (int, float)) else "N/A"

    # Días de efectivo
    gasto_diario = safe_div(cv + gastos_op, 30)
    dias_efectivo = safe_round(safe_div(efectivo, gasto_diario), 0) if isinstance(gasto_diario, (int, float)) else "N/A"

    # Concentración de CxC en activo
    cxc_pct_activo = safe_pct(cxc, total_activo)

    # Concentración de clientes (requiere data extra)
    concentracion_top10 = extra.get('concentracion_top10_pct', "N/D")

    # Spread cambiario (si hay data)
    activos_usd = extra.get('activos_usd', 0) or 0
    pasivos_usd = extra.get('pasivos_usd', 0) or 0
    tc = extra.get('tipo_cambio', 0) or 0
    if tc > 0 and (activos_usd > 0 or pasivos_usd > 0):
        exposicion_neta_usd = pasivos_usd - activos_usd
        exposicion_neta_pen = round(exposicion_neta_usd * tc, 0)
        spread_fx = {
            "activos_usd": round(activos_usd, 0),
            "pasivos_usd": round(pasivos_usd, 0),
            "exposicion_neta_usd": round(exposicion_neta_usd, 0),
            "exposicion_neta_pen": exposicion_neta_pen,
            "tipo_cambio": tc,
        }
    else:
        spread_fx = None

    # Pérdida por diferencia de cambio
    perdida_tc = abs(er.get('perdida_diferencia_cambio', 0) or extra.get('perdida_tc', 0) or 0)
    perdida_tc_pct_ventas = safe_pct(perdida_tc, ventas)

    result = {
        "dso_dias": dso,
        "rotacion_inventarios": rot_inv,
        "edad_inventario_dias": edad_inv,
        "dias_efectivo": dias_efectivo,
        "cxc_pct_activo": cxc_pct_activo,
        "concentracion_top10_pct": concentracion_top10,
        "perdida_tc": round(perdida_tc, 0),
        "perdida_tc_pct_ventas": perdida_tc_pct_ventas,
    }

    if spread_fx:
        result["spread_cambiario"] = spread_fx

    # Benchmarks
    result["benchmarks"] = {
        "dso": {"normal": (30, 60), "riesgo": 90},
        "rotacion_inv": {"eficiente": 8, "normal": (4, 8), "lento": 4},
        "concentracion": {"diversificado": 30, "concentrado": 50, "critico": 70},
        "dias_efectivo": {"holgura": 30, "normal": (15, 30), "presion": 15},
        "cxc_pct_activo": {"alerta": 40},
    }

    return result


def kpis_retail(bg, er, extra_data=None):
    """KPIs específicos para retail / comercio."""
    ventas = abs(er.get('ventas_netas', 0) or 0)
    cv = abs(er.get('costo_ventas', 0) or 0)
    inv = get_bg_value(bg, 'activo_corriente', 'inventarios') or 0
    extra = extra_data or {}

    # Ventas por m2 (si hay data)
    m2 = extra.get('metros_cuadrados', 0) or 0
    ventas_m2 = safe_round(safe_div(ventas, m2)) if m2 > 0 else "N/D"

    # GMROI (Gross Margin Return on Investment in Inventory)
    mg_bruto = er.get('margen_bruto', 0) or 0
    gmroi = safe_round(safe_div(mg_bruto, inv))

    # Shrinkage / merma
    merma = abs(extra.get('merma', 0) or 0)
    merma_pct = safe_pct(merma, ventas)

    return {
        "ventas_por_m2": ventas_m2,
        "gmroi": gmroi,
        "merma_pct": merma_pct,
        "rotacion_inventarios": safe_round(safe_div(cv, inv)),
        "benchmarks": {
            "gmroi": {"bajo": 1.5, "normal": (1.5, 3.0), "alto": 3.0},
            "merma": {"controlado": 1.0, "alerta": 2.0},
        },
    }


def kpis_construction(bg, er, extra_data=None):
    """KPIs específicos para construcción / inmobiliario."""
    ventas = abs(er.get('ventas_netas', 0) or 0)
    extra = extra_data or {}

    obras_en_curso = abs(extra.get('obras_en_curso', 0) or 0)
    backlog = extra.get('backlog', 0) or 0

    return {
        "obras_en_curso": round(obras_en_curso, 0),
        "backlog": round(backlog, 0),
        "backlog_meses": safe_round(safe_div(backlog, safe_div(ventas, 12))),
        "benchmarks": {
            "backlog_meses": {"bajo": 6, "normal": (6, 18), "alto": 18},
        },
    }


def kpis_banking(bg, er, extra_data=None):
    """
    KPIs específicos para Banca y Seguros (SBS / BCRP).

    Ratios regulatorios y de gestión bancaria:
      - Margen Financiero Bruto
      - Ratio de Eficiencia (Cost-to-Income)
      - Prima por Riesgo
      - CAR (Cartera de Alto Riesgo)
      - Cobertura CAR
      - RCG (Ratio de Capital Global)
      - Liquidez MN / ME
      - Colocaciones / Depósitos
      - ROE y ROA con promedios si hay datos del periodo anterior
    """
    extra = extra_data or {}

    # ── Ingresos y gastos financieros ────────────────────────────────────────
    ing_fin = er.get('ing_financieros_total', 0) or 0
    gasto_fin = abs(er.get('gastos_financieros_total', 0) or 0)
    mg_fin_bruto = er.get('margen_fin_bruto', ing_fin - gasto_fin) or (ing_fin - gasto_fin)

    # ── Provisiones ─────────────────────────────────────────────────────────
    gasto_prov = abs(er.get('gasto_provisiones', 0) or 0)
    mg_fin_neto = er.get('margen_fin_neto', mg_fin_bruto - gasto_prov) or (mg_fin_bruto - gasto_prov)

    # ── Ingresos por servicios netos y ROF ───────────────────────────────────
    ing_serv_netos = er.get('ing_serv_fin_netos', 0) or 0
    rof = er.get('rof', 0) or 0

    # ── Resultado operativo bruto (denominador del ratio de eficiencia) ──────
    resultado_op_bruto = mg_fin_bruto + ing_serv_netos + rof

    # ── Gastos administrativos ───────────────────────────────────────────────
    gastos_admin = abs(er.get('gastos_admin', 0) or 0)

    # ── Resultado / Utilidad Neta ─────────────────────────────────────────────
    utilidad_neta = er.get('utilidad_neta_bancaria', 0) or 0

    # ── Balance — colocaciones ───────────────────────────────────────────────
    colocaciones_brutas = (
        get_bg_value(bg, 'colocaciones', 'colocaciones_brutas') or
        extra.get('colocaciones_brutas', 0) or 0
    )
    provisiones_credito = abs(
        get_bg_value(bg, 'colocaciones', 'provisiones_credito') or
        extra.get('provisiones', 0) or 0
    )

    # Cartera alto riesgo (CAR) components
    cart_vencida = abs(get_bg_value(bg, 'cartera_alto_riesgo', 'cartera_vencida') or
                       extra.get('cartera_vencida', 0) or 0)
    cart_judicial = abs(get_bg_value(bg, 'cartera_alto_riesgo', 'cartera_judicial') or
                        extra.get('cartera_judicial', 0) or 0)
    cart_refinanc = abs(get_bg_value(bg, 'cartera_alto_riesgo', 'cartera_refinanciada') or
                        extra.get('cartera_refinanciada', 0) or 0)
    cart_reestruc = abs(get_bg_value(bg, 'cartera_alto_riesgo', 'cartera_reestructurada') or
                        extra.get('cartera_reestructurada', 0) or 0)
    cartera_alto_riesgo = cart_vencida + cart_judicial + cart_refinanc + cart_reestruc

    # ── Balance — depósitos ──────────────────────────────────────────────────
    total_depositos = (
        get_bg_value(bg, 'obligaciones_publico', 'total_dep') or
        extra.get('total_depositos', 0) or 0
    )

    # ── Balance — patrimonio y activos ────────────────────────────────────────
    total_patrimonio = (
        get_bg_value(bg, 'patrimonio', 'total_patrimonio') or
        extra.get('patrimonio', 0) or 0
    )
    patrimonio_efectivo = (
        get_bg_value(bg, 'patrimonio', 'patrimonio_efectivo') or
        extra.get('patrimonio_efectivo', 0) or 0
    )
    total_activo = (
        get_bg_value(bg, 'totales', 'activo') or
        extra.get('total_activo', 0) or 0
    )

    # APR (activos ponderados por riesgo)
    apr = extra.get('apr', 0) or er.get('apr', 0) or 0

    # Liquidez MN / ME
    act_liq_mn = extra.get('activos_liquidos_mn', 0) or 0
    pas_cp_mn = extra.get('pasivos_cp_mn', 0) or 0
    act_liq_me = extra.get('activos_liquidos_me', 0) or 0
    pas_cp_me = extra.get('pasivos_cp_me', 0) or 0

    # ── Promedios (si hay datos del periodo anterior) ────────────────────────
    pat_ant = extra.get('patrimonio_anterior', 0) or total_patrimonio
    activo_ant = extra.get('activo_anterior', 0) or total_activo
    col_ant = extra.get('colocaciones_brutas_anterior', 0) or colocaciones_brutas

    pat_prom = (total_patrimonio + pat_ant) / 2 if pat_ant else total_patrimonio
    activo_prom = (total_activo + activo_ant) / 2 if activo_ant else total_activo
    col_prom = (colocaciones_brutas + col_ant) / 2 if col_ant else colocaciones_brutas

    # ── Cálculo de ratios ────────────────────────────────────────────────────

    # Margen Financiero Bruto %
    mg_fin_bruto_pct = safe_pct(mg_fin_bruto, ing_fin)

    # Ratio de Eficiencia (Cost-to-Income) — menor es mejor
    ratio_eficiencia = safe_pct(gastos_admin, resultado_op_bruto) if resultado_op_bruto != 0 else "N/A"

    # Prima por Riesgo = Gasto Provisiones / Coloc Brutas Promedio × 100
    prima_riesgo = safe_pct(gasto_prov, col_prom)

    # CAR = Cartera Alto Riesgo / Colocaciones Brutas × 100
    car_pct = safe_pct(cartera_alto_riesgo, colocaciones_brutas)

    # Cobertura CAR = Provisiones / Cartera Alto Riesgo × 100
    cobertura_car = safe_pct(provisiones_credito, cartera_alto_riesgo) if cartera_alto_riesgo > 0 else "N/A"

    # RCG = Patrimonio Efectivo / APR × 100
    rcg = safe_pct(patrimonio_efectivo, apr) if apr > 0 else "N/D (sin APR)"

    # Liquidez MN / ME
    liquidez_mn = safe_pct(act_liq_mn, pas_cp_mn) if pas_cp_mn > 0 else "N/D"
    liquidez_me = safe_pct(act_liq_me, pas_cp_me) if pas_cp_me > 0 else "N/D"

    # Colocaciones / Depósitos
    col_dep = safe_pct(colocaciones_brutas, total_depositos) if total_depositos > 0 else "N/A"

    # ROE y ROA con promedios
    roe = safe_pct(utilidad_neta, pat_prom) if pat_prom > 0 else "N/A (Patrimonio ≤ 0)"
    roa = safe_pct(utilidad_neta, activo_prom) if activo_prom > 0 else "N/A"

    result = {
        # Rentabilidad
        "roe_prom": roe,
        "roa_prom": roa,
        # Margen financiero
        "ing_financieros": round(ing_fin, 0),
        "gastos_financieros": round(gasto_fin, 0),
        "margen_fin_bruto": round(mg_fin_bruto, 0),
        "margen_fin_bruto_pct": mg_fin_bruto_pct,
        "gasto_provisiones": round(gasto_prov, 0),
        "margen_fin_neto": round(mg_fin_neto, 0),
        # Eficiencia operativa
        "gastos_admin": round(gastos_admin, 0),
        "ratio_eficiencia_pct": ratio_eficiencia,
        # Calidad de cartera
        "colocaciones_brutas": round(colocaciones_brutas, 0),
        "cartera_alto_riesgo": round(cartera_alto_riesgo, 0),
        "car_pct": car_pct,
        "provisiones": round(provisiones_credito, 0),
        "cobertura_car_pct": cobertura_car,
        "prima_riesgo_pct": prima_riesgo,
        # Capitalización
        "patrimonio_efectivo": round(patrimonio_efectivo, 0),
        "apr": round(apr, 0),
        "rcg_pct": rcg,
        # Liquidez regulatoria
        "liquidez_mn_pct": liquidez_mn,
        "liquidez_me_pct": liquidez_me,
        # Estructura de financiamiento
        "total_depositos": round(total_depositos, 0),
        "col_dep_pct": col_dep,
        # Benchmarks (SBS / sistema bancario Perú)
        "benchmarks": {
            "roe": {"bajo": 10, "normal": (10, 18), "solido": 18},
            "roa": {"bajo": 1.0, "normal": (1.0, 2.0), "solido": 2.0},
            "mg_fin_bruto_pct": {"bajo": 60, "normal": (60, 72), "solido": 72},
            "ratio_eficiencia": {"eficiente": 36, "normal": (36, 42), "ineficiente": 42},
            "car": {"bueno": 5.0, "moderado": (5.0, 7.0), "alto": 7.0},
            "cobertura_car": {"insuficiente": 90, "adecuado": (90, 110), "holgado": 110},
            "rcg": {"ajustado": 13, "adecuado": (13, 17), "holgado": 17, "minimo_sbs": 10},
            "prima_riesgo": {"bajo": 2.0, "normal": (2.0, 3.5), "alto": 3.5},
            "liquidez_mn": {"minimo_sbs": 8, "ajustado": (8, 15), "adecuado": (15, 30), "holgado": 30},
            "liquidez_me": {"minimo_sbs": 20, "ajustado": (20, 35), "adecuado": (35, 55), "holgado": 55},
            "col_dep": {"conservador": 90, "normal": (90, 110), "agresivo": 110},
        },
    }

    return result


SECTOR_KPI_FUNCTIONS = {
    "restaurants": kpis_restaurants,
    "distribution": kpis_distribution,
    "retail": kpis_retail,
    "construction": kpis_construction,
    "banking": kpis_banking,
    # manufacturing, services, healthcare, hospitality: add as needed
}


# =============================================================================
# ANÁLISIS VERTICAL Y KPIs RESUMEN
# =============================================================================

def analisis_vertical(bg, er):
    """Análisis vertical: cada partida como % del total correspondiente."""
    total_activo = get_bg_value(bg, 'total_activo') or 0
    ventas = er.get('ventas_netas', 0) or 0

    vertical = {"balance": {}, "estado_resultados": {}}

    if total_activo > 0:
        ac = get_bg_value(bg, 'activo_corriente', 'total_activo_corriente') or 0
        anc = get_bg_value(bg, 'activo_no_corriente', 'total_activo_no_corriente') or 0
        pc = get_bg_value(bg, 'pasivo_corriente', 'total_pasivo_corriente') or 0
        pnc = get_bg_value(bg, 'pasivo_no_corriente', 'total_pasivo_no_corriente') or 0
        pat = get_bg_value(bg, 'patrimonio', 'total_patrimonio') or 0

        vertical["balance"] = {
            "activo_corriente_pct": round(ac / total_activo * 100, 1),
            "activo_no_corriente_pct": round(anc / total_activo * 100, 1),
            "pasivo_corriente_pct": round(pc / total_activo * 100, 1),
            "pasivo_no_corriente_pct": round(pnc / total_activo * 100, 1),
            "patrimonio_pct": round(pat / total_activo * 100, 1),
        }

        # Detalle de AC
        efectivo = get_bg_value(bg, 'activo_corriente', 'efectivo') or 0
        cxc = get_bg_value(bg, 'activo_corriente', 'cuentas_por_cobrar') or 0
        inv = get_bg_value(bg, 'activo_corriente', 'inventarios') or 0
        vertical["balance"]["detalle_ac"] = {
            "efectivo_pct": round(efectivo / total_activo * 100, 1),
            "cxc_pct": round(cxc / total_activo * 100, 1),
            "inventarios_pct": round(inv / total_activo * 100, 1),
        }

    if ventas > 0:
        vertical["estado_resultados"] = {
            "costo_ventas_pct": safe_pct(abs(er.get('costo_ventas', 0) or 0), ventas),
            "margen_bruto_pct": safe_pct(er.get('margen_bruto', 0), ventas),
            "gastos_operativos_pct": safe_pct(
                abs(er.get('gastos_administracion', 0) or 0) +
                abs(er.get('gastos_ventas', 0) or 0) +
                abs(er.get('gastos_distribucion', 0) or 0),
                ventas
            ),
            "margen_operativo_pct": safe_pct(er.get('margen_operativo', 0), ventas),
            "margen_neto_pct": safe_pct(er.get('resultado_ejercicio', 0), ventas),
        }

    return vertical


def generate_kpis(ratios_ultimo, er_ultimo, moneda):
    """Generate summary KPIs for the executive summary slide."""
    er = er_ultimo
    r = ratios_ultimo

    return {
        "ventas_netas": er.get('ventas_netas', 0),
        "resultado_neto": er.get('resultado_ejercicio', 0),
        "margen_bruto_pct": r.get('rentabilidad', {}).get('margen_bruto_pct', 'N/A'),
        "margen_neto_pct": r.get('rentabilidad', {}).get('margen_neto_pct', 'N/A'),
        "roe": r.get('rentabilidad', {}).get('roe', 'N/A'),
        "roa": r.get('rentabilidad', {}).get('roa', 'N/A'),
        "ratio_corriente": r.get('liquidez', {}).get('ratio_corriente', 'N/A'),
        "endeudamiento_de": r.get('solvencia', {}).get('pasivo_patrimonio', 'N/A'),
        "cce_dias": r.get('eficiencia', {}).get('cce_dias', 'N/A'),
        "moneda": moneda,
    }


def generate_alertas(ratios, bg, er, sector=None, country_config=None, kpis_sector=None):
    """Generate automatic alerts based on ratios and thresholds."""
    alertas = []
    r = ratios

    # Patrimonio negativo
    pat = get_bg_value(bg, 'patrimonio', 'total_patrimonio')
    capital = get_bg_value(bg, 'patrimonio', 'capital_social')
    if pat is not None and capital is not None and capital > 0:
        pat_pct_capital = pat / capital * 100
        if pat_pct_capital < 50:
            alertas.append({
                "tipo": "legal",
                "severidad": "critico",
                "mensaje": f"Patrimonio ({pat_pct_capital:.1f}% del capital) por debajo del 50%. Causal de disolución.",
                "referencia": "Art. 407 LGS" if (country_config or {}).get('pais') == 'peru' else "",
            })

    # Liquidez
    rc = r.get('liquidez', {}).get('ratio_corriente')
    if isinstance(rc, (int, float)) and rc < 0.8:
        alertas.append({
            "tipo": "liquidez",
            "severidad": "alto",
            "mensaje": f"Ratio corriente de {rc}x indica presión de liquidez.",
        })

    # Endeudamiento
    de = r.get('solvencia', {}).get('pasivo_patrimonio')
    if isinstance(de, (int, float)) and de > 5:
        alertas.append({
            "tipo": "solvencia",
            "severidad": "alto",
            "mensaje": f"D/E de {de}x indica apalancamiento excesivo.",
        })

    # Margen operativo negativo
    mo = r.get('rentabilidad', {}).get('margen_operativo_pct')
    if isinstance(mo, (int, float)) and mo < 0:
        alertas.append({
            "tipo": "rentabilidad",
            "severidad": "critico",
            "mensaje": f"Margen operativo negativo ({mo}%). La operación genera pérdidas antes de financieros.",
        })

    # ── Alertas específicas del sector bancario ──────────────────────────────
    if sector == "banking":
        ks = kpis_sector or {}

        rcg = ks.get('rcg_pct')
        if isinstance(rcg, (int, float)):
            if rcg < 10:
                alertas.append({
                    "tipo": "regulatorio",
                    "severidad": "critico",
                    "mensaje": f"RCG de {rcg:.1f}% por debajo del mínimo SBS (10%). Incumplimiento regulatorio.",
                })
            elif rcg < 12:
                alertas.append({
                    "tipo": "regulatorio",
                    "severidad": "alto",
                    "mensaje": f"RCG de {rcg:.1f}% cerca del mínimo regulatorio. Evaluar necesidad de capitalización.",
                })

        car = ks.get('car_pct')
        if isinstance(car, (int, float)) and car > 8:
            alertas.append({
                "tipo": "calidad_cartera",
                "severidad": "alto",
                "mensaje": f"CAR de {car:.1f}% indica deterioro significativo. Revisar políticas de originación.",
            })

        cob = ks.get('cobertura_car_pct')
        if isinstance(cob, (int, float)) and cob < 85:
            alertas.append({
                "tipo": "calidad_cartera",
                "severidad": "alto",
                "mensaje": f"Cobertura CAR de {cob:.1f}%: provisiones insuficientes. Riesgo de requerimiento SBS.",
            })

        ef = ks.get('ratio_eficiencia_pct')
        if isinstance(ef, (int, float)) and ef > 45:
            alertas.append({
                "tipo": "eficiencia",
                "severidad": "medio",
                "mensaje": f"Ratio de eficiencia de {ef:.1f}%: gastos admin presionan rentabilidad (benchmark <42%).",
            })

    return alertas


# =============================================================================
# ORQUESTADOR PRINCIPAL
# =============================================================================

def calculate_all(data: dict) -> dict:
    """
    Main calculation function.

    Input JSON:
    {
      "periodos": ["2024", "2025"],
      "moneda": "PEN",
      "sector": "restaurants",           # optional
      "extra_data": { ... },             # optional, sector-specific
      "balance": { "2025": { ... } },
      "estado_resultados": { "2025": { ... } }
    }

    Output JSON:
    {
      "ratios": { "2025": { "liquidez": {...}, "solvencia": {...}, ... } },
      "variaciones": { "2025_vs_2024": { ... } },
      "analisis_vertical": { "2025": { ... } },
      "punto_equilibrio": { "2025": { ... } },
      "kpis_sectoriales": { "2025": { ... } },     # if sector provided
      "kpis_resumen": { ... },
      "alertas": [ ... ],
      "periodos": [...],
      "moneda": "PEN",
      "sector": "restaurants"
    }
    """
    periodos = sorted(data.get('periodos', []))
    balances = data.get('balance', {})
    ers = data.get('estado_resultados', {})
    moneda = data.get('moneda', 'PEN')
    sector = data.get('sector', None)
    extra_data = data.get('extra_data', {})

    all_ratios = {}
    variaciones = {}
    vertical = {}
    pe_results = {}
    kpis_sector = {}

    for i, periodo in enumerate(periodos):
        bg = balances.get(periodo, {})
        er = ers.get(periodo, {})
        bg_anterior = balances.get(periodos[i-1]) if i > 0 else None

        ratios_periodo = {
            "liquidez": calculate_liquidez(bg),
            "solvencia": calculate_solvencia(bg),
            "rentabilidad": calculate_rentabilidad(bg, er),
            "eficiencia": calculate_eficiencia(bg, er, bg_anterior),
            "dupont": calculate_dupont(bg, er),
        }
        all_ratios[periodo] = ratios_periodo
        vertical[periodo] = analisis_vertical(bg, er)
        pe_results[periodo] = calculate_punto_equilibrio(er)

        # KPIs sectoriales
        if sector and sector in SECTOR_KPI_FUNCTIONS:
            period_extra = extra_data.get(periodo, extra_data)
            kpis_sector[periodo] = SECTOR_KPI_FUNCTIONS[sector](bg, er, period_extra)

        # Variaciones vs periodo anterior
        if i > 0:
            er_ant = ers.get(periodos[i-1], {})
            bg_ant = balances.get(periodos[i-1], {})
            key = f"{periodo}_vs_{periodos[i-1]}"
            variaciones[key] = {
                "ventas": variation(er.get('ventas_netas'), er_ant.get('ventas_netas')),
                "margen_bruto": variation(er.get('margen_bruto'), er_ant.get('margen_bruto')),
                "margen_operativo": variation(er.get('margen_operativo'), er_ant.get('margen_operativo')),
                "resultado_neto": variation(er.get('resultado_ejercicio'), er_ant.get('resultado_ejercicio')),
                "total_activo": variation(
                    get_bg_value(bg, 'total_activo'),
                    get_bg_value(bg_ant, 'total_activo')
                ),
                "total_pasivo": variation(
                    get_bg_value(bg, 'total_pasivo'),
                    get_bg_value(bg_ant, 'total_pasivo')
                ),
                "patrimonio": variation(
                    get_bg_value(bg, 'patrimonio', 'total_patrimonio'),
                    get_bg_value(bg_ant, 'patrimonio', 'total_patrimonio')
                ),
                "capital_trabajo": variation(
                    ratios_periodo['liquidez']['capital_trabajo'],
                    all_ratios.get(periodos[i-1], {}).get('liquidez', {}).get('capital_trabajo')
                ),
            }

    # EBITDA multiperiodo
    ebitda_multi = calculate_ebitda_multiperiodo(balances, ers, periodos)
    for periodo in periodos:
        if periodo in ebitda_multi:
            all_ratios[periodo]['rentabilidad'].update(ebitda_multi[periodo])

    # KPIs del último periodo
    ultimo = periodos[-1] if periodos else None
    kpis = {}
    alertas = []
    if ultimo:
        kpis = generate_kpis(all_ratios[ultimo], ers.get(ultimo, {}), moneda)
        if len(periodos) > 1:
            key = f"{ultimo}_vs_{periodos[-2]}"
            if key in variaciones:
                kpis['variaciones'] = variaciones[key]

        # Alertas automáticas
        alertas = generate_alertas(
            all_ratios[ultimo],
            balances.get(ultimo, {}),
            ers.get(ultimo, {}),
            sector=sector,
            kpis_sector=kpis_sector.get(ultimo, {}),
        )

    result = {
        "ratios": all_ratios,
        "variaciones": variaciones,
        "analisis_vertical": vertical,
        "punto_equilibrio": pe_results,
        "kpis_resumen": kpis,
        "alertas": alertas,
        "periodos": periodos,
        "moneda": moneda,
    }

    if sector:
        result["sector"] = sector
        result["kpis_sectoriales"] = kpis_sector

    # For banking, override kpis_resumen with banking-centric summary KPIs
    if sector == "banking" and ultimo and ultimo in kpis_sector:
        ks = kpis_sector[ultimo]
        result["kpis_resumen"] = {
            "ing_financieros": ks.get("ing_financieros"),
            "utilidad_neta": ers.get(ultimo, {}).get("utilidad_neta_bancaria"),
            "margen_fin_bruto_pct": ks.get("margen_fin_bruto_pct"),
            "ratio_eficiencia_pct": ks.get("ratio_eficiencia_pct"),
            "roe_prom": ks.get("roe_prom"),
            "roa_prom": ks.get("roa_prom"),
            "car_pct": ks.get("car_pct"),
            "cobertura_car_pct": ks.get("cobertura_car_pct"),
            "rcg_pct": ks.get("rcg_pct"),
            "prima_riesgo_pct": ks.get("prima_riesgo_pct"),
            "moneda": moneda,
        }

    return result


# =============================================================================
# CLI
# =============================================================================

if __name__ == '__main__':
    source = sys.argv[1] if len(sys.argv) > 1 else None
    sector_arg = None
    for i, arg in enumerate(sys.argv):
        if arg == '--sector' and i + 1 < len(sys.argv):
            sector_arg = sys.argv[i + 1]

    try:
        if source and Path(source).exists():
            with open(source, 'r', encoding='utf-8') as f:
                data = json.load(f)
        else:
            data = json.load(sys.stdin)

        if sector_arg:
            data['sector'] = sector_arg

        result = calculate_all(data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
