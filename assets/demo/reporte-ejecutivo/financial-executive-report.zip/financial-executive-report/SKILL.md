---
name: financial-executive-report
description: Genera reportes ejecutivos de estados financieros en formato PowerPoint (.pptx) o HTML interactivo, con minuta de observaciones contables (.docx). Usa este skill cuando el usuario suba estados financieros (Balance General, Estado de Resultados) en PDF o Excel y quiera un análisis financiero profesional con ratios, comentarios ejecutivos y visualización de datos. También se activa cuando el usuario mencione 'reporte financiero', 'análisis de estados financieros', 'ratios financieros', 'reporte ejecutivo', 'reporte de directorio', 'análisis de balance', 'análisis de resultados', o quiera evaluar la salud financiera de una empresa. Funciona en modo simple (1 periodo) o multiperiodo (2+ periodos). Soporta 2 modos de reporte (diagnóstico completo o status ejecutivo). Soporta 8 sectores económicos y regulación de Perú. SIEMPRE usa este skill cuando haya estados financieros involucrados.
---

# Reporte Financiero Ejecutivo — Orquestador V4.2

## ⚡ REGLA DE EFICIENCIA — LEER ESTO PRIMERO

Este SKILL.md es **autocontenido**. Claude NO necesita leer archivos adicionales para
comenzar. Los módulos se cargan **bajo demanda** según la fase:

```
SIEMPRE LEE:     Este archivo (SKILL.md) — contiene todo para Fases 0-2
FASE 3 PPTX:     Leer core/pptx_design.md + core/comment_engine.md
FASE 3 HTML:     Leer core/html_style.md + core/comment_engine.md
SECTOR:          Leer sectors/{sector}.md cuando se confirme el sector
PAÍS:            Leer countries/{pais}.md cuando se confirme el país
NUNCA LEER:      scripts/*.py, scripts/*.js, templates/*.js (son ejecutados, no leídos)
```

---

## Pipeline V4.2

```
FASE 0         FASE 1            FASE 1.5          FASE 2                FASE 3           FASE 4
Interview → extract_data.py → generate_minuta → calculate_ratios.py → generate_pptx → QA Visual
                                  (NUEVO)        scan_router.py
                 │                   │                 │                    │
                 ▼                   ▼                 ▼                    ▼
             data.json      minuta_contable.docx   ratios.json         reporte.pptx
                                                   slide_plan.json
```

**NUEVO V4.1:** Fase 1.5 genera automáticamente una minuta de observaciones
contables (.docx) con inconsistencias detectadas, para coordinación con contabilidad.

### 3 Capas Modulares
```
core/           → Motor genérico (pptx_design, comment_engine, html_style)
sectors/        → Módulo sectorial (solo leer el sector detectado)
countries/      → Módulo de país (solo leer el país detectado)
```

---

## Modos de Reporte

### MODE: "diagnostic" (por defecto)
Análisis profundo con recomendaciones accionables.
Audiencia: Directorio, CEO, CFO. Framing: "¿Qué está pasando y qué debemos hacer?"
- Comentarios 3 capas (dato → causa → acción)
- Multi-stakeholder en resumen ejecutivo
- Slide de conclusiones: Hallazgos / Riesgos / Prioridades
- KPIs evaluados contra benchmarks sectoriales (semáforo)

### MODE: "status"
Seguimiento periódico. Audiencia: Gerencia. Framing: "¿Cómo vamos vs anterior?"
- Comentarios 1 capa: solo hechos + deltas
- KPI dashboard con tendencias (sin multi-stakeholder)
- Sin slide de conclusiones → "Evolución de Indicadores"
- Footers informativos (NUNCA verbos imperativos)
- **Requiere 2+ periodos.** Si solo hay 1, sugerir "diagnostic".

### Matriz Mode × Slide

| Slide | diagnostic | status |
|-------|-----------|--------|
| Portada | ✅ | ✅ |
| Resumen Ejecutivo | KPIs + semáforo + delta↑↓ + multi-stakeholder | KPIs + deltas + mini-trend |
| EGP | Tabla + 5 bullets + insight box EBITDA | Tabla comparativa + 2-3 bullets |
| Slide Sectorial | KPIs vs benchmark + Pareto | KPIs vs periodo anterior |
| ESF — Activos | Tabla + bullets + insight liquidez | Tabla comparativa |
| ESF — Pasivo/Pat | Tabla + bullets + insight financiamiento | Tabla comparativa |
| Ratios | Heatmap + círculos🟢🟡🔴 + ROE | Tabla con delta ↑↓ + círculos |
| Estructura | Doughnuts + trend ventas + PE | Stacked bars comparativos |
| Flujo Efectivo | Tabla indirecta + barras + bullets | Tabla indirecta + barras |
| Conclusiones | Hallazgos / Riesgos / Prioridades (dots🔴🟡🟢) | ❌ NO |
| Evolución | ❌ NO | ✅ Tabla resumen flechas |
| Cierre | ✅ | ✅ |

---

## FASE 0 — ENTREVISTA OBLIGATORIA

⚠️ **NUNCA generar un reporte sin las 4 preguntas mínimas.**
Usar `ask_user_input` (widget), no preguntas en prosa. Max 2 turnos, 3 preguntas por turno.

### Pregunta 1: País + Sector (confirmación)
Auto-detectar del Excel. Presentar: "¿Es un [sector] en [país]?"
Triggers detección: food cost/menajes/cortesías → restaurants | existencias/mercaderías → distribution/retail | obras en curso → construction | colocaciones/depositos/SBS/morosidad/cartera crediticia → banking

### Pregunta 2: Contexto del periodo
Multi-select: Operación normal | Apertura reciente | Cambio gerencia | Reestructuración | Otro
Para restaurantes agregar: Cobra recargo 10% | Venta fuerte licores | Mes bajo estacionalidad | Remodelación

### Pregunta 3: Modo de reporte
diagnostic (Diagnóstico completo) | status (Status ejecutivo)
Si solo 1 periodo + status: warning y sugerir diagnostic.

### Pregunta 4: Formato de salida
PPTX | HTML interactivo | Ambos

### Post-entrevista: Cargar módulos
```
Leer: sectors/{sector}.md + countries/{pais}.md
```

---

## FASE 1 — EXTRACCIÓN DE DATOS

### Exploración previa (ANTES de parsear)
1. Listar TODAS las hojas del Excel y dimensiones
2. Identificar data complementaria (costos por categoría, mensual, CC)
3. Registrar hojas útiles vs vacías

### Ejecución
```bash
python scripts/extract_data.py /path/to/excel.xlsx --sector {sector}
```
**Output:** `data.json` con ESF, EGP, complementaria, metadata de calidad.

### Claude valida
- ¿Totales cuadran? Activo = Pasivo + Patrimonio
- ¿Resultado EGP = Resultado ESF? (si difieren > S/ 100 → ALERTAR al usuario)
- ¿Cuentas mapeadas correctamente?
- Si parser falla → extracción manual

### Mapeo de Cuentas
```
Balance: AC (Efectivo, CxC, Inventarios, Suministros, Diferido) / ANC (IME, Deprec, Intangibles)
Pasivo: PC (Tributos, Remuneraciones, CxP Com, CxP Div, Provisiones) / PNC / Patrimonio
Resultado: Ventas → CV → MB → Gastos Op → EBIT → Financieros → Otros → Resultado
```
Nombres alternativos: Efectivo=Caja y Bancos | CxC=Clientes,Deudores | Inventarios=Existencias
IME=Activo Fijo,PPE | CxP=Proveedores | CV=Costo Servicio,Food Cost

Reglas: CV positivo internamente | Depreciación valor absoluto | Pérdidas acum signo negativo

---

## FASE 1.5 — MINUTA DE OBSERVACIONES CONTABLES (NUEVO V4.1)

⚠️ **SIEMPRE generar después de la extracción, ANTES del reporte.**
Es un documento Word (.docx) para coordinación con el área contable.

### Propósito
Listar toda inconsistencia, dato faltante o partida inusual detectada en los EEFF,
para que contabilidad corrija ANTES de que el reporte ejecutivo se presente al directorio.

### Generación
```bash
# Leer el DOCX skill (public/docx/SKILL.md) para la generación del documento
node scripts/generate_minuta.js data.json minuta_contable.docx
```

### Contenido de la Minuta
1. **Encabezado**: Empresa, periodo, fecha de generación, confidencialidad
2. **Verificación de Ecuación Patrimonial**: Activo vs Pasivo+Patrimonio, diferencia si existe
3. **Consistencia EGP ↔ ESF**: Resultado del Ejercicio en ambos estados, diferencia
4. **Composición del Patrimonio**: Capital + Resultados Acum + Resultado = Total declarado
5. **Observaciones por Cuenta** (solo si hay anomalías):
   - Cuentas con saldo inusual (ej: CxC negativa, efectivo negativo)
   - Partidas materiales (>10% del total) sin detalle
   - Gastos anticipados/preoperativos grandes sin nota
   - Depreciación acumulada vs IME bruto (% razonable)
6. **Partidas No Recurrentes**: Dif. cambio, otros ingresos, auspicios material
7. **Alertas Regulatorias**: Patrimonio negativo, pérdidas > 2/3 capital (Art. 407 LGS)
8. **Tabla Resumen de Hallazgos**: Tipo | Descripción | Severidad | Acción requerida

### Reglas
- Tono profesional y neutro (es para contabilidad, no directorio)
- Solo reportar hechos y números, NO interpretaciones de negocio
- Usar formato: "Se observa que [dato]. Se sugiere [acción contable]."
- Si todo cuadra: "No se detectaron inconsistencias materiales en los EEFF revisados."

---

## FASE 2 — CÁLCULOS + ROUTING

```bash
python scripts/calculate_ratios.py data.json --sector {sector}
python scripts/scan_router.py data.json ratios.json --sector {sector} --country {pais} --mode {mode}
```
**Output:** `ratios.json` + `slide_plan.json`

### Fórmulas de Ratios

**Liquidez:**
- Ratio Corriente = AC / PC
- Prueba Ácida = (AC - Inventarios - Suministros) / PC
- Capital Trabajo = AC - PC
- Días Cobertura = Efectivo / ((CV + Gastos_Rest + Gastos_Admin) / 365)
  Edge: gastos=0 → NA | <15 días → alerta liquidez crítica

**Solvencia:**
- D/E = Pasivo / Patrimonio. Edge: pat<0 → "N/A - Pat. Negativo"
- Endeudamiento = Pasivo / Activo × 100
- Concentración CP = PC / Pasivo Total × 100
- Cobertura Intereses = EBIT / Gastos Financieros. Edge: GF=0 → NA

**Rentabilidad:**
- Margen Bruto = (Ventas-CV)/Ventas × 100
- Margen Operativo = EBIT/Ventas × 100
- Margen Neto = Resultado/Ventas × 100
- EBITDA = EBIT + Depreciación_periodo. SIEMPRE mostrar descomposición explícita.
  Edge: EBITDA<0 → "operación no genera caja"
- ROE = Resultado/Patrimonio × 100. Edge: pat<0 → "N/A - Pat. Negativo"; pat<5% activo → usar DuPont
- ROA = Resultado/Activo × 100

**Eficiencia:**
- Rotación Inv = CV/Inventarios | Días = 365/Rotación
- Periodo Cobro = 365 / (Ventas/CxC)
- Periodo Pago = 365 / (CV/CxP)
- CCE = Días Inv + Per Cobro - Per Pago

**Punto Equilibrio:**
- PE = Gastos Fijos / (1 - CV/Ventas)

### Routers del scan_router.py

| Router | Decisión | Output |
|--------|----------|--------|
| R-PERIOD | 1 vs 2+ periodos | Cambia tablas/charts |
| R-RICHNESS | Data complementaria | Slides condicionales |
| R-SEVERITY | Sano/riesgo/crítico | Tono + colores |
| R-DISTORT | Distorsiones | Ajusta interpretación |
| R-ALERT | Alertas legales | Conclusiones + prioridades |
| R-CHART | Selección charts | Tipo visualización |
| R-MODE | diagnostic vs status | Slides, comentarios, framing |

### Claude revisa slide_plan.json
- ¿La severidad es correcta?
- ¿Los comentarios capturan los matices?
- ¿Hay algo que el router no detectó?
- ¿Quiere agregar/quitar alguna slide?

---

## FASE 3 — GENERACIÓN

### PPTX
```bash
# ⚡ AHORA leer: core/pptx_design.md + core/comment_engine.md
node scripts/generate_pptx.js data.json ratios.json slide_plan.json output.pptx
```

### HTML
```bash
python scripts/generate_html.py data.json ratios.json slide_plan.json reporte.html
```
Sale de los mismos JSON que el PPTX, así que dos corridas sobre el mismo archivo
dan el mismo reporte. Single-file, CSS+JS embebidos, sin dependencias externas
más que la tipografía. El waterfall va en SVG en línea para que el archivo se
abra sin red y se imprima bien.

**PDF.** El HTML trae reglas `@media print` con salto de página por lámina:
```bash
# desde el navegador: Imprimir → Guardar como PDF (horizontal, con fondos)
# headless, si hay Chromium disponible:
#   page.pdf({format:'A4', landscape:true, printBackground:true})
```

### Reglas SWD (resumen — detalle completo en pptx_design.md)
- Cada slide responde UNA pregunta clara
- Arco: Contexto (slides 1-2) → Evidencia (3-8) → Acción (9-10)
- Color semántico: azul=positivo, rojo=negativo, teal=subtotal, gris=contexto
- Max 5 segmentos en doughnut | Barras ordenadas mayor→menor
- Diseñar en GRIS primero, luego UN color estratégico para foco
- ⚠️ Filas TOTAL: texto BLANCO sobre fondo AZUL (NUNCA texto oscuro sobre azul)
- ⚠️ Un waterfall DEBE reconciliar: si los tramos no suman el total declarado, no se
  dibuja. Un puente que no cierra significa una partida sin mapear o un subtotal
  contado dos veces, y el gráfico saldría mintiendo con confianza.

---

## FASE 4 — QA

```bash
python scripts/office/soffice.py --headless --convert-to pdf output.pptx
pdftoppm -jpeg -r 150 output.pdf slide
```

Checklist (detalle completo en pptx_design.md sección 9):
- [ ] Montos en slides = montos del Excel
- [ ] Porcentajes con 1 decimal
- [ ] Activo = Pasivo + Patrimonio
- [ ] Filas TOTAL: texto BLANCO
- [ ] Doughnuts con leyenda visible
- [ ] Sin 3D, sin gridlines excesivos
- [ ] Insight boxes llenan espacios vacíos entre contenido y footer
- [ ] Nota de patrimonio negativo en doughnut de financiamiento

---

## Sectores Soportados

| ID | Sector | Archivo | Profundidad |
|----|--------|---------|-------------|
| restaurants | Restaurantes / Food Service | sectors/restaurants.md | Profundo |
| distribution | Distribución / Wholesale | sectors/distribution.md | Profundo |
| retail | Retail / Comercio | sectors/retail.md | Estándar |
| construction | Construcción / Inmobiliario | sectors/construction.md | Estándar |
| manufacturing | Manufactura | sectors/manufacturing.md | Estándar |
| services | Servicios Profesionales | sectors/services.md | Estándar |
| healthcare | Salud / Clínicas | sectors/healthcare.md | Estándar |
| hospitality | Hotelería / Turismo | sectors/hospitality.md | Estándar |
| banking | Banca y Seguros | sectors/banking.md | Profundo |

## Países: peru (countries/peru.md)

---

## Cambios V4.2 — Mejoras Aprobadas

### M-01alt: KPI Cards Mejoradas (Resumen Ejecutivo)
En modo multiperiodo, cada KPI card muestra 3 niveles de información:
```
┌───────────────────┐
│ LABEL      (8pt)  │  gris
│ VALOR      (18pt) │  bold, color semáforo
│ ↑↓ DELTA   (9pt)  │  verde/rojo, bold, con flecha ↑↓
│ vs [anterior] (7pt)│  gris itálica, valor del periodo anterior
└───────────────────┘
```
- El delta debe ser prominente: fontSize 9pt bold, con flecha ↑ o ↓ y color semántico
- El valor anterior se muestra en gris itálica (7pt) como referencia
- NO agregar una tercera fila de cards. Mantener 2 filas × 5 cards + multi-stakeholder
- En modo single-period: solo LABEL + VALOR (sin delta ni anterior)

### M-02: Columna "Variación S/" en Tablas Comparativas
En modo multiperiodo, las tablas de EGP y ESF incluyen columna de variación absoluta (S/):
- **Con bullets laterales (Tipo A):** Solo agregar Var S/ si hay ≤5 columnas actuales. Si la tabla ya tiene 6+ cols, la Var S/ la cubren los bullets narrativos.
- **Sin bullets (Tipo F full-width):** SIEMPRE incluir Var S/ + Var %
- Formato: negativo en rojo con paréntesis. Positivo en color normal.
- Columna header: "Var S/"

### M-03: Semáforo con Círculos en Tabla de Ratios
Agregar columna "Estado" al final de la tabla de ratios con círculos de color sólido:
```
🟢 Cumple benchmark (color: 28A745, radio: 0.12")
🟡 En observación (color: FFC107, radio: 0.12")
🔴 Fuera de benchmark (color: CC0000, radio: 0.12")
```
Implementación en pptxgenjs:
- Después de renderizar la tabla, agregar shapes OVAL posicionados al final de cada fila
- Calcular Y de cada fila: tableY + headerHeight + (rowIndex * rowHeight)
- Mantener TAMBIÉN el heatmap de fondo de celda (complementario, no reemplazo)
- Incluir leyenda al pie: "🟢 Cumple | 🟡 Observación | 🔴 Fuera de benchmark"

### M-04a: ROE como Ratio Estándar
- **Fórmula:** ROE = Resultado / Patrimonio × 100
- **Benchmarks estándar:** bajo <8%, normal 8-15%, sólido >15%
- **Edge cases:** Si patrimonio < 0 → "N/A - Pat. Negativo"; si pat < 5% activo → incluir nota DuPont
- **Ubicación:** En sección Rentabilidad, entre Margen Neto y ROA
- **Benchmarks sectoriales:** Ajustar en cada sectors/*.md

### M-05: Tabla Resumen de Flujo de Efectivo (Método Indirecto)
En la slide de Flujo de Efectivo, usar Layout Tipo D (dual):
- **Izquierda:** Tabla resumen método indirecto (6-8 filas)
- **Derecha:** Gráfico de barras por actividad (existente)

Estructura de la tabla:
```
| Concepto                    | Periodo 1  | Periodo 2  | Var     |
| Resultado Neto              | (xxx)      | (xxx)      | (xxx)   |
| (+) Depreciación y Amort.   | xxx        | xxx        | xxx     |
| (+) Otros ajustes no caja   | xxx        | xxx        | xxx     |
| (±) Cambios en WK           | xxx        | xxx        | xxx     |
| = Flujo Operativo           | xxx        | xxx        | xxx     |  ← SUBTOTAL
| Flujo de Inversión          | (xxx)      | (xxx)      | xxx     |
| Flujo de Financiamiento     | xxx        | (xxx)      | (xxx)   |
| Efecto Tipo de Cambio       | (xxx)      | (xxx)      | xxx     |
| = Variación Neta Efectivo   | xxx        | (xxx)      | (xxx)   |  ← TOTAL
```
- Si solo hay 1 periodo: tabla de 2 columnas (Concepto + Importe)
- Filas subtotal/total con formato bold + fondo azul/gris
- Fuente de datos: Estado de Flujo de Efectivo del EEFF original

### M-09: Dots de Color en Headers de Prioridades (Conclusiones)
En la slide de Conclusiones (Tipo E), los headers de las 3 columnas de prioridades usan
círculos de color como prefijo visual:
```
🔴 [shape OVAL rojo 0.15"] + "Urgente (0-3 meses)"     — bold, color CC0000
🟡 [shape OVAL ámbar 0.15"] + "Mediano Plazo (3-6m)"   — bold, color FFC107  
🟢 [shape OVAL verde 0.15"] + "Estructural (6-12m)"    — bold, color 28A745
```
Implementación: addShape(OVAL) + addText al lado. El dot se posiciona 0.2" antes del texto.
Refuerza el sistema visual de semáforo usado en la tabla de ratios → consistencia cromática.

---

## Archivos del Skill

| Archivo | Propósito | Cuándo leer |
|---------|-----------|-------------|
| **SKILL.md** | Orquestador completo | ⚡ SIEMPRE (único archivo inicial) |
| **Core** | | |
| core/pptx_design.md | Paleta, layout, coordenadas, reglas SWD, QA | Solo Fase 3 PPTX |
| core/html_style.md | Formato HTML interactivo | Solo Fase 3 HTML |
| core/comment_engine.md | Templates comentarios × mode | Solo Fase 3 |
| core/ratio_formulas.md | Referencia detallada fórmulas | Solo si hay dudas |
| **Scripts (EJECUTAR, nunca leer)** | | |
| scripts/extract_data.py | Excel → data.json | Fase 1: ejecutar |
| scripts/validate_data.py | Validación consistencia | Fase 1: ejecutar |
| scripts/generate_minuta.js | data.json → minuta.docx | Fase 1.5: ejecutar |
| scripts/calculate_ratios.py | data.json → ratios.json | Fase 2: ejecutar |
| scripts/scan_router.py | Routing → slide_plan.json | Fase 2: ejecutar |
| scripts/generate_pptx.js | Plan → reporte.pptx | Fase 3: ejecutar |
| scripts/generate_html.py | Plan → reporte.html (+ PDF por impresión) | Fase 3: ejecutar |
| **Templates (EJECUTAR, nunca leer)** | | |
| templates/base.js | Helpers compartidos | Motor interno |
| templates/slide_*.js | 1 template por slide | Motor interno |
| templates/slide_kpi_distribution.js | Lámina sectorial de distribución | Motor interno |
